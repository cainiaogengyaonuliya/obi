
pyinstaller --onefile --noconsole --hidden-import comtypes.main --hidden-import comtypes.stream --hidden-import comtypes.client._generate --add-data "F:\xu\code\pycharm2\pythonProject1\main_dir\templates;templates" --add-data "F:\xu\code\pycharm2\pythonProject1\main_dir\static;static" --icon="F:\xu\code\pycharm2\pythonProject1\main_dir\static\loyalty.ico" "F:\xu\code\pycharm2\pythonProject1\main_dir\main_gui.py"



pyinstaller --onefile --noconsole --add-data "F:\xu\code\pycharm2\pythonProject1\main_dir\templates;templates" --add-data "F:\xu\code\pycharm2\pythonProject1\main_dir\static;static" --icon="F:\xu\code\pycharm2\pythonProject1\main_dir\static\loyalty.ico" "F:\xu\code\pycharm2\pythonProject1\main_dir\main_gui_2.py"


pyinstaller --onefile --noconsole --add-data "F:\xu\code\pycharm2\pythonProject1\main_dir\templates;templates" --add-data "F:\xu\code\pycharm2\pythonProject1\main_dir\static;static" --icon="F:\xu\code\pycharm2\pythonProject1\main_dir\static\loyalty.ico" "F:\xu\code\pycharm2\pythonProject1\main_dir\main_gui_2.py"


--upx-dir="D:\Downloads\upx-4.2.4-win64\upx-4.2.4-win64\"

pyinstaller --onefile --noconsole --upx-dir="D:\Downloads\upx-4.2.4-win64\upx-4.2.4-win64\" --hidden-import comtypes.main --hidden-import comtypes.stream --hidden-import comtypes.client._generate --add-data "F:\xu\code\pycharm2\pythonProject1\main_dir\templates;templates" --add-data "F:\xu\code\pycharm2\pythonProject1\main_dir\static;static" --icon="F:\xu\code\pycharm2\pythonProject1\main_dir\static\loyalty.ico" "F:\xu\code\pycharm2\pythonProject1\main_dir\main_gui.py"

pyinstaller --onefile --noconsole --hidden-import comtypes.main --hidden-import comtypes.stream --hidden-import comtypes.client._generate --add-data "F:\xu\code\pycharm2\pythonProject1\main_dir\templates;templates" --add-data "F:\xu\code\pycharm2\pythonProject1\main_dir\static;static" --icon="F:\xu\code\pycharm2\pythonProject1\main_dir\static\loyalty.ico" "F:\xu\code\pycharm2\pythonProject1\main_dir\main_gui.py"

--add-data "config.db;."

pyinstaller --onefile --noconsole --hidden-import comtypes.main --hidden-import comtypes.stream --hidden-import comtypes.client._generate --add-data "F:\xu\code\pycharm2\pythonProject1\main_dir\secret.db;." --add-data "F:\xu\code\pycharm2\pythonProject1\main_dir\templates;templates" --add-data "F:\xu\code\pycharm2\pythonProject1\main_dir\static;static" --icon="F:\xu\code\pycharm2\pythonProject1\main_dir\static\loyalty.ico" "F:\xu\code\pycharm2\pythonProject1\main_dir\main_gui.py"
