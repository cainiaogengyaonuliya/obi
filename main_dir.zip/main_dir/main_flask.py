from flask import Flask, render_template

from blueprints.chu_ku_shen_he.chu_ku_shen_he_blueprint import chu_ku_shen_he_blueprint
from blueprints.production_data.production_data_blueprint import production_data_blueprint
from blueprints.qing_gou_local.qing_gou_local_blueprint import qing_gou_local_blueprint
from blueprints.yi_wei_fa_piao.yi_wei_fa_piao_blueprint import yi_wei_fa_piao_blueprint
from blueprints.qian_zi.qian_zi_blueprint import qian_zi_blueprint
from blueprints.production_data_progress.production_data_progress_blueprint import  production_data_progress_blueprint

app = Flask(__name__)

# 注册蓝图

app.register_blueprint(production_data_progress_blueprint, url_prefix='/')
app.register_blueprint(qing_gou_local_blueprint, url_prefix='/')
app.register_blueprint(production_data_blueprint, url_prefix='/')
app.register_blueprint(chu_ku_shen_he_blueprint, url_prefix='/')
app.register_blueprint(yi_wei_fa_piao_blueprint, url_prefix='/')
app.register_blueprint(qian_zi_blueprint, url_prefix='/')
@app.route('/')
@app.route('/home')
def home():
    return render_template("home3.html")
@app.route('/home2')
def home2():
    return render_template("home2.html")
@app.route('/home3')
def home3():
    return render_template("home3.html")
def run_flask():
    app.run(debug=False)
if __name__ == '__main__':
    app.run(debug=True)
