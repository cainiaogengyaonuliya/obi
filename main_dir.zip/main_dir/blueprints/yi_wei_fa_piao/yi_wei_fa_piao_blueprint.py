import os
import sqlite3
import tkinter
from tkinter import filedialog

from flask import Blueprint, render_template, jsonify, request

from blueprints.yi_wei_fa_piao.yi_wei_multi import yi_wei_insert_multy
from blueprints.yi_wei_fa_piao.yi_wei_single import yi_wei_insert_single



def insert_basic_db(my_key,my_value):
    connection = sqlite3.connect('basic_data.db')
    # 创建一个游标对象
    cursor = connection.cursor()
    # 插入数据
    cursor.execute('''
                    INSERT OR REPLACE INTO file_paths (id, file_name, file_path) VALUES (
                        (SELECT id FROM file_paths WHERE file_name = ?),
                        ?, ?
                    )
                    ''',
                   (my_key, my_key, my_value))
    connection.commit()  # 提交事务
    # 关闭游标和连接
    cursor.close()
    connection.close()
def get_value_from_basic_db(my_key):
    connection = sqlite3.connect('basic_data.db')
    cursor = connection.cursor() # 创建一个游标对象
    cursor.execute("SELECT * FROM file_paths where file_name='"+my_key+"'")   # 执行查询
    rows = cursor.fetchall()# 获取所有结果
    #print("查询结果：") # 打印查询结果
    my_value=""
    for row in rows:
        #print(row)
        my_value= row[2]
    # 关闭游标和连接
    cursor.close()
    connection.close()
    return my_value
def open_file_dialog():
    file_path = ""
    dialog = tkinter.Toplevel()  # 创建对话窗口
    dialog.withdraw()  # 隐藏对话窗口
    dialog.geometry("300x150")
    dialog.attributes("-topmost", True)  # 设置对话窗口为置顶
    def on_file_select():  # 文件选择功能
        file_path = filedialog.askopenfilename(parent=dialog, title="Select a file")
        if file_path:
            print(f"Selected file: {file_path}")
        dialog.destroy()  # 关闭对话窗口
        return file_path
    file_path = on_file_select()
    return file_path

yi_wei_fa_piao_blueprint = Blueprint('yi_wei_fa_piao_blueprint', __name__)
@yi_wei_fa_piao_blueprint.route('/yi_wei_fa_piao')
def yi_wei_fa_piao_blueprint_1():
    return render_template("yi_wei_fa_piao/home.html")

@yi_wei_fa_piao_blueprint.route("/yi_wei_fa_piao_post",methods=["post"])
def yi_wei_fa_piao_blueprint_2():
    return_json = {'status': 'success'}
    if request.method == 'POST':
        data = request.get_json()
        my_type = data["my_type"]
        if my_type=="upload_path":
            files=""
            files_sorted=""
            file_path=open_file_dialog()
            folder_path=file_path[0:-(len(file_path.split("/")[-1])+1)]
            if folder_path!="":
                insert_basic_db("毅威_数据源_文件夹路径",folder_path)
                files = [f for f in os.listdir(folder_path) if os.path.isfile(os.path.join(folder_path, f))]
                files_sorted = sorted(files)  # 对文件名进行排序
            return_json["files"] = files_sorted
            return_json["folder_path"] = folder_path
        if my_type == "yi_wei_folder_open":

            yi_wei_fa_piao_path = open_file_dialog()
            insert_basic_db("毅威_台账_文件路径", yi_wei_fa_piao_path)
            return_json["file_path"] = yi_wei_fa_piao_path
        if my_type == "main_start":
            checkbox_list=data["checkbox_list"]
            print("选中的文件"+str(checkbox_list))
            chuan_ci=data["chuan_ci"]
            print("船次："+chuan_ci)
            毅威_数据源_文件夹路径 = get_value_from_basic_db("毅威_数据源_文件夹路径")
            毅威_台账_文件路径 = get_value_from_basic_db("毅威_台账_文件路径")
            print("毅威_数据源_文件夹路径:"+毅威_数据源_文件夹路径)
            print("毅威_台账_文件路径："+毅威_台账_文件路径)
            if len(checkbox_list)>1: #multi
                source_excel_path_list=[]
                if 毅威_数据源_文件夹路径!="":
                    for i in range(0,len(checkbox_list)):
                        source_excel_path_list.append(毅威_数据源_文件夹路径+"/"+checkbox_list[i])
                    if 毅威_台账_文件路径!="":
                        print("当前处理:多个")
                        yi_wei_insert_multy(source_excel_path_list,毅威_台账_文件路径,chuan_ci)
            else: #single

                源文件路径=毅威_数据源_文件夹路径+"/"+checkbox_list[0]
                print("当前处理:"+源文件路径)
                if 源文件路径!="" and 毅威_台账_文件路径!="":
                    yi_wei_insert_single(源文件路径,毅威_台账_文件路径,chuan_ci)
        if my_type == "fetch_data":
            毅威_数据源_文件夹路径=""
            files=""
            files_sorted=""
            毅威_数据源_文件夹路径=get_value_from_basic_db("毅威_数据源_文件夹路径")
            if 毅威_数据源_文件夹路径!="":
                files = [f for f in os.listdir(毅威_数据源_文件夹路径) if os.path.isfile(os.path.join(毅威_数据源_文件夹路径, f))]
                files_sorted = sorted(files)  # 对文件名进行排序
            毅威_台账_文件路径=get_value_from_basic_db("毅威_台账_文件路径")
            return_json["file_path"] = 毅威_台账_文件路径
            return_json["files"] = files_sorted
            return_json["folder_path"] = 毅威_数据源_文件夹路径
        return return_json
