import ctypes
import re
from datetime import datetime

import xlwings
from pywinauto import Application


def set_excel_window_right_half(app):
    # 获取Excel应用程序窗口句柄
    excel_hwnd = app.api.Hwnd

    # 使用pywinauto连接到Excel窗口
    app_window = Application().connect(handle=excel_hwnd)

    # 设置Excel窗口置顶
    app_window.top_window().set_focus()
    ctypes.windll.user32.SetWindowPos(excel_hwnd, -1, 0, 0, 0, 0, 0x0001)  # -1 表示置顶

    # 获取屏幕的宽度和高度
    screen_width = ctypes.windll.user32.GetSystemMetrics(0)
    screen_height = ctypes.windll.user32.GetSystemMetrics(1)

    # 获取任务栏的高度
    taskbar_info = ctypes.windll.user32.SystemParametersInfoW(0x0030, 0, 0, 0)  # SPI_GETWORKAREA
    work_area = ctypes.wintypes.RECT()
    ctypes.windll.user32.SystemParametersInfoW(0x0030, 0, ctypes.byref(work_area), 0)
    taskbar_height = screen_height - work_area.bottom

    # 计算右半边窗口的宽度和高度，减去任务栏高度
    right_half_width = screen_width // 2
    right_half_height = screen_height - taskbar_height

    # 调整Excel窗口大小和位置，移动到右半边
    app_window.top_window().move_window(x=screen_width - right_half_width, y=0, width=right_half_width, height=right_half_height)
def read_yi_wei(excel_path):
    return_data={"是否为标准文件":"是","data":[]}
    app = xlwings.App(visible=False, add_book=False)  # 创建一个不可见的 Excel 应用程序实例
    wb = app.books.open(excel_path,update_links=False)  # 打开工作簿
    sheet = wb.sheets["INVOICE"]  # 选择一个工作表
    sheet.activate()
    company_name = sheet.range((3, 1)).value
    company_name=company_name.strip()
    if not company_name.startswith("NINGBO"):
        return_data["是否为标准文件"]= "公司名称不匹配,不完全等于NINGBO YIWEI MINING CO., LTD"
        wb.close()
        app.quit()
        return return_data

    return_data["公司名称"]="宁波毅威"
    if sheet.range((14, 1)).value != "No":
        return_data["是否为标准文件"]="No的位置不匹配"
        wb.close()
        app.quit()
        return return_data
    发票号 = sheet.range((8, 2)).value
    合同号 = sheet.range((8, 6)).value
    日期=sheet.range((9, 6)).value
    航班 = sheet.range((13, 2)).value
    币种=re.search(r'\((.*?)\)', sheet.range((14, 6)).value).group(1)
    if 币种=="CNY":
        币种="人民币RMB"
    if 币种=="USD":
        币种="美元USD"
    return_data["发票号"]=发票号
    return_data["合同号"] =合同号
    return_data["日期"] =日期
    return_data["航班"] =航班
    return_data["币种"] =币种

    data = sheet.range('A1:Z300').value # 一次性读取前30行和30列的数据，减少I/O操作
    for row in range(14,len(data)):
        cell_value = data[row][0]
        if isinstance(cell_value, (int, float)):  # 判断是否为数字
            return_data["data"].append({
                "合同号":data[row][1],
                "中文名称":data[row][2].split("\n")[0],
                "英文名称": data[row][2].split("\n")[1],
                "数量":data[row][3],
                "数量单位": data[row][4],
                "单价": data[row][5],
                "总价": data[row][6],
            })
        else:
            return_data["总金额"]= data[row][6]
            break
    wb.close()
    app.quit()
    return return_data
def insert_yi_wei(destination_path,return_data,序号,船次):
    app = xlwings.App(visible=True, add_book=False)  # 创建一个不可见的 Excel 应用程序实例
    set_excel_window_right_half(app)
    wb = app.books.open(destination_path, update_links=False)  # 打开工作簿
    sheet = next(sheet for sheet in wb.sheets if sheet.name.startswith("清关发票明细台账"))
    last_row = sheet.range('K1').end('down').row
    sheet.api.Rows(last_row).Select()  # 选择第 1 行
    start_row = int(last_row) + 1
    data_list=return_data["data"]
    for i in range(0,len(data_list)):
        sheet.range((start_row + i, 1)).api.Select()
        sheet.range((start_row + i, 1)).value = 序号
        sheet.range((start_row + i, 2)).value = 船次
        sheet.range((start_row + i, 3)).value = return_data["航班"]
        sheet.range((start_row + i, 5)).value = return_data["公司名称"]

        sheet.range((start_row + i, 7)).value = data_list[i]["中文名称"]
        sheet.range((start_row + i, 8)).value = data_list[i]["英文名称"]
        sheet.range((start_row + i, 11)).value = return_data["发票号"]
        sheet.range((start_row + i, 12)).value = data_list[i]["合同号"]
        sheet.range((start_row + i, 13)).value = data_list[i]["数量"]
        sheet.range((start_row + i, 14)).value = data_list[i]["数量单位"]
        sheet.range((start_row + i, 15)).value = return_data["币种"]
        sheet.range((start_row + i, 16)).value = data_list[i]["单价"]
        sheet.range((start_row + i, 17)).value = data_list[i]["总价"]
        sheet.range((start_row + i, 18)).value = return_data["日期"]
        sheet.range((start_row + i, 19)).value = return_data["日期"].year
        sheet.range((start_row + i, 20)).value = "系统未做"
        # 获取当前日期并格式化为 yyyymmdd
        current_date = datetime.now().strftime('%Y%m%d')
        sheet.range((start_row + i, 23)).value = current_date

    #wb.save()  # 保存工作簿
    #wb.close()  # 关闭工作簿
    #app.quit()  # 退出应用程序

def yi_wei_insert_single(source_excel_path,destination_path,船次):
    return_data = read_yi_wei(source_excel_path)
    print(return_data)
    if return_data["是否为标准文件"]=="是":
        序号 = source_excel_path.split("/")[-1].split(".")[0]
        insert_yi_wei(destination_path, return_data, 序号, 船次)
    else:
        print(return_data["是否为标准文件"])
#excel_path = r"C:\Users\22590\Desktop\清关\资料0820\221st Shipment\DRAFT CIPL\66. YWW2400025601XXHP PP TUBE PACKING D80.xlsx"
#dest = r"C:\Users\22590\Desktop\清关\HPAL---清关发票明细台账(更新版）20240820.xlsx"
#yi_wei_insert_single(excel_path,dest,"船次")