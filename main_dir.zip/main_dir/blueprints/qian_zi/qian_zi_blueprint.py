import sqlite3
import tkinter
from tkinter import filedialog

from flask import Blueprint, render_template, request

from blueprints.qian_zi.qian_zi import qian_zi_main

from blueprints.qian_zi.qian_zi import qian_zi_main_2

from blueprints.qian_zi.qian_zi_multi import qian_zi_main_3


def open_file_dialog():
    file_path = ""
    dialog = tkinter.Toplevel()  # 创建对话窗口
    dialog.withdraw()  # 隐藏对话窗口
    dialog.geometry("300x150")
    dialog.attributes("-topmost", True)  # 设置对话窗口为置顶
    def on_file_select():  # 文件选择功能
        file_path = filedialog.askopenfilename(parent=dialog, title="Select a file")
        if file_path:
            print(f"Selected file: {file_path}")
        dialog.destroy()  # 关闭对话窗口
        return file_path
    file_path = on_file_select()
    return file_path
def insert_basic_db(my_key,my_value):
    connection = sqlite3.connect('basic_data.db')
    # 创建一个游标对象
    cursor = connection.cursor()
    # 插入数据
    cursor.execute('''
                    INSERT OR REPLACE INTO file_paths (id, file_name, file_path) VALUES (
                        (SELECT id FROM file_paths WHERE file_name = ?),
                        ?, ?
                    )
                    ''',
                   (my_key, my_key, my_value))
    connection.commit()  # 提交事务
    # 关闭游标和连接
    cursor.close()
    connection.close()
def get_value_from_basic_db(my_key):
    connection = sqlite3.connect('basic_data.db')
    cursor = connection.cursor() # 创建一个游标对象
    cursor.execute("SELECT * FROM file_paths where file_name='"+my_key+"'")   # 执行查询
    rows = cursor.fetchall()# 获取所有结果
    #print("查询结果：") # 打印查询结果
    my_value=""
    for row in rows:
        #print(row)
        my_value= row[2]
    # 关闭游标和连接
    cursor.close()
    connection.close()
    return my_value









qian_zi_blueprint = Blueprint('qian_zi_blueprint', __name__)
@qian_zi_blueprint.route('/qian_zi')
def qing_gou_local_home():
    return render_template("qian_zi/home.html")
@qian_zi_blueprint.route('/qian_zi_2')
def qing_gou_local_home_2():
    return render_template("qian_zi/home_2.html")
@qian_zi_blueprint.route('qian_zi_post',methods=["post"])
def qing_gou_local_upload_path():
    return_json = {'status': 'success'}
    if request.method == 'POST':
        data = request.get_json()
        my_type = data["my_type"]

        if my_type == "open_file":

            file_path=open_file_dialog()

            insert_basic_db("签字文件路径",file_path)

            return_json["file_path"]=file_path
        if my_type == "main_start":
            签字文件路径=get_value_from_basic_db("签字文件路径")
            checkbox_list=data["checkbox"]
            if len(checkbox_list)>0:
                if 签字文件路径!="":
                    qian_zi_main(签字文件路径,checkbox_list[0])
                    pass
        if my_type=="main_start_2":
            签字文件路径 = get_value_from_basic_db("签字文件路径")
            checkbox_list = data["checkbox"]
            if len(checkbox_list) > 0:
                if 签字文件路径 != "":
                    qian_zi_main_2(签字文件路径, checkbox_list[0])

        if my_type=="main_start_3":
            签字文件路径 = get_value_from_basic_db("签字文件路径")
            checkbox_list = data["checkbox"]

            if len(checkbox_list) > 0:
                if 签字文件路径 != "":
                    qian_zi_main_3(签字文件路径, checkbox_list)

        if my_type=="fetch_data":
            签字文件路径 = get_value_from_basic_db("签字文件路径")
            return_json["file_path"] = 签字文件路径
    return return_json