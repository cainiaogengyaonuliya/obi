import ctypes
import os
import sys
import threading
import xlwings
from PIL import ImageGrab
import keyboard
import time
import cv2
import numpy as np
import pyperclip
from pywinauto import keyboard as kb, Application
import tkinter as tk
from tkinter import messagebox
from pywinauto import mouse
业务日期位置=None

debug=1
def set_excel_window_right_half(app):
    # 获取Excel应用程序窗口句柄
    excel_hwnd = app.api.Hwnd

    # 使用pywinauto连接到Excel窗口
    app_window = Application().connect(handle=excel_hwnd)

    # 设置Excel窗口置顶
    app_window.top_window().set_focus()
    ctypes.windll.user32.SetWindowPos(excel_hwnd, 0, 0, 0, 0, 0, 0x0001)  # -1 表示置顶

    # 获取屏幕的宽度和高度
    screen_width = ctypes.windll.user32.GetSystemMetrics(0)
    screen_height = ctypes.windll.user32.GetSystemMetrics(1)

    # 获取任务栏的高度
    taskbar_info = ctypes.windll.user32.SystemParametersInfoW(0x0030, 0, 0, 0)  # SPI_GETWORKAREA
    work_area = ctypes.wintypes.RECT()
    ctypes.windll.user32.SystemParametersInfoW(0x0030, 0, ctypes.byref(work_area), 0)
    taskbar_height = screen_height - work_area.bottom

    # 计算右半边窗口的宽度和高度，减去任务栏高度
    right_half_width = screen_width // 2
    right_half_height = screen_height - taskbar_height

    # 调整Excel窗口大小和位置，移动到右半边
    app_window.top_window().move_window(x=screen_width - right_half_width, y=0, width=right_half_width, height=right_half_height)
def get_image_path(filename):
    """根据文件名获取图片路径，无论是否被打包"""
    # 如果被 PyInstaller 打包
    if getattr(sys, 'frozen', False):
        base_path = sys._MEIPASS  # 打包后的临时路径
    else:
        base_path = os.path.dirname(os.path.abspath(__file__))  # 开发时路径

    return os.path.join(base_path, 'static', filename)
def 业务日期位置查询():
    global 业务日期位置,debug
    screenshot_path = screenshot()  # 截取屏幕

    if debug == 1:
        image_path =r"F:\xu\code\pycharm2\pythonProject1\main_dir\blueprints\qian_zi\h.png"
    else:
        image_path = get_image_path('h.png')
    #image_path = get_image_path('h.png')
    业务日期 = find_image_position(screenshot_path, image_path,0.8)
    if 业务日期:
        corrected_positions = [(x - 40, y + 10) for x, y in 业务日期]
        业务日期位置=corrected_positions[0]
        print("业务日期位置查询到")
        print(业务日期位置)
    else:
        print("业务日期位置查询不到")
        业务日期位置=None
    return 业务日期位置
def read_可签字去重表(shen_he_file_path):
    app = xlwings.App(visible=False, add_book=False)  # 创建一个不可见的 Excel 应用程序实例
    wb = app.books.open(shen_he_file_path, update_links=False)  # 打开工作簿
    sht = wb.sheets["可签字去重单据号"]  # 替换为你要复制的工作表名称
    last_row = sht.range(sht.cells.last_cell.row, 1).end('up').row
    data = sht.range((1, 1), (last_row, 4)).value  # 一次性读取前30行和30列的数据
    wb.close()  # 关闭工作簿
    app.quit()  # 退出应用程序
    return data

def screenshot():
    screenshot = ImageGrab.grab()# 截取屏幕并保存为 screenshot.png
    screenshot.save("screenshot.png")
    return "screenshot.png"

def find_image_position(screenshot_path, template_path,threshold):
    # 读取截图和模板图像
    screenshot = cv2.imread(screenshot_path)
    template = cv2.imread(template_path)
    h, w, _ = template.shape
    result = cv2.matchTemplate(screenshot, template, cv2.TM_CCOEFF_NORMED)
    #threshold = 0.8  # 设置阈值
    yloc, xloc = np.where(result >= threshold)
    return [(x, y) for (x, y) in zip(xloc, yloc)]

def show_alert():
    # 创建主窗口
    root = tk.Tk()
    root.withdraw()  # 隐藏主窗口
    root.attributes("-topmost", True)  # 设置窗口为置顶模式
    messagebox.showinfo("Alert", "程序已停止")
    root.destroy()  # 关闭窗口

# 定义一个例外类，用于在线程中抛出
class ThreadTerminationException(Exception):
    pass

def terminate_thread(thread):
    # 使用 ctypes 在线程中抛出异常
    if not thread.is_alive():
        return
    thread_id = ctypes.pythonapi.PyThreadState_SetAsyncExc(
        ctypes.c_long(thread.ident),
        ctypes.py_object(ThreadTerminationException)
    )
    if thread_id == 0:
        raise ValueError("Invalid thread ID")
    elif thread_id > 1:
        ctypes.pythonapi.PyThreadState_SetAsyncExc(thread.ident, None)
        raise SystemError("Failed to stop thread")

def on_esc_pressed(thread):
    print("ESC pressed. Terminating thread...")
    terminate_thread(thread)
def click_position(position):
    time.sleep(0.5)  # 等待一小段时间
    mouse.click(coords=position)  # 使用 pywinauto 模拟点击指定的坐标

def run_program(shen_he_file_path,出库类型):

    try:
        签字_1(shen_he_file_path, 出库类型)
    except ThreadTerminationException:
        print("except: 签字_1(shen_he_file_path, 出库类型)Thread was terminated.")

def 签字_1(shen_he_file_path, 出库类型):
    app = xlwings.App(visible=True, add_book=False)  # 创建一个不可见的 Excel 应用程序实例]
    set_excel_window_right_half(app)

    try:
        # 启动或连接到 Yonyou UClient
        app2 = Application().connect(title='Yonyou UClient')  # 如果已运行，连接到它
        # 访问窗口
        window = app2.window(title='Yonyou UClient')

        # 检查窗口是否最小化，如果是则恢复
        if window.is_minimized():
            window.restore()  # 恢复窗口

        # 将窗口置顶
        window.set_focus()  # 设置焦点

        # 获取屏幕的宽度和高度
        screen_width = ctypes.windll.user32.GetSystemMetrics(0)
        screen_height = ctypes.windll.user32.GetSystemMetrics(1)

        # 获取任务栏的高度
        work_area = ctypes.wintypes.RECT()
        ctypes.windll.user32.SystemParametersInfoW(0x0030, 0, ctypes.byref(work_area), 0)
        taskbar_height = screen_height - work_area.bottom

        # 计算左半边窗口的宽度和高度，减去任务栏高度
        left_half_width = screen_width // 2
        left_half_height = screen_height - taskbar_height

        # 将窗口移动到左半边并调整大小
        window.move_window(x=0, y=0, width=left_half_width, height=left_half_height)
        time.sleep(1)




    except:
        print("except window = app.window(title='Yonyou UClient')")
        pass

    print("b")
    print(shen_he_file_path)
    wb = app.books.open(shen_he_file_path, update_links=False)  # 打开工作簿
    print("c")
    sheet = wb.sheets["可签字去重单据号"]
    sheet.activate()
    print("d")
    data_list = read_可签字去重表(shen_he_file_path)
    print("e")
    for i in range(len(data_list)):
        if data_list[i][1] == 出库类型:
            print(data_list[i][0], data_list[i][1])
            if data_list[i][3]!=None and data_list[i][3]!="":
                continue

            return_data = 签字_2(data_list[i])
            if return_data["签字状态"]=="成功":
                print(" sheet.range(i + 1, 4).select()")
                sheet.api.Rows(i + 1).Select()  # 选择第 1 行
                print(" sheet.range(i + 1, 4).select()")
                sheet.range(i+1, 4).value = "已签字"
                print(" sheet.range(i+1, 4).value =已签字")
            if return_data["签字状态"] == "失败":
                sheet.range(i + 1, 4).value = "签字失败"
                print("签字状态失败")
                #show_alert()
                print(" show_alert()")
                #os._exit(0)  # 强制终止整个进程
                print(" os._exit(0)  # 强制终止整个进程")

def 签字完成位置查询():
    global debug
    screenshot_path = screenshot()  # 截取屏幕
    if debug==1:
        image_path=r"F:\xu\code\pycharm2\pythonProject1\main_dir\blueprints\qian_zi\f.png"
    else:
        image_path = get_image_path('f.png')

    签字完成 = find_image_position(screenshot_path, image_path,0.9)
    if 签字完成:
        corrected_positions = [(x + 20, y + 10) for x, y in 签字完成]
        签字完成位置=corrected_positions[0]
        print("签字完成位置查询到")
        print(签字完成位置)
    else:
        print(" 签字完成位置 查询不到")
        签字完成位置=None
    print("return 签字完成位置")
    return 签字完成位置
def 签字_2(data_list):
    return_data={"签字状态":"失败"}

    global 业务日期位置
    sleeptile=0.2
    # 模拟按下 F3 键
    keyboard.press_and_release('F3')
    time.sleep(2)
    pyperclip.copy("010108,01011402")
    my_str ="010108,01011402"
    for char in my_str:
        #keyboard.send(char)
        #time.sleep(0.05)  # 确保每个字符间有足够的时间间隔
        pass

    kb.send_keys('^v')

    time.sleep(sleeptile)
    #kb.send_keys('{TAB}')
    keyboard.press_and_release('enter')  # 模拟按下 Enter 键
    time.sleep(sleeptile)
    kb.send_keys('{TAB}')
    time.sleep(sleeptile)
    pyperclip.copy("上月")
    time.sleep(sleeptile)
    kb.send_keys('^v')
    time.sleep(sleeptile)
    for _ in range(7):  # 发送多个 Tab 键
        kb.send_keys('{TAB}')
        time.sleep(sleeptile)
    print("粘贴板数据")
    print(data_list[0])
    print(data_list[1])
    pyperclip.copy(data_list[0])
    time.sleep(sleeptile)
    kb.send_keys('^v')
    time.sleep(sleeptile)
    keyboard.press_and_release('alt+y')
    time.sleep(0.5)
    if 业务日期位置 == None:
        业务日期位置=业务日期位置查询()
    #print(业务日期位置)
    if 业务日期位置!=None:
        click_position(业务日期位置)
        time.sleep(sleeptile)
        kb.send_keys('+{TAB}')
        time.sleep(sleeptile)

        date_str = data_list[2].strftime('%Y-%m-%d')
        #pyperclip.copy(date_str)

        #kb.send_keys('^v')
        #time.sleep(sleeptile)

        # 模拟键盘打字 data_list[2]="2024-09-10"
        try:
            date_str = data_list[2].strftime('%Y-%m-%d')
            for char in date_str:
                keyboard.send(char)
                time.sleep(0.1)  # 确保每个字符间有足够的时间间隔
                #print("try")
        except:
            for char in data_list[2]:
                keyboard.send(char)
                time.sleep(0.1)  # 确保每个字符间有足够的时间间隔
                #print("except")

        # 模拟键盘打字 data_list[2]="2024-09-10"

        time.sleep(sleeptile)
        # 模拟按下 Enter 键
        keyboard.press_and_release('enter')
        time.sleep(0.2)

        keyboard.press_and_release('enter')# 模拟按下 Enter 键
        time.sleep(0.3)
        keyboard.press_and_release('ctrl+g')
        ##回调
        签字完成flag=0
        for i in range(0,50):
            if 签字完成位置查询():#签字成功
                签字完成flag=1
                return_data["签字状态"]="成功"
                print("return_data[签字状态成功")
                break
            else:#签字失败
                keyboard.press_and_release('ctrl+g')
                time.sleep(0.1)
        if 签字完成flag==1:
            print("签字完成flag==1:")
            return return_data
        if 签字完成flag==0:
            print("签字完成flag==0:")
            return return_data
    else:
        print("找不到业务日期")
        return return_data

def qian_zi_main(审核文件路径,出库类型):
    print("按下 Ctrl+Q 开始程序...")
    keyboard.wait('ctrl+q')


    thread = threading.Thread(target=run_program,args=(审核文件路径, 出库类型)) # 创建并启动线程
    keyboard.add_hotkey('esc', lambda: on_esc_pressed(thread)) # 设置全局监听 ESC 键的事件处理
    thread.start()
    thread.join() # 等待线程结束

    print("程序已终止.")
    show_alert()  # 直接调用显示警告
def qian_zi_main_2(审核文件路径, 出库类型):

    thread = threading.Thread(target=run_program, args=(审核文件路径, 出库类型))  # 创建并启动线程
    keyboard.add_hotkey('esc', lambda: on_esc_pressed(thread))  # 设置全局监听 ESC 键的事件处理
    thread.start()
    thread.join()  # 等待线程结束

    print("程序已终止.")
    show_alert()  # 直接调用显示警告

审核文件路径 = r"D:\Desktop\副本材料出库单列表ONC0909 - 副本.xls"
出库类型 = "印尼办公及长期资产领用材料出库"
出库类型="印尼生产领用材料出库"
if 0:
    qian_zi_main(审核文件路径,出库类型)



