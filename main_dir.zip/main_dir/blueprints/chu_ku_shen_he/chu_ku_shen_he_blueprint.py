# 创建一个蓝图实例
import tkinter
from tkinter import filedialog
import tkinter as tk
from flask import Blueprint, render_template, jsonify, request

from blueprints.chu_ku_shen_he.chu_ku_shen_he_5 import start_shen_he


def open_file_dialog():
    file_path = ""
    dialog = tkinter.Toplevel()  # 创建对话窗口
    dialog.withdraw()  # 隐藏对话窗口
    dialog.geometry("300x150")
    dialog.attributes("-topmost", True)  # 设置对话窗口为置顶
    def on_file_select():  # 文件选择功能
        file_path = filedialog.askopenfilename(parent=dialog, title="Select a file")
        if file_path:
            print(f"Selected file: {file_path}")
        dialog.destroy()  # 关闭对话窗口
        return file_path
    file_path = on_file_select()
    return file_path
def open_folder_dialog():
    file_path = ""
    dialog = tkinter.Tk()  # 创建主窗口
    dialog.withdraw()  # 隐藏主窗口
    dialog.geometry("300x150")
    dialog.attributes("-topmost", True)  # 设置对话窗口为置顶

    def on_file_select():  # 文件选择功能
        nonlocal file_path
        file_path = filedialog.askdirectory(parent=dialog, title="Select a folder")
        if file_path:
            print(f"Selected file: {file_path}")
        dialog.destroy()  # 关闭对话窗口

    dialog.after(0, on_file_select)  # 将文件选择功能放到事件循环中
    dialog.mainloop()  # 开始事件循环
    return file_path

chu_ku_shen_he_blueprint = Blueprint('chu_ku_shen_he_blueprint', __name__)
@chu_ku_shen_he_blueprint.route("/chu_ku_shen_he")
def chu_ku_shen_he():
    return render_template("chu_ku_shen_he/home.html")


file_path=""
rule_list=""
@chu_ku_shen_he_blueprint.route("/chu_ku_shen_he_upload",methods=["post"])
def chu_ku_shen_he_upload():
    global file_path
    global rule_list
    return_json= {'status': 'success'}
    if request.method == 'POST':
        data = request.get_json()
        my_type=data["my_type"]
        if my_type=="upload_path":
            file_path = open_file_dialog()
            rule_list=data["checkbox"]
            return_json["file_path"]=file_path
        if my_type == "upload_path_2":
            if file_path == "":
                # 没有选择文件
                print("空文件，不执行")
            else:
                rule_list = data["checkbox"]
                start_shen_he(file_path,rule_list)
    return jsonify(return_json)