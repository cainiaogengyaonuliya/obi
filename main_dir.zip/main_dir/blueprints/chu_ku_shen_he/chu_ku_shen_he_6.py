# -*- coding: utf-8 -*-
import xlwings

import ctypes

from pywinauto import Application
class ROW_INSPECT:
    库存组织=""
    def __init__(self, data_row_json):
        self.库存组织 = data_row_json["库存组织"]  # 实例变量 name
        self.单据状态 = data_row_json["单据状态"]  # 实例变量 name
        self.单据日期 = data_row_json["单据状态"]  # 实例变量 name
        self.出库日期 = data_row_json["单据状态"]  # 实例变量 name
        self.仓库 = data_row_json["单据状态"]  # 实例变量 name
        self.出入库类型 = data_row_json["单据状态"]  # 实例变量 name
        self.领料部门 = data_row_json["单据状态"]  # 实例变量 name
        self.承包商 = data_row_json["单据状态"]  # 实例变量 name
        self.物料名称 = data_row_json["单据状态"]  # 实例变量 name
        self.物料基本分类 = data_row_json["单据状态"]  # 实例变量 name
        self.项目号 = data_row_json["单据状态"]  # 实例变量 name
        self.实际项目号 = data_row_json["单据状态"]  # 实例变量 name
        self.实际项目名称 = data_row_json["单据状态"]  # 实例变量 name
        self.存货分类 = data_row_json["单据状态"]  # 实例变量 name
        self.收支项目 = data_row_json["单据状态"]  # 实例变量 name
        self.生产线 = data_row_json["单据状态"]  # 实例变量 name
        self.使用位置 = data_row_json["单据状态"]  # 实例变量 name
        self.销售单价 = data_row_json["单据状态"]  # 实例变量 name

