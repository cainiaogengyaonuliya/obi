from flask import Blueprint, render_template

production_data_progress_blueprint = Blueprint('production_data_progress_blueprint', __name__)

@production_data_progress_blueprint.route("/production_data_progress")
def production_data_progress_1():
    return render_template("production_data_progress/home.html")