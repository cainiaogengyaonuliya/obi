def pdf_convert(source_file_path):#如果是pdf文件，那么转成excel文件，返回excel文件路径，参数是pdf文件路径
    file_extension = source_file_path.split(".")[-1]
    file_name=source_file_path.split("\\")[-1]
    file_name_no_extension=file_name[0:-(len(file_extension)+1)]#2024.9.6褐铁矿质量证明书
    #print(file_name_no_extension)
    #print(file_name)
    source_folder= source_file_path[0:-(len(file_name) + 1)]  # 去除后缀名#D:\Desktop\新建文件夹 (3)
    converted_excel_path=source_folder+"\\转换后excel\\"+file_name_no_extension+".xlsx"
    if file_extension == "pdf":
        print("source file is pdf  ||  file:converting...........")
        #pdf_to_excel(source_file_path, converted_excel_path)
        source_file_path = converted_excel_path
    return source_file_path

source_file_path=r"D:\Desktop\新建文件夹 (3)\2024.9.6褐铁矿质量证明书.pdf"
a=pdf_convert(source_file_path)
print(a)