import ctypes
import os
import re
import shutil
import time
from datetime import datetime

import pdfplumber
import xlwings
from dateutil import parser
from openpyxl.reader.excel import load_workbook
from openpyxl.workbook import Workbook
from pywinauto import Application

def border_color(range,color_p,sht):


    #sht.range(range).api.HorizontalAlignment = -4108

    # 添加所有框线
    range.api.Borders(xlwings.constants.BordersIndex.xlEdgeBottom).LineStyle = xlwings.constants.LineStyle.xlContinuous
    range.api.Borders(xlwings.constants.BordersIndex.xlEdgeTop).LineStyle = xlwings.constants.LineStyle.xlContinuous
    range.api.Borders(xlwings.constants.BordersIndex.xlEdgeLeft).LineStyle = xlwings.constants.LineStyle.xlContinuous
    range.api.Borders(xlwings.constants.BordersIndex.xlEdgeRight).LineStyle = xlwings.constants.LineStyle.xlContinuous
    range.api.Borders(xlwings.constants.BordersIndex.xlInsideVertical).LineStyle = xlwings.constants.LineStyle.xlContinuous
    range.api.Borders(xlwings.constants.BordersIndex.xlInsideHorizontal).LineStyle = xlwings.constants.LineStyle.xlContinuous
    range.api.Borders(xlwings.constants.BordersIndex.xlEdgeBottom).Weight =2
    range.api.Borders(xlwings.constants.BordersIndex.xlEdgeTop).Weight = 2
    range.api.Borders(xlwings.constants.BordersIndex.xlEdgeLeft).Weight = 2
    range.api.Borders(xlwings.constants.BordersIndex.xlEdgeRight).Weight = 2
    range.api.Borders(xlwings.constants.BordersIndex.xlInsideVertical).Weight =2
    range.api.Borders(xlwings.constants.BordersIndex.xlInsideHorizontal).Weight = 2

    range.api.Borders(xlwings.constants.BordersIndex.xlEdgeBottom).Color = xlwings.utils.rgb_to_int((0, 0, 0))  # 黑色
    range.api.Borders(xlwings.constants.BordersIndex.xlEdgeTop).Color = xlwings.utils.rgb_to_int((0, 0, 0))  # 黑色
    range.api.Borders(xlwings.constants.BordersIndex.xlEdgeLeft).Color = xlwings.utils.rgb_to_int((0, 0, 0))  # 黑色
    range.api.Borders(xlwings.constants.BordersIndex.xlEdgeRight).Color =xlwings.utils.rgb_to_int((0, 0, 0))  # 黑色
    range.api.Borders(xlwings.constants.BordersIndex.xlInsideVertical).Color = xlwings.utils.rgb_to_int((0, 0, 0))  # 黑色
    range.api.Borders(xlwings.constants.BordersIndex.xlInsideHorizontal).Color = xlwings.utils.rgb_to_int((0, 0, 0))  # 黑色
def set_excel_window_right_half(app):
    # 获取Excel应用程序窗口句柄
    excel_hwnd = app.api.Hwnd

    # 使用pywinauto连接到Excel窗口
    app_window = Application().connect(handle=excel_hwnd)

    # 设置Excel窗口置顶
    app_window.top_window().set_focus()
    ctypes.windll.user32.SetWindowPos(excel_hwnd, -1, 0, 0, 0, 0, 0x0001)  # -1 表示置顶

    # 获取屏幕的宽度和高度
    screen_width = ctypes.windll.user32.GetSystemMetrics(0)
    screen_height = ctypes.windll.user32.GetSystemMetrics(1)

    # 获取任务栏的高度
    taskbar_info = ctypes.windll.user32.SystemParametersInfoW(0x0030, 0, 0, 0)  # SPI_GETWORKAREA
    work_area = ctypes.wintypes.RECT()
    ctypes.windll.user32.SystemParametersInfoW(0x0030, 0, ctypes.byref(work_area), 0)
    taskbar_height = screen_height - work_area.bottom

    # 计算右半边窗口的宽度和高度，减去任务栏高度
    right_half_width = screen_width // 2
    right_half_height = screen_height - taskbar_height

    # 调整Excel窗口大小和位置，移动到右半边
    app_window.top_window().move_window(x=screen_width - right_half_width, y=0, width=right_half_width, height=right_half_height)
def set_excel_window_left_half(app):
    # 获取Excel应用程序窗口句柄
    excel_hwnd = app.api.Hwnd

    # 使用pywinauto连接到Excel窗口
    app_window = Application().connect(handle=excel_hwnd)

    # 设置Excel窗口置顶
    app_window.top_window().set_focus()
    ctypes.windll.user32.SetWindowPos(excel_hwnd, -1, 0, 0, 0, 0, 0x0001)  # -1 表示置顶

    # 获取屏幕的宽度和高度
    screen_width = ctypes.windll.user32.GetSystemMetrics(0)
    screen_height = ctypes.windll.user32.GetSystemMetrics(1)

    # 获取任务栏的高度
    taskbar_info = ctypes.windll.user32.SystemParametersInfoW(0x0030, 0, 0, 0)  # SPI_GETWORKAREA
    work_area = ctypes.wintypes.RECT()
    ctypes.windll.user32.SystemParametersInfoW(0x0030, 0, ctypes.byref(work_area), 0)
    taskbar_height = screen_height - work_area.bottom

    # 计算右半边窗口的宽度和高度，减去任务栏高度
    right_half_width = screen_width // 2
    right_half_height = screen_height - taskbar_height

    # 调整Excel窗口大小和位置，移动到右半边
    app_window.top_window().move_window(x=0, y=0, width=right_half_width, height=right_half_height)
def read_mhp(mhp_path):
    return_data = {"是否为标准文件": "是", "data": []}
    app = xlwings.App(visible=False, add_book=False)  # 创建一个不可见的 Excel 应用程序实例
    sheet = app.books.open(mhp_path,update_links=False).sheets[0]
    data = sheet.range('A1:AD30').value # 一次性读取前30行和30列的数据，减少I/O操作
    ri_qi_row = ri_qi_col=0
    for row in range(0, len(data)):
        if "日期" in data[row]:
            ri_qi_row, ri_qi_col = row + 1, data[row].index("日期") + 1
    if ri_qi_row==0 or ri_qi_col==0:
        return_data["是否为标准文件"] = "日期坐标无法定位，非标准文件"
        app.quit()
        return return_data
    ri_qi = data[ri_qi_row][ri_qi_col - 1]
    headers = data[ri_qi_row - 1]  # 定位其他列
    try:
        ban_ci_col = headers.index("班次")+1
        pi_hao_col = headers.index("批号")+1
        bao_shu_col = headers.index("包数")+1
        ban_ci_jing_zhong_col = next(i for i, v in enumerate(headers) if v and v.startswith("班次净重量"))+1
    except ValueError:
        return_data["是否为标准文件"] = "列名定位失败，非标准文件"
        app.quit()
        return return_data
    last_row = len(data)   # last_row = sheet.range(sheet.cells.last_cell.row, ban_ci_col).end('up').row
    for row in range(ri_qi_row , last_row ):  # 多10行的判断， 以if ban_ci!="白班" and ban_ci!="夜班":结束
        ban_ci = data[row][ban_ci_col-1]
        if ban_ci not in ["白班", "夜班"]:
            break
        return_data["data"].append({
            "ri_qi":ri_qi,"ban_ci":ban_ci,"pi_hao":data[row][pi_hao_col-1],
            "bao_shu":data[row][bao_shu_col-1],"ban_ci_jing_zhong":data[row][ban_ci_jing_zhong_col-1]})
    app.quit()  # 退出应用程序
    return return_data
def read_mhp_quality(mhp_quality_path):
    print("读取文件中......")
    return_data = {"是否为标准文件": "是", "data": []}
    app = xlwings.App(visible=False, add_book=False)  # 创建一个不可见的 Excel 应用程序实例

    sheet = app.books.open(mhp_quality_path, update_links=False).sheets[0]
    data = sheet.range('A1:AK40').value  # 一次性读取前30行和30列的数据，减少I/O操作
    pi_hao_row = pi_hao_col = 0
    for row in range(0, len(data)):
        for col in range(0,len(data[0])):
            cell_value = data[row][col]
            if isinstance(cell_value, str) and cell_value.startswith("Batch"):
                pi_hao_row, pi_hao_col = row + 1, col + 1
                break
    #(pi_hao_row,pi_hao_col)
    if pi_hao_row==0 or pi_hao_col==0:
        return_data["是否为标准文件"] = "日期坐标无法定位，非标准文件"
        app.quit()
        return return_data
    Ni_col=Co_col=Fe_col=Al_col=Cr_col=Mn_col=Mg_col=Si_col=S_col=H2O_col=0
    for row in range(0, len(data)):
        for col in range(0, len(data[0])):
            cell_value = data[row][col]
            if isinstance(cell_value, str) and cell_value.startswith("Ni"):
                Ni_col=col+1
            if isinstance(cell_value, str) and cell_value.startswith("Co"):
                Co_col=col+1
            if isinstance(cell_value, str) and cell_value.startswith("Fe"):
                Fe_col=col+1
            if isinstance(cell_value, str) and cell_value.startswith("Al"):
                Al_col=col+1
            if isinstance(cell_value, str) and cell_value.startswith("Cr"):
                Cr_col=col+1
            if isinstance(cell_value, str) and cell_value.startswith("Mn"):
                Mn_col=col+1
            if isinstance(cell_value, str) and cell_value.startswith("Mg"):
                Mg_col=col+1
            if isinstance(cell_value, str) and cell_value.startswith("Si"):
                Si_col=col+1
            if isinstance(cell_value, str) and cell_value.split('\n')=="S":
                S_col=col+1
            if isinstance(cell_value, str) and cell_value.startswith("Moisture"):
                H2O_col=col+1
        #print(row+1,col+1)
        #print(Ni,Co,Fe,Al,Cr,Mn,Mg,Si,S,H2O)
        if  Ni_col==0 or Co_col==0 or Fe_col==0 or Al_col==0 or Cr_col==0 or Mn_col==0 or Mg_col==0 or Si_col==0 or S_col==0 or H2O_col==0:
            Ni_col = Co_col = Fe_col = Al_col = Cr_col = Mn_col = Mg_col = Si_col = S_col = H2O_col = 0
        else:
            print("定位成功,列名定位结果")
            print(Ni_col, Co_col, Fe_col, Al_col, Cr_col, Mn_col, Mg_col, Si_col, S_col, H2O_col)
            break
    if Ni_col == 0 or Co_col == 0 or Fe_col == 0 or Al_col == 0 or Cr_col == 0 or Mn_col == 0 or Mg_col == 0 or Si_col == 0 or S_col == 0 or H2O_col == 0:
        return_data["是否为标准文件"] = "列名定位失败，非标准文件"
        app.quit()
        return return_data
    last_row = len(data)  # last_row = sheet.range(sheet.cells.last_cell.row, ban_ci_col).end('up').row
    pattern = re.compile(r'^[DN]\d{8}$')
    for row in range(0,len(data)):
        cell_value = data[row][pi_hao_col-1]
        #print(cell_value)
        if isinstance(cell_value, str) and pattern.match(cell_value):#print(f"匹配成功: {cell_value}")
            pi_hao=cell_value
            return_data["data"].append({
                "pi_hao": pi_hao, "Ni":data[row][Ni_col-1],"Co":data[row][Co_col-1],"Fe":data[row][Fe_col-1],"Al":data[row][Al_col-1],
                "Cr": data[row][Cr_col - 1], "Mn": data[row][Mn_col - 1], "Mg": data[row][Mg_col - 1], "Si": data[row][Si_col - 1],
                "S": data[row][S_col - 1], "H2O": data[row][H2O_col - 1],
            })
        else:# print("不匹配或不是字符串")
           pass
    #print(return_data)
    print("读取成功")
    app.quit()  # 退出应用程序
    return return_data
def read_niso4_quality(quality_path):
    print("读取文件中......")
    return_data = {"是否为标准文件": "是", "data": []}
    app = xlwings.App(visible=False, add_book=False)  # 创建一个不可见的 Excel 应用程序实例
    sheet = app.books.open(quality_path, update_links=False).sheets[0]
    data = sheet.range('A1:AM40').value  # 一次性读取前30行和30列的数据，减少I/O操作
    指标_row = 指标_col = 0
    for row in range(0, len(data)):
        for col in range(0,len(data[0])):
            cell_value = data[row][col]
            if isinstance(cell_value, str) and cell_value.startswith("指标值"):
                指标_row, 指标_col = row + 1, col + 1
                break
    if 指标_row==0 or 指标_col==0:
        return_data["是否为标准文件"] = "日期坐标无法定位，非标准文件"
        app.quit()
        return return_data
    包数_col=净重_col=0
    for row in range(0,len(data)):
        for col in range(0, len(data[0])):
            cell_value = data[row][col]
            if isinstance(cell_value, str) and cell_value.startswith("包数"):
                包数_col=col+1
            if isinstance(cell_value, str) and cell_value.startswith("净重"):
                净重_col=col+1
        if 包数_col==0 or 净重_col==0:
            包数_col = 净重_col = 0
        else:
            break
    if 包数_col == 0 or 净重_col == 0:
        return_data["是否为标准文件"] = "包数_col列名定位失败，非标准文件"
        app.quit()
        return return_data

    Ni_col=Co_col=Mg_col=Na_col=H2O_col=Ci_col=备注_col=0
    for row in range(0, len(data)):
        for col in range(0, len(data[0])):
            cell_value = data[row][col]
            if isinstance(cell_value, str) and cell_value.startswith("Ni"):
                Ni_col=col+1
            if isinstance(cell_value, str) and cell_value.startswith("Co"):
                Co_col=col+1
            if isinstance(cell_value, str) and cell_value.startswith("Mg"):
                Mg_col=col+1
            if isinstance(cell_value, str) and cell_value.startswith("Na"):
                Na_col=col+1
            if isinstance(cell_value, str) and cell_value.startswith("磁性异物"):
                Ci_col=col+1
            if isinstance(cell_value, str) and cell_value.startswith("水不溶物"):
                H2O_col=col+1
            if isinstance(cell_value, str) and cell_value.startswith("备注"):
                备注_col = col + 1

        if  Ni_col==0 or Co_col==0 or Mg_col==0 or Na_col==0 or H2O_col==0 or Ci_col==0 or 备注_col==0:
            Ni_col=Co_col=Mg_col=Na_col=H2O_col=Ci_col=备注_col=0
        else:
            print("定位成功")
            break
    if Ni_col == 0 or Co_col == 0 or Mg_col == 0 or Na_col == 0 or H2O_col == 0 or Ci_col == 0 or 备注_col==0:
        return_data["是否为标准文件"] = "列名定位失败，非标准文件"
        app.quit()
        return return_data

    pattern = re.compile(r'^[A-Za-z]{3}\d{8}-\d$')
    for row in range(0,len(data)):
        cell_value = data[row][指标_col-1]
        if isinstance(cell_value, str) and pattern.match(cell_value):#print(f"匹配成功: {cell_value}")
            pi_hao=cell_value
            return_data["data"].append({
                "pi_ci": pi_hao, "包数":data[row][包数_col-1],"净重":data[row][净重_col-1],"Ni":data[row][Ni_col-1],"Co":data[row][Co_col-1],
                "Mg": data[row][Mg_col - 1], "Na": data[row][Na_col - 1], "H2O": data[row][H2O_col - 1], "Ci": data[row][Ci_col - 1],
                "备注": data[row][备注_col - 1]
            })
        else:# print("不匹配或不是字符串")
           pass
    print("读取成功")
    app.quit()  # 退出应用程序
    return return_data
def read_电解钴_quality(电解钴质量路径):
    print("读取文件中......")
    return_data = {"是否为标准文件": "是", "data": []}
    app = xlwings.App(visible=False, add_book=False)  # 创建一个不可见的 Excel 应用程序实例
    sheet = app.books.open(电解钴质量路径, update_links=False).sheets[0]
    data = sheet.range('A1:AN100').value  # 一次性读取前30行和30列的数据，减少I/O操作
    标记_行=标记_列=0
    for row in range(0, len(data)):
        for col in range(0, len(data[0])):
            cell_value = data[row][col]
            if isinstance(cell_value, str) and cell_value.startswith("Sample Id"):
                标记_行 =row+1
                标记_列=col+1
    if 标记_行==0 or 标记_列==0:
        return_data["是否为标准文件"] = "标记_行坐标无法定位，非标准文件"
        app.quit()
        return return_data
    Co_col=Fe_col=Al_col=Mn_col=Mg_col=Zn_col=Cu_col=Si_col=S_col=P_col=Cd_col=Pb_col=C_col=As_col=Sb_col=Sn_col=Bi_col=Ni_col=0
    for row in range(0, len(data)):
        for col in range(0, len(data[0])):
            cell_value = data[row][col]
            if isinstance(cell_value, str) and cell_value.startswith("Co"):
                Co_col = col + 1
            if isinstance(cell_value, str) and cell_value.startswith("Fe"):
                Fe_col = col + 1
            if isinstance(cell_value, str) and cell_value.startswith("Al"):
                Al_col = col + 1
            if isinstance(cell_value, str) and cell_value.startswith("Mn"):
                Mn_col = col + 1
            if isinstance(cell_value, str) and cell_value.startswith("Mg"):
                Mg_col = col + 1
            if isinstance(cell_value, str) and cell_value.startswith("Zn"):
                Zn_col = col + 1
            if isinstance(cell_value, str) and cell_value.startswith("Cu"):
                Cu_col = col + 1
            if isinstance(cell_value, str) and cell_value.startswith("Si"):
                Si_col = col + 1
            if isinstance(cell_value, str) and cell_value.split('\n')[0]=="S":
                S_col = col + 1
            if isinstance(cell_value, str) and cell_value.split('\n')[0]=="P":
                P_col = col + 1
            if isinstance(cell_value, str) and cell_value.startswith("Cd"):
                Cd_col = col + 1
            if isinstance(cell_value, str) and cell_value.startswith("Pb"):
                Pb_col = col + 1
            if isinstance(cell_value, str) and cell_value.split('\n')[0]=="C":
                C_col = col + 1
            if isinstance(cell_value, str) and cell_value.startswith("As"):
                As_col = col + 1
            if isinstance(cell_value, str) and cell_value.startswith("Sb"):
                Sb_col = col + 1
            if isinstance(cell_value, str) and cell_value.startswith("Sn"):
                Sn_col = col + 1
            if isinstance(cell_value, str) and cell_value.startswith("Bi"):
                Bi_col = col + 1
            if isinstance(cell_value, str) and cell_value.startswith("Ni"):
                Ni_col = col + 1
        if Co_col==0 or Fe_col==0 or Al_col==0 or Mn_col==0 or Mg_col==0 or Zn_col==0 or Cu_col==0 or Si_col==0 or S_col==0 or P_col==0 or Cd_col==0 or Pb_col==0 or C_col==0 or As_col==0 or Sb_col==0 or Sn_col==0 or Bi_col==0 or Ni_col==0:
            Co_col = Fe_col = Al_col = Mn_col = Mg_col = Zn_col = Cu_col = Si_col = S_col = P_col = Cd_col = Pb_col = C_col = As_col = Sb_col = Sn_col = Bi_col = Ni_col = 0
        else:
            print("定位成功")
            break
    if Co_col == 0 or Fe_col == 0 or Al_col == 0 or Mn_col == 0 or Mg_col == 0 or Zn_col == 0 or Cu_col == 0 or Si_col == 0 or S_col == 0 or P_col == 0 or Cd_col == 0 or Pb_col == 0 or C_col == 0 or As_col == 0 or Sb_col == 0 or Sn_col == 0 or Bi_col == 0 or Ni_col == 0:
        return_data["是否为标准文件"] = "列名定位失败，非标准文件"
        app.quit()
        return return_data
    NW_row = NW_col = 0#net weight


    for row in range(0, len(data)):
        for col in range(0, len(data[0])):
            cell_value = data[row][col]
            if isinstance(cell_value, str) and cell_value.startswith("NW"):
                NW_row = row + 1
                NW_col=col+1

        if NW_row == 0 or NW_col == 0:
            NW_row = NW_col = 0  # net weight
        else:
            print("NW定位成功")
            break
    if NW_row == 0 or NW_col == 0:
        return_data["是否为标准文件"] = "NW定位列名定位失败，非标准文件"
        app.quit()
        return return_data

    for row in range(0, len(data)):

        cell_value = data[row][标记_列 - 1]
        if not isinstance(cell_value, str):
            continue
        match = re.search(r'\d{8}', cell_value)
        if match:
            return_data["data"].append({

                "Key": data[row][标记_列 - 1],
                "NW": data[row][NW_col - 1],
                "Co": data[row][Co_col - 1],
                "Fe": data[row][Fe_col - 1],
                "Al": data[row][Al_col - 1],
                "Mn": data[row][Mn_col - 1],
                "Mg": data[row][Mg_col - 1],
                "Zn": data[row][Zn_col - 1],
                "Cu": data[row][Cu_col - 1],
                "Si": data[row][Si_col - 1],
                "S": data[row][S_col - 1],
                "P": data[row][P_col - 1],
                "Cd": data[row][Cd_col - 1],
                "Pb": data[row][Pb_col - 1],
                "C": data[row][C_col - 1],
                "As": data[row][As_col - 1],
                "Sb": data[row][Sb_col - 1],
                "Sn": data[row][Sn_col - 1],
                "Bi": data[row][Bi_col - 1],
                "Ni": data[row][Ni_col - 1],
            })
    app.quit()  # 退出应用程序
    print("读取成功")
    return return_data
def read_硫酸钴_quality(硫酸钴质量路径):
    print("读取文件中......")
    return_data = {"是否为标准文件": "是", "data": []}
    app = xlwings.App(visible=False, add_book=False)  # 创建一个不可见的 Excel 应用程序实例
    sheet = app.books.open(硫酸钴质量路径, update_links=False).sheets[0]
    data = sheet.range('A1:AK100').value  # 一次性读取前30行和30列的数据，减少I/O操作
    指标值_行=指标值_列=0
    for row in range(0, len(data)):
        for col in range(0, len(data[0])):
            cell_value = data[row][col]
            if isinstance(cell_value, str) and cell_value.startswith("指标值"):
                指标值_行=row+1
                指标值_列=col+1
                break
    if 指标值_行==0 or 指标值_列==0:
        return_data["是否为标准文件"] = "指标值坐标无法定位，非标准文件"
        app.quit()
        return return_data
    Co_col=Al_col=Ni_col=Fe_col=Cr_col=Mn_col=Mg_col=Zn_col=Ca_col=Cu_col=Si_col=Na_col=Cd_col=Pb_col=油分_col=水不溶物_col=磁性异物_col=备注_col=0
    for row in range(0, len(data)):
        for col in range(0, len(data[0])):
            cell_value = data[row][col]
            if isinstance(cell_value, str) and cell_value.startswith("Co"):
                Co_col = col + 1
            if isinstance(cell_value, str) and cell_value.startswith("Al"):
                Al_col = col + 1
            if isinstance(cell_value, str) and cell_value.startswith("Ni"):
                Ni_col = col + 1
            if isinstance(cell_value, str) and cell_value.startswith("Fe"):
                Fe_col = col + 1
            if isinstance(cell_value, str) and cell_value.startswith("Cr"):
                Cr_col = col + 1
            if isinstance(cell_value, str) and cell_value.startswith("Mn"):
                Mn_col = col + 1
            if isinstance(cell_value, str) and cell_value.startswith("Mg"):
                Mg_col = col + 1
            if isinstance(cell_value, str) and cell_value.startswith("Zn"):
                Zn_col = col + 1
            if isinstance(cell_value, str) and cell_value.startswith("Ca"):
                Ca_col = col + 1
            if isinstance(cell_value, str) and cell_value.startswith("Cu"):
                Cu_col = col + 1
            if isinstance(cell_value, str) and cell_value.startswith("Si"):
                Si_col = col + 1
            if isinstance(cell_value, str) and cell_value.startswith("Na"):
                Na_col = col + 1
            if isinstance(cell_value, str) and cell_value.startswith("Si"):
                Si_col = col + 1
            if isinstance(cell_value, str) and cell_value.startswith("Cd"):
                Cd_col = col + 1
            if isinstance(cell_value, str) and cell_value.startswith("Pb"):
                Pb_col = col + 1
            if isinstance(cell_value, str) and cell_value.startswith("油分"):
                油分_col = col + 1
            if isinstance(cell_value, str) and cell_value.startswith("水不溶物"):
                水不溶物_col = col + 1
            if isinstance(cell_value, str) and cell_value.startswith("磁性异物"):
                磁性异物_col = col + 1
            if isinstance(cell_value, str) and cell_value.startswith("备注"):
                备注_col = col + 1
        if  Co_col==0 or Al_col==0 or Ni_col==0 or Fe_col==0 or Cr_col==0 or Mn_col==0 or Mg_col==0 or Zn_col==0 or Ca_col==0 or Cu_col==0 or Si_col==0 or Na_col==0 or Cd_col==0 or Pb_col==0 or 油分_col==0 or 水不溶物_col==0 or 磁性异物_col==0 or 备注_col==0:
            Co_col = Al_col = Ni_col = Fe_col = Cr_col = Mn_col = Mg_col = Zn_col = Ca_col = Cu_col = Si_col = Na_col = Cd_col = Pb_col = 油分_col = 水不溶物_col = 磁性异物_col = 备注_col = 0
        else:
            print("定位成功")
            break
    if Co_col == 0 or Al_col == 0 or Ni_col == 0 or Fe_col == 0 or Cr_col == 0 or Mn_col == 0 or Mg_col == 0 or Zn_col == 0 or Ca_col == 0 or Cu_col == 0 or Si_col == 0 or Na_col == 0 or Cd_col == 0 or Pb_col == 0 or 油分_col == 0 or 水不溶物_col == 0 or 磁性异物_col == 0 or 备注_col == 0:
        return_data["是否为标准文件"] = "列名定位失败，非标准文件"
        app.quit()
        return return_data

    包数_col=重量_col=0
    for row in range(0, len(data)):
        for col in range(0, len(data[0])):
            cell_value = data[row][col]
            if isinstance(cell_value, str) and cell_value.startswith("包数"):
                包数_col=col + 1
            if isinstance(cell_value, str) and cell_value.startswith("重量"):
                重量_col=col + 1
        if  包数_col==0 or 重量_col==0:
            包数_col = 重量_col = 0
        else:
            print("包数_col = 重量_col = 0定位成功")
            break
    if 包数_col == 0 or 重量_col == 0:
        return_data["是否为标准文件"] = "包数_col = 重量_col列名定位失败，非标准文件"
        app.quit()
        return return_data

    for row in range(0, len(data)):

        cell_value = data[row][指标值_列 - 1]
        if not isinstance(cell_value, str):
            continue
        match = re.search(r'\d{8}', cell_value)
        if match:
            # 提取匹配到的日期字符串
            date_str = match.group()
            # 将日期字符串转换为 datetime 对象
            date_obj = datetime.strptime(date_str, '%Y%m%d')
            # 将 datetime 对象格式化为所需的格式 YYYY-MM-DD
            formatted_date = date_obj.strftime('%Y-%m-%d')
            return_data["data"].append({
                "日期":formatted_date,
                "批号": data[row][指标值_列 - 1],
                "包数": data[row][包数_col - 1], "重量": data[row][重量_col - 1], "Ni": data[row][Ni_col - 1],
                "Co": data[row][Co_col - 1],
                "Mg": data[row][Mg_col - 1], "Na": data[row][Na_col - 1], "水不溶物": data[row][水不溶物_col - 1],
                "磁性异物": data[row][磁性异物_col - 1],
                "备注": data[row][备注_col - 1]
            })
    app.quit()  # 退出应用程序
    print("读取成功")
    return return_data

def read_he_tie_kuang_quality(he_tie_kuang_quality):
    print("读取文件中......")
    return_data = {"是否为标准文件": "是", "data": []}
    app = xlwings.App(visible=False, add_book=False)  # 创建一个不可见的 Excel 应用程序实例
    sheet = app.books.open(he_tie_kuang_quality, update_links=False).sheets[0]
    data = sheet.range('A1:AK40').value  # 一次性读取前30行和30列的数据，减少I/O操作

    yang_pin_bian_hao_row = yang_pin_bian_hao_col = 0
    for row in range(0, len(data)):
        for col in range(0, len(data[0])):
            cell_value = data[row][col]
            if isinstance(cell_value, str) and cell_value.startswith("Nomor Sample"):
                yang_pin_bian_hao_row, yang_pin_bian_hao_col = row + 1, col + 1
                break
    if yang_pin_bian_hao_row == 0 or yang_pin_bian_hao_col == 0:
        return_data["是否为标准文件"] = "日期坐标无法定位，非标准文件"
        app.quit()
        return return_data

    Ni_col = Co_col = Al_col = Mg_col = Fe_col = Cr_col = Mn_col = Si_col = H2O_col = 0

    for row in range(0, len(data)):
        for col in range(0, len(data[0])):
            cell_value = data[row][col]
            if isinstance(cell_value, str) and cell_value.startswith("Nickel"):
                Ni_col=col+1
            if isinstance(cell_value, str) and cell_value.startswith("Cobal"):
                Co_col=col+1
            if isinstance(cell_value, str) and cell_value.startswith("Aluminum"):
                Al_col=col+1
            if isinstance(cell_value, str) and cell_value.startswith("Magnesium"):
                Mg_col=col+1
            if isinstance(cell_value, str) and cell_value.startswith("Iron"):
                Fe_col=col+1
            if isinstance(cell_value, str) and cell_value.startswith("Chromium"):
                Cr_col=col+1
            if isinstance(cell_value, str) and cell_value.startswith("Manganese"):
                Mn_col=col+1
            if isinstance(cell_value, str) and cell_value.startswith("Silicon"):
                Si_col=col+1
            if isinstance(cell_value, str) and cell_value.startswith("Moisture"):
                H2O_col=col+1
        if  Ni_col ==0 or Co_col ==0 or Al_col ==0 or  Mg_col ==0 or  Fe_col ==0 or Cr_col ==0 or Mn_col ==0 or Si_col ==0 or  H2O_col == 0:
            Ni_col = Co_col = Al_col = Mg_col = Fe_col = Cr_col = Mn_col = Si_col = H2O_col = 0
        else:
            print("定位成功")
            print(Ni_col, Co_col, Al_col, Mg_col,Fe_col,Cr_col, Mn_col, Si_col, H2O_col)
            break
    if Ni_col == 0 or Co_col == 0 or Al_col == 0 or Mg_col == 0 or Fe_col == 0 or Cr_col == 0 or Mn_col == 0 or Si_col == 0 or H2O_col == 0:
        return_data["是否为标准文件"] = "列名定位失败，非标准文件"
        app.quit()
        return return_data

    for row in range(0, len(data)):
        cell_value = data[row][yang_pin_bian_hao_col - 1]
        if isinstance(cell_value, str) and cell_value.startswith("截止"):
            break
        if isinstance(cell_value, str):
            return_data["data"].append({
                "yang_pin_bian_hao": data[row][yang_pin_bian_hao_col - 1],
                "Ni": data[row][Ni_col - 1], "Co": data[row][Co_col - 1],"Al":data[row][Al_col-1],"Mg":data[row][Mg_col-1],
                "Fe": data[row][Fe_col - 1], "Cr": data[row][Cr_col - 1], "Mn": data[row][Mn_col - 1],"Si": data[row][Si_col - 1],
                "H2O":data[row][H2O_col - 1]
            })
    app.quit()  # 退出应用程序
    print("读取成功")
    return return_data
def read_he_tie_kuang(he_tie_kuang_path):#褐铁矿数据读取，判断标准文件的两个锚点，日期和合计，
    print("读取中......")
    return_data = {"是否为标准文件": "是", "data": []}
    app = xlwings.App(visible=False, add_book=False)  # 创建一个不可见的 Excel 应用程序实例
    sheet = app.books.open(he_tie_kuang_path, update_links=False).sheets[0]
    data = sheet.range('A1:AD30').value  # 一次性读取前30行和30列的数据，减少I/O操作
    ri_qi_row = ri_qi_col=0
    for row in range(0, len(data)):
        if "日期" in data[row]:
            ri_qi_row, ri_qi_col = row + 1, data[row].index("日期") + 1
    if ri_qi_row==0 or ri_qi_col==0:
        return_data["是否为标准文件"] = "日期坐标无法定位，非标准文件"
        app.quit()
        return return_data
    ri_qi = data[ri_qi_row][ri_qi_col - 1]
    headers = data[ri_qi_row - 1]  # 定位其他列


    try:
        pi_ci_col = headers.index("批次") + 1
        gong_ying_shang_col = headers.index("供应商") + 1
        jing_zhong_col = headers.index("净重（吨）") + 1
    except ValueError:
        return_data["是否为标准文件"] = "列名定位失败，非标准文件"
        app.quit()
        return return_data

    last_row = len(data)  # last_row = sheet.range(sheet.cells.last_cell.row, ban_ci_col).end('up').row
    for row in range(ri_qi_row, last_row):
        pi_ci = data[row][pi_ci_col - 1]
        if pi_ci =="合计":
            break
        return_data["data"].append({
            "ri_qi": ri_qi, "pi_ci": pi_ci, "gong_ying_shang": data[row][gong_ying_shang_col - 1],
            "jing_zhong": data[row][jing_zhong_col - 1]})
    app.quit()  # 退出应用程序
    print("读取完成！")
    return return_data
def read_li_shi(li_shi_path):
    print("读取中......")
    return_data = {"是否为标准文件": "是", "data": []}
    app = xlwings.App(visible=False, add_book=False)  # 创建一个不可见的 Excel 应用程序实例
    sheet = app.books.open(li_shi_path, update_links=False).sheets[0]
    data = sheet.range('A1:AD30').value  # 一次性读取前30行和30列的数据，减少I/O操作
    ri_qi_row = ri_qi_col = 0
    for row in range(0, len(data)):
        if "日期" in data[row]:
            ri_qi_row, ri_qi_col = row + 1, data[row].index("日期") + 1
    if ri_qi_row==0 or ri_qi_col==0:
        return_data["是否为标准文件"] = "日期坐标无法定位，非标准文件"
        app.quit()
        return return_data
    ri_qi = data[ri_qi_row][ri_qi_col - 1]
    headers = data[ri_qi_row - 1]  # 定位其他列
    try:
        ban_ci_col = headers.index("班次") + 1
        guo_bang_wu_pin_col = headers.index("过磅物品") + 1
        jing_zhong_col= next(i for i, v in enumerate(headers) if v and v.startswith("净重")) + 1
    except ValueError:
        return_data["是否为标准文件"] = "列名定位失败，非标准文件"
        app.quit()
        return return_data

    last_row = len(data)  # last_row = sheet.range(sheet.cells.last_cell.row, ban_ci_col).end('up').row
    for row in range(ri_qi_row, last_row):  # 多10行的判断， 以if ban_ci!="白班" and ban_ci!="夜班":结束
        ban_ci = data[row][ban_ci_col - 1]
        if ban_ci not in ["白班", "夜班"]:
            break
        return_data["data"].append({
            "ri_qi": ri_qi, "ban_ci": ban_ci, "guo_bang_wu_pin": data[row][guo_bang_wu_pin_col - 1],
            "jing_zhong": data[row][jing_zhong_col - 1]})
    print("读取完成！")
    app.quit()  # 退出应用程序
    return return_data

def insert_ledger_mhp(ledger_path, sheet_name,return_data):
    print("写入中......")
    app = xlwings.App(visible=True, add_book=False)  # 创建一个不可见的 Excel 应用程序实例
    wb = app.books.open(ledger_path, update_links=False)  # 打开工作簿
    sheet = wb.sheets[sheet_name]
    if sheet is None:  # 检查 sheet 是否为 None
       pass
    sheet.activate()
    set_excel_window_right_half(app)
    last_row = sheet.range(sheet.cells.last_cell.row, 1).end('up').row
    data_list = return_data["data"]
    start_row = last_row + 1  # 调整1位
    # 解析字符串为日期对象
    #date1 = parser.parse(sheet.range(last_row,2).value).date()  # 解析第一个日期
    date1=sheet.range(last_row,2).value.date()
    date2 = parser.parse(data_list[0]["ri_qi"]).date()  # 解析第二个日期
    if date1==date2:
        print("日期相等")
        return
    else:
        print("日期不相等")
        print(sheet.range(last_row,2).value)
        print(data_list[0]["ri_qi"])
    # 可选：如果你想让Excel滚动到该行
    sheet.api.Cells(start_row, 1).Activate()
    for i in range(0, len(data_list)):
        date_obj = datetime.strptime(data_list[i]["ri_qi"], "%Y/%m/%d")
        sheet.range(start_row + i, 1).select()
        sheet.range(start_row + i, 1).value = date_obj.strftime("%Y%m")
        sheet.range(start_row + i, 2).value = data_list[i]["ri_qi"]
        sheet.range(start_row + i, 3).value = data_list[i]["ban_ci"]
        sheet.range(start_row + i, 7).value = data_list[i]["pi_hao"]
        sheet.range(start_row + i, 8).value = data_list[i]["bao_shu"]
        sheet.range(start_row + i, 9).value = data_list[i]["ban_ci_jing_zhong"]

        #sheet.range(start_row + i, 20).formula = sheet.range(start_row + i - 1, 20).formula
        #sheet.range(start_row + i, 21).formula = sheet.range(start_row + i - 1, 21).formula
        #sheet.range(start_row + i, 22).formula = sheet.range(start_row + i - 1, 22).formula

        source_range = sheet.range(start_row + i - 1, 20)
        target_range = sheet.range(start_row + i,20)
        source_range.copy(target_range)  # 复制并粘贴

        source_range = sheet.range(start_row + i - 1, 21)
        target_range = sheet.range(start_row + i, 21)
        source_range.copy(target_range)  # 复制并粘贴

        source_range = sheet.range(start_row + i - 1, 22)
        target_range = sheet.range(start_row + i, 22)
        source_range.copy(target_range)  # 复制并粘贴
    print("写入完成")
    #wb.save()  # 保存工作簿
    #wb.close()  # 关闭工作簿
    #app.quit()  # 退出应用程序


def insert_ledger_he_tie_kuang(ledger_path,sheet_name,col_index,return_data):
    print("写入中...")
    app = xlwings.App(visible=True, add_book=False)  # 创建一个不可见的 Excel 应用程序实例
    wb = app.books.open(ledger_path, update_links=False)  # 打开工作簿
    sheet = wb.sheets[sheet_name]
    if sheet is None:  # 检查 sheet 是否为 None
        pass
    sheet.activate()
    set_excel_window_right_half(app)

    last_row = sheet.range(sheet.cells.last_cell.row, 1).end('up').row
    start_row = last_row + 1  # 调整1位
    data_list = return_data["data"]

    date1 = sheet.range(last_row, 2).value.date()
    try:
        date2 = parser.parse(data_list[0]["ri_qi"]).date()  # 解析第二个日期
    except:
        date2=data_list[0]["ri_qi"].date()

    矿名=sheet.range(last_row, 3).value

    if 矿名=="褐铁矿":
        if date1 == date2:
            print("日期重复，不可以写入")
            return
        else:
            print("日期不重复，可以写入")
            print("台账日期："+str(sheet.range(last_row, 2).value))
            print("数据源日期："+str(data_list[0]["ri_qi"]))






    sheet.api.Cells(start_row, 1).Activate()
    for i in range(0, len(data_list)):
        sheet.range(start_row + i, 1).select()
        try:
            date_obj = datetime.strptime(data_list[i]["ri_qi"], "%Y/%m/%d")
        except:
            date_obj=data_list[i]["ri_qi"]
        sheet.range(start_row + i, col_index["year_month"]).value = date_obj.strftime("%Y%m")
        sheet.range(start_row + i, col_index["ri_qi"]).value = data_list[i]["ri_qi"]
        sheet.range(start_row + i, 3).value = "褐铁矿"
        sheet.range(start_row + i, col_index["pi_ci"]).value = data_list[i]["pi_ci"]
        sheet.range(start_row + i, col_index["gong_ying_shang"]).value = data_list[i]["gong_ying_shang"]
        sheet.range(start_row + i, col_index["jing_zhong"]).value = data_list[i]["jing_zhong"]
        for v in range(0,len(col_index["value_copy"])):
            sheet.range(start_row + i, col_index["value_copy"][v]).value = sheet.range(start_row + i-1, col_index["value_copy"][v]).value
        for f in range(0, len(col_index["formula_copy"])):
            source_range=sheet.range(start_row + i - 1,col_index["formula_copy"][f])
            target_range =sheet.range(start_row + i,col_index["formula_copy"][f])
            source_range.copy(target_range)  # 复制并粘贴
            #sheet.range(start_row + i, col_index["formula_copy"][f]).formula = sheet.range(start_row + i - 1,col_index["formula_copy"][f]).formula
    print("写入完成！")


def insert_ledger_li_shi(ledger_path,sheet_name,col_index,return_data):
    print("写入中...")
    app = xlwings.App(visible=True, add_book=False)  # 创建一个不可见的 Excel 应用程序实例
    wb = app.books.open(ledger_path, update_links=False)  # 打开工作簿
    sheet = wb.sheets[sheet_name]
    if sheet is None:  # 检查 sheet 是否为 None
        pass
    sheet.activate()
    set_excel_window_right_half(app)
    last_row = sheet.range(sheet.cells.last_cell.row, 1).end('up').row
    start_row = last_row + 1  # 调整1位
    data_list = return_data["data"]
    date1 = sheet.range(last_row, 2).value.date()
    date2 = parser.parse(data_list[0]["ri_qi"]).date()  # 解析第二个日期

    if date1 == date2:
        print("日期相等")
        return
    else:
        print("日期不相等")
        print(sheet.range(last_row, 2).value)
        print(data_list[0]["ri_qi"])

    sheet.api.Cells(start_row, 1).Activate()
    index_b=0
    for i in range(0, len(data_list)):
        if data_list[i]["jing_zhong"]==None or data_list[i]["jing_zhong"]=="" or data_list[i]["jing_zhong"]=="0" or data_list[i]["jing_zhong"]==0:
            continue
        sheet.range(start_row + index_b,1).select()
        date_obj = datetime.strptime(data_list[i]["ri_qi"], "%Y/%m/%d")
        sheet.range(start_row + index_b, col_index["year_month"]).value = date_obj.strftime("%Y%m")
        sheet.range(start_row + index_b, col_index["ri_qi"]).value = data_list[i]["ri_qi"]
        sheet.range(start_row + index_b, col_index["guo_bang_wu_pin"]).value = data_list[i]["guo_bang_wu_pin"]
        sheet.range(start_row + index_b, col_index["jing_zhong"]).value = data_list[i]["jing_zhong"]
        for v in range(0,len(col_index["value_copy"])):
            sheet.range(start_row + index_b, col_index["value_copy"][v]).value = sheet.range(start_row + index_b-1, col_index["value_copy"][v]).value
        index_b =index_b+1
    range_a=sheet.range((start_row,1),(start_row+index_b-1,6))
    border_color(range_a,(255,255,0),sheet)
    print("写入完成...")
    #wb.save()  # 保存工作簿
    #wb.close()  # 关闭工作簿
    #app.quit()  # 退出应用程序
def insert_ledger_mhp_quality(ledger_path, sheet_name,return_data):
    print("写入中...")
    app = xlwings.App(visible=True, add_book=False)  # 创建一个不可见的 Excel 应用程序实例
    set_excel_window_right_half(app)
    wb = app.books.open(ledger_path, update_links=False)  # 打开工作簿
    sheet = wb.sheets[sheet_name]
    sheet.activate()
    set_excel_window_right_half(app)

    data_list = return_data["data"]
    last_row_ri_qi= sheet.range(sheet.cells.last_cell.row, 2).end('up').row

    last_row_Ni = sheet.range('J1').end('down').row
    print(last_row_Ni, last_row_ri_qi)
    for i in range(0, len(data_list)):
        for j in range(last_row_Ni+1,last_row_ri_qi+1):
            if data_list[i]["pi_hao"]==sheet.range(j,7).value: #插入
                sheet.range(j, 10).select()
                sheet.range(j , 10).value=data_list[i]["Ni"]
                sheet.range(j , 11).value = data_list[i]["Co"]
                sheet.range(j , 12).value = data_list[i]["Fe"]
                sheet.range(j , 13).value = data_list[i]["Al"]
                sheet.range(j, 14).value = data_list[i]["Cr"]
                sheet.range(j , 15).value = data_list[i]["Mn"]
                sheet.range(j , 16).value = data_list[i]["Mg"]
                sheet.range(j , 17).value = data_list[i]["Si"]
                sheet.range(j , 18).value = data_list[i]["S"]
                sheet.range(j , 19).value = data_list[i]["H2O"]
                break
    print("写入完成...")
    #wb.save()  # 保存工作簿
    # wb.close()  # 关闭工作簿
    # app.quit()  # 退出应用程序
def insert_ledger_he_quality(ledger_path, sheet_name,return_data,yang_pin_bian_hao_col):
    print("写入中...")
    app = xlwings.App(visible=True, add_book=False)  # 创建一个不可见的 Excel 应用程序实例
    set_excel_window_right_half(app)
    wb = app.books.open(ledger_path, update_links=False)  # 打开工作簿
    sheet = wb.sheets[sheet_name]
    sheet.activate()
    data_list = return_data["data"]
    last_row_ri_qi= sheet.range(sheet.cells.last_cell.row, 2).end('up').row

    last_row_Ni = sheet.range('J1').end('down').row
    if last_row_Ni<last_row_ri_qi-100:
        last_row_Ni=last_row_ri_qi-100
    print(last_row_Ni, last_row_ri_qi)
    for i in range(0, len(data_list)):
        for j in range(last_row_Ni+1,last_row_ri_qi+1):
            if data_list[i]["yang_pin_bian_hao"]==sheet.range(j,yang_pin_bian_hao_col).value: #插入
                sheet.range(j, 10).select()
                sheet.range(j , 10).value=data_list[i]["Ni"]
                sheet.range(j , 11).value = data_list[i]["Co"]
                sheet.range(j , 12).value = data_list[i]["Fe"]
                sheet.range(j , 13).value = data_list[i]["Al"]
                sheet.range(j, 14).value = data_list[i]["Cr"]
                sheet.range(j , 15).value = data_list[i]["Mn"]
                sheet.range(j , 16).value = data_list[i]["Mg"]
                sheet.range(j , 17).value = data_list[i]["Si"]
                sheet.range(j , 18).value = data_list[i]["H2O"]
                break
    print("写入完成...")
    #wb.save()  # 保存工作簿
    # wb.close()  # 关闭工作簿
    # app.quit()  # 退出应用程序
def insert_niso4_quality(ledger_path,sheet_name,return_data):
    print("写入文件中......")
    app = xlwings.App(visible=True, add_book=False)  # 创建一个不可见的 Excel 应用程序实例
    wb = app.books.open(ledger_path, update_links=False)  # 打开工作簿
    sheet = wb.sheets[sheet_name]

    set_excel_window_right_half(app)

    sheet.activate()
    last_row = sheet.range(sheet.cells.last_cell.row, 2).end('up').row

    data_list = return_data["data"]
    入库日期参数=data_list[0]["pi_ci"]

    match = re.search(r'\d{8}', 入库日期参数)
    if match:
        date_str = match.group()
        date_obj = datetime.strptime(date_str, "%Y%m%d").date() # 将字符串转换为date对象
    else:
        print("未找到有效的日期格式")
    # 将字符串转换为日期对象
    date_1 = sheet.range(last_row,2).value.date()
    date_2 = date_obj
    if date_1==date_2:
        print("日期重复不可以写入")
        return 9
    start_row=last_row+1
    for i in range(0, len(data_list)):
        match = re.search(r'\d{8}', data_list[i]["pi_ci"])
        if match:
            date_str = match.group()
            # 将字符串转换为date对象
            date_obj = datetime.strptime(date_str, "%Y%m%d").date()
            year_month_day=date_obj
        else:
            print("未找到有效的日期格式2")
        sheet.range(start_row+i,1).select()
        sheet.range(start_row+i,1).value=data_list[i]["pi_ci"][3:9]
        sheet.range(start_row + i, 2).value = year_month_day
        sheet.range(start_row + i, 3).value = "硫酸镍"
        sheet.range(start_row + i, 7).value = data_list[i]["pi_ci"]
        sheet.range(start_row + i, 8).value = data_list[i]["包数"]
        sheet.range(start_row + i,9).value = data_list[i]["净重"]
        sheet.range(start_row + i, 10).value = data_list[i]["Ni"]
        sheet.range(start_row + i, 11).value = data_list[i]["Co"]
        sheet.range(start_row + i, 12).value = data_list[i]["Mg"]
        sheet.range(start_row + i, 13).value = data_list[i]["Na"]
        sheet.range(start_row + i, 14).value = data_list[i]["H2O"]
        sheet.range(start_row + i, 15).value = data_list[i]["Ci"]

        sheet.range(start_row + i, 17).value = data_list[i]["备注"]
        source_range = sheet.range(start_row + i - 1, 16)
        target_range = sheet.range(start_row + i, 16)
        source_range.copy(target_range)  # 复制并粘贴
    print("写入完成！")
    # wb.save()  # 保存工作簿
    # wb.close()  # 关闭工作簿
    # app.quit()  # 退出应用程序
def insert_硫酸钴_quality(ledger_path,sheet_name,return_data):
    print("写入文件中......")
    app = xlwings.App(visible=True, add_book=False)  # 创建一个不可见的 Excel 应用程序实例
    wb = app.books.open(ledger_path, update_links=False)  # 打开工作簿
    sheet = wb.sheets[sheet_name]

    set_excel_window_right_half(app)

    sheet.activate()
    last_row = sheet.range(sheet.cells.last_cell.row, 2).end('up').row
    data_list = return_data["data"]
    日期 = data_list[0]["日期"]

    date_1 = sheet.range(last_row, 2).value.date()
    date_obj = datetime.strptime(日期, "%Y-%m-%d").date()  # 将字符串转换为date对象
    date_2 = date_obj
    if date_1 == date_2:
        print("日期重复不可以写入")
        return 9
    start_row = last_row + 1
    for i in range(0, len(data_list)):
        # 将 date 对象格式化为 YYYYMM 格式
        日期 = data_list[i]["日期"]
        date_obj = datetime.strptime(日期, "%Y-%m-%d").date()  # 将字符串转换为date对象
        formatted_date = date_obj.strftime("%Y%m")

        sheet.range(start_row + i, 1).select()
        sheet.range(start_row + i, 1).value = formatted_date
        sheet.range(start_row + i, 2).value = 日期
        sheet.range(start_row + i, 3).value = "硫酸钴"
        sheet.range(start_row + i, 7).value =data_list[i]["批号"]
        sheet.range(start_row + i, 8).value = data_list[i]["包数"]
        sheet.range(start_row + i, 9).value = data_list[i]["重量"]

        sheet.range(start_row + i, 10).value = data_list[i]["Ni"]
        sheet.range(start_row + i, 11).value = data_list[i]["Co"]
        sheet.range(start_row + i, 12).value = data_list[i]["Mg"]
        sheet.range(start_row + i, 13).value = data_list[i]["Na"]
        sheet.range(start_row + i, 14).value = data_list[i]["水不溶物"]
        sheet.range(start_row + i, 15).value = data_list[i]["磁性异物"]
        sheet.range(start_row + i, 17).value = data_list[i]["备注"]

        source_range = sheet.range(start_row + i - 1, 16)
        target_range = sheet.range(start_row + i, 16)
        source_range.copy(target_range)  # 复制并粘贴
def insert_电解钴_match(ledger_path,sheet_name,return_data):
    print("写入文件中......")
    app = xlwings.App(visible=True, add_book=False)  # 创建一个不可见的 Excel 应用程序实例
    wb = app.books.open(ledger_path, update_links=False)  # 打开工作簿
    sheet = wb.sheets[sheet_name]

    set_excel_window_right_half(app)

    sheet.activate()

    last_row_Co = sheet.range('J1').end('down').row
    #last_row_Co = sheet.range(sheet.cells.last_cell.row, 10).end('up').row
    last_row_批号=sheet.range(sheet.cells.last_cell.row, 7).end('up').row
    data_list = return_data["data"]
    print(last_row_Co)
    print(last_row_批号)
    if last_row_Co==last_row_批号:
        #钴板
        start_row = last_row_Co + 1
        for i in range(0, len(data_list)):
            sheet.range(start_row + i, 1).select()
            sheet.range(start_row + i, 7).value =data_list[i]["Key"]
            sheet.range(start_row + i, 9).value = data_list[i]["NW"]
            sheet.range(start_row + i, 10).value = data_list[i]["Co"]
            sheet.range(start_row + i, 11).value = data_list[i]["Fe"]
            sheet.range(start_row + i, 12).value = data_list[i]["Al"]
            sheet.range(start_row + i, 13).value = data_list[i]["Mn"]
            sheet.range(start_row + i, 14).value = data_list[i]["Mg"]
            sheet.range(start_row + i, 15).value = data_list[i]["Zn"]
            sheet.range(start_row + i, 16).value = data_list[i]["Cu"]
            sheet.range(start_row + i, 17).value = data_list[i]["Si"]
            sheet.range(start_row + i, 18).value = data_list[i]["S"]
            sheet.range(start_row + i, 19).value = data_list[i]["P"]
            sheet.range(start_row + i, 20).value = data_list[i]["Cd"]
            sheet.range(start_row + i, 21).value = data_list[i]["Pb"]
            sheet.range(start_row + i, 22).value = data_list[i]["C"]
            sheet.range(start_row + i, 23).value = data_list[i]["As"]
            sheet.range(start_row + i, 24).value = data_list[i]["Sb"]
            sheet.range(start_row + i, 25).value = data_list[i]["Sn"]
            sheet.range(start_row + i, 26).value = data_list[i]["Bi"]
            sheet.range(start_row + i, 27).value = data_list[i]["Ni"]
            source_range = sheet.range(start_row + i - 1, 28)
            target_range = sheet.range(start_row + i, 28)
            source_range.copy(target_range)  # 复制并粘贴


    start_row = last_row_Co + 1#reset
    if last_row_Co!=last_row_批号:
        for i in range(0, len(data_list)):
            for j in range(last_row_Co + 1, last_row_批号 + 1):
                print(data_list[i]["Key"])
                print(sheet.range(j, 7).value)
                if data_list[i]["Key"] == sheet.range(j, 7).value:  # 插入
                    sheet.range(j, 10).select()
                    sheet.range(j, 10).value = data_list[i]["Co"]
                    sheet.range(j, 11).value = data_list[i]["Fe"]
                    sheet.range(j , 12).value = data_list[i]["Al"]
                    sheet.range(j , 13).value = data_list[i]["Mn"]
                    sheet.range(j , 14).value = data_list[i]["Mg"]
                    sheet.range(j , 15).value = data_list[i]["Zn"]
                    sheet.range(j , 16).value = data_list[i]["Cu"]
                    sheet.range(j, 17).value = data_list[i]["Si"]
                    sheet.range(j, 18).value = data_list[i]["S"]
                    sheet.range(j , 19).value = data_list[i]["P"]
                    sheet.range(j, 20).value = data_list[i]["Cd"]
                    sheet.range(j , 21).value = data_list[i]["Pb"]
                    sheet.range(j , 22).value = data_list[i]["C"]
                    sheet.range(j , 23).value = data_list[i]["As"]
                    sheet.range(j, 24).value = data_list[i]["Sb"]
                    sheet.range(j, 25).value = data_list[i]["Sn"]
                    sheet.range(j , 26).value = data_list[i]["Bi"]
                    sheet.range(j, 27).value = data_list[i]["Ni"]
                    source_range = sheet.range(j  - 1, 28)
                    target_range = sheet.range(j , 28)
                    source_range.copy(target_range)  # 复制并粘贴
    print("写入完成...")
def strip_and_number_convert(excel_file_path):#清空空白字符串以及数字转换
    wb = load_workbook(excel_file_path) # 加载Excel文件
    ws = wb.active
    for row in ws.iter_rows(min_row=1, max_row=100, min_col=1, max_col=ws.max_column):# 处理数据
        for cell in row:
            if isinstance(cell.value, str):
                cell.value = cell.value.strip()
            if isinstance(cell.value, str): # 尝试将文本转换为数字
                try:
                    cell.value = float(cell.value)  # 转换为浮点数
                except ValueError:
                    pass# 如果转换失败，保持原值
    wb.save(excel_file_path) # 保存到新Excel文件
    wb.close()

def pdf_to_excel(source_file,destination_file):
    pdf = pdfplumber.open(source_file)
    page = pdf.pages[0]# 选择第一个页面
    table = page.extract_table() # 提取表格
    workbook = Workbook() # 创建Excel工作簿
    sheet = workbook.active
    # 如果目录不存在，创建目录
    destination_dir = os.path.dirname(destination_file)
    if not os.path.exists(destination_dir):
        os.makedirs(destination_dir)
    if table: # 将提取的表格数据写入Excel
        for row in table:
            sheet.append(row)  # 将每一行添加到工作表

        workbook.save(destination_file) # 保存Excel文件
        print(f"表格已成功提取并保存到 {destination_file}")
    else:
        print("未找到表格数据")
    pdf.close()# 关闭PDF文件
    strip_and_number_convert(destination_file)
def make_copy(production_ledger_path): # 复制
    folder_path = os.path.dirname(production_ledger_path)
    timestamp_a = datetime.now().strftime("%Y%m%d")  # 获取当前时间的年月日_小时分钟秒
    history_folder = os.path.join(folder_path, "历史台账\\"+timestamp_a)  # 定义历史台账目录路径
    if not os.path.exists(history_folder):  # 如果历史台账目录不存在，则创建它
        os.makedirs(history_folder)
    timestamp = datetime.now().strftime("%Y%m%d")  # 获取当前时间的年月日_小时分钟秒
    file_name = os.path.basename(production_ledger_path)  # 获取文件名
    new_file_name = f"{os.path.splitext(file_name)[0]}_{timestamp}{os.path.splitext(file_name)[1]}"  # 构造新文件名
    target_path = os.path.join(history_folder, new_file_name)
    print("原文件副本存档路径："+target_path)
    shutil.copy2(production_ledger_path, target_path)  # 复制文件到历史台账目录，并重命名
'''
def pdf_convert(source_file_path):#如果是pdf文件，那么转成excel文件，返回excel文件路径，参数是pdf文件路径
    file_extension = source_file_path.split(".")[-1]
    source_file_name_without_extention = source_file_path[0:-(len(file_extension) + 1)]  # 去除后缀名
    converted_excel_path = source_file_name_without_extention + ".xlsx"
    if file_extension == "pdf":
        print("source file is pdf  ||  file:converting...........")
        pdf_to_excel(source_file_path, converted_excel_path)
        source_file_path = converted_excel_path
    return source_file_path'''
def pdf_convert(source_file_path):#如果是pdf文件，那么转成excel文件，返回excel文件路径，参数是pdf文件路径
    file_extension = source_file_path.split(".")[-1]
    file_name=source_file_path.split("/")[-1]
    file_name_no_extension=file_name[0:-(len(file_extension)+1)]#2024.9.6褐铁矿质量证明书
    #print(file_name_no_extension)
    #print(file_name)
    source_folder= source_file_path[0:-(len(file_name) + 1)]  # 去除后缀名#D:\Desktop\新建文件夹 (3)
    converted_excel_path=source_folder+"/转换后excel/"+file_name_no_extension+".xlsx"
    print(source_file_path)
    print("converted_excel_path:")
    print(converted_excel_path)
    if file_extension == "pdf":
        print("source file is pdf  ||  file:converting...........")
        pdf_to_excel(source_file_path, converted_excel_path)
        source_file_path = converted_excel_path
    return source_file_path
def open_ledger(file_path):
    print("写入中......")
    app = xlwings.App(visible=True, add_book=False)  # 创建一个不可见的 Excel 应用程序实例
    wb = app.books.open(file_path, update_links=False)  # 打开工作簿
    set_excel_window_left_half(app)
def production_ledger_insert(production_ledger_path,source_file_path,my_type):
    return_data_2={"文件名匹配状态":0}
    源文件名=os.path.basename(source_file_path)
    台账文件名 = os.path.basename(production_ledger_path)
    if ("ONC褐铁矿运输确认单" in 源文件名 and "ONC---褐铁矿---入库指标明细数据库" in 台账文件名) or my_type=="ONC褐铁矿":
        return_data_2 = {"文件名匹配状态": 1}
        source_file_path=pdf_convert(source_file_path)
        make_copy(production_ledger_path)

        return_data = read_he_tie_kuang(source_file_path)
        if return_data["是否为标准文件"] == "是":
            onc_he_index = {"year_month": 1, "ri_qi": 2, "pi_ci": 5, "gong_ying_shang": 7, "jing_zhong": 8,
                            "value_copy": [4], "formula_copy": [6, 9, 19, 20, 21, 22, 23, 24, 25, 26, 27]}
            insert_ledger_he_tie_kuang(production_ledger_path, "褐铁矿指标明细数据库", onc_he_index,return_data)
        else:
            print(return_data["是否为标准文件"])

    if "ONC大中小砾石" in 源文件名 and "ONC---褐铁矿---入库指标明细数据库" in 台账文件名 or my_type=="ONC砾石":
        return_data_2 = {"文件名匹配状态": 1}
        source_file_path=pdf_convert(source_file_path)
        make_copy(production_ledger_path)
        return_data=read_li_shi(source_file_path)
        if return_data["是否为标准文件"] == "是":
            onc_li_shi_index = {"year_month": 1, "ri_qi": 2, "guo_bang_wu_pin": 4, "jing_zhong": 6,"value_copy": [3]}
            insert_ledger_li_shi(production_ledger_path,"砾石数据",onc_li_shi_index,return_data)
    if "ONC-MHP过磅日报" in 源文件名 and "ONC---MHP产成品入库指标数" in 台账文件名 or my_type=="ONC_MHP":
        return_data_2 = {"文件名匹配状态": 1}
        source_file_path = pdf_convert(source_file_path)

        make_copy(production_ledger_path)
        return_data=read_mhp(source_file_path)
        if return_data["是否为标准文件"]=="是":
            insert_ledger_mhp(production_ledger_path,"MHP 产品入库明细数",return_data)

    if "ONC-MHP质量证明书" in 源文件名 and "ONC---MHP产成品入库指标数"in 台账文件名 or my_type=="ONC_MHP质量":
        return_data_2 = {"文件名匹配状态": 1}
        source_file_path = pdf_convert(source_file_path)
        make_copy(production_ledger_path)
        return_data=read_mhp_quality(source_file_path)
        if return_data["是否为标准文件"] == "是":
            insert_ledger_mhp_quality(production_ledger_path,"MHP 产品入库明细数", return_data)
    if "ONC褐铁矿质量证明" in 源文件名 and "ONC---褐铁矿---入库指标明细数据库"in 台账文件名 or my_type=="ONC褐铁矿质量":
        return_data_2 = {"文件名匹配状态": 1}
        source_file_path = pdf_convert(source_file_path)
        make_copy(production_ledger_path)
        return_data = read_he_tie_kuang_quality(source_file_path)
        if return_data["是否为标准文件"] == "是":
            insert_ledger_he_quality(production_ledger_path, "褐铁矿指标明细数据库", return_data,5)

    if "HPL褐铁矿运输确认单" in 源文件名 and "HPAL-褐铁矿入库指标明细数据库" in 台账文件名 or my_type=="HPAL褐铁矿":
        return_data_2 = {"文件名匹配状态": 1}
        source_file_path = pdf_convert(source_file_path)
        make_copy(production_ledger_path)
        return_data = read_he_tie_kuang(source_file_path)
        if return_data["是否为标准文件"] == "是":
            hpal_he_index = {"year_month": 1, "ri_qi": 2, "pi_ci": 6, "gong_ying_shang": 7, "jing_zhong": 8,
                             "value_copy": [4], "formula_copy": [5,9, 19, 20, 21, 22, 23, 24, 25, 26, 27]}
            insert_ledger_he_tie_kuang(production_ledger_path, "褐铁矿指标明细数据库(现用版-刘卉）", hpal_he_index, return_data)
    if "HPL大中小" in 源文件名 and "HPAL-褐铁矿入库指标明细数据库" in 台账文件名 or my_type=="HPAL砾石":

        return_data_2 = {"文件名匹配状态": 1}
        source_file_path = pdf_convert(source_file_path)
        make_copy(production_ledger_path)
        return_data=read_li_shi(source_file_path)
        if return_data["是否为标准文件"] == "是":
            hpal_li_shi_index = {"year_month": 1, "ri_qi": 2, "guo_bang_wu_pin": 3, "jing_zhong": 6,
                                 "value_copy": []}
            insert_ledger_li_shi(production_ledger_path,"砾石数据明细台账（现用版）",hpal_li_shi_index,return_data)
    if "HPL-MHP过磅日报" in 源文件名 and "HPAL-MHP、硫酸镍、硫酸钴产品入库明细表" in 台账文件名 or my_type=="HPAL_MHP":
        return_data_2 = {"文件名匹配状态": 1}
        source_file_path=pdf_convert(source_file_path)
        make_copy(production_ledger_path)
        return_data = read_mhp(source_file_path)
        if return_data["是否为标准文件"] == "是":
            insert_ledger_mhp(production_ledger_path,"1-MHP 入库明细台账（更新表）", return_data)

    if "HPL-MHP质量证明" in 源文件名 and "HPAL-MHP、硫酸镍、硫酸钴产品入库明细表"in 台账文件名 or my_type=="HPAL_MHP质量":
        return_data_2 = {"文件名匹配状态": 1}
        source_file_path = pdf_convert(source_file_path)
        make_copy(production_ledger_path)
        return_data=read_mhp_quality(source_file_path)
        if return_data["是否为标准文件"] == "是":
            insert_ledger_mhp_quality(production_ledger_path,"1-MHP 入库明细台账（更新表）", return_data)
        else:
            print(return_data["是否为标准文件"])
    if "HPL褐铁矿质量证明" in 源文件名 and "HPAL-褐铁矿入库指标明细数据库"in 台账文件名 or my_type=="HPAL褐铁矿质量":
        return_data_2 = {"文件名匹配状态": 1}
        source_file_path = pdf_convert(source_file_path)
        make_copy(production_ledger_path)
        return_data = read_he_tie_kuang_quality(source_file_path)
        if return_data["是否为标准文件"] == "是":
            insert_ledger_he_quality(production_ledger_path, "褐铁矿指标明细数据库(现用版-刘卉）", return_data,6)
    if "硫酸镍质量证明" in 源文件名 and "HPAL-MHP、硫酸镍、硫酸钴产品入库明细表"in 台账文件名 or my_type=="HPAL硫酸镍":
        return_data_2 = {"文件名匹配状态": 1}
        source_file_path = pdf_convert(source_file_path)
        make_copy(production_ledger_path)
        return_data = read_niso4_quality(source_file_path)
        if return_data["是否为标准文件"] == "是":
            insert_niso4_quality(production_ledger_path, "2硫酸镍产品入库明细台账", return_data)
        else:
            print(return_data["是否为标准文件"])

    if "硫酸钴质量证明" in 源文件名 and "HPAL-MHP、硫酸镍、硫酸钴产品入库明细表"in 台账文件名 or my_type=="HPAL硫酸钴":
        return_data_2 = {"文件名匹配状态": 1}
        source_file_path = pdf_convert(source_file_path)
        make_copy(production_ledger_path)
        return_data = read_硫酸钴_quality(source_file_path)
        if return_data["是否为标准文件"] == "是":
            insert_硫酸钴_quality(production_ledger_path, "3硫酸钴产品入库明细台账", return_data)
        else:
            print(return_data["是否为标准文件"])
    if "电解钴" in 源文件名 and "HPAL-MHP、硫酸镍、硫酸钴产品入库明细表"in 台账文件名 or my_type=="电解钴":
        return_data_2 = {"文件名匹配状态": 1}
        source_file_path = pdf_convert(source_file_path)
        make_copy(production_ledger_path)
        return_data = read_电解钴_quality(source_file_path)
        if return_data["是否为标准文件"] == "是":
            insert_电解钴_match(production_ledger_path, "4-电解钴产品入库明细台账", return_data)
        else:
            print(return_data["是否为标准文件"])

    return return_data_2

onc_mhp=r"Z:\ONC-----------共享资料\ONC--生产数据台账更新版\ONC---MHP产成品入库指标数(8月).xlsx"
onc_he=r"D:\Desktop\def\ONC---褐铁矿---入库指标明细数据库(8月).xlsx"
hpal_mhp=r"Z:\HPAL-----------共享资料\HPAL-----生产数据--台账更新版\HPAL-MHP、硫酸镍、硫酸钴产品入库明细表(更新版202408月).xlsx"
hpal_he=r"Z:\HPAL-----------共享资料\HPAL-----生产数据--台账更新版\HPAL-褐铁矿入库指标明细数据库(更新版202408月).xlsx"
test_file=r"D:\Desktop\def\2024.8.30ONC褐铁矿运输确认单（待确认）.pdf"
onc_ledger_path=[onc_mhp,onc_he]
hpal_ledger_path=[hpal_mhp,hpal_he]
if 0:
    for path in onc_ledger_path:
        insert_status=production_ledger_insert(path,test_file)
        print(insert_status)
    for path in hpal_ledger_path:
        insert_status=production_ledger_insert(path,test_file)
        print(insert_status)
if 0:
    硫酸钴质量路径=r"F:\xu\生产台账临时文件夹\2024.9.22-9.23硫酸钴质量证明.xlsx"
    return_data=read_硫酸钴_quality(硫酸钴质量路径)
    print(return_data)
    ledger_path=r"F:\xu\生产台账临时文件夹\HPAL-MHP、硫酸镍、硫酸钴产品入库明细表.xlsx"
    sheet_name=r"3硫酸钴产品入库明细台账"
    insert_硫酸钴_quality(ledger_path,sheet_name,return_data)
