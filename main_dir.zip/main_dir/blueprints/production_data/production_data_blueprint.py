import os

from flask import Blueprint, render_template, request

from blueprints.production_data.production_data_functions import open_file_dialog, insert_basic_db, \
    get_value_from_basic_db, open_folder_dialog, my_merge,merge_test
from blueprints.production_data.production_ledger2 import production_ledger_insert,open_ledger

# 创建一个蓝图实例
production_data_blueprint = Blueprint('production_data_blueprint', __name__)

@production_data_blueprint.route("/production_data_blueprint")
def production_data_blueprint_home():
    return render_template("production_data/home.html")
@production_data_blueprint.route("/production_data_blueprint_upload",methods=["POST"])
def production_data_blueprint_2():
    if request.method=="POST":
        return_json={"status":1}
        data = request.get_json()

        my_type = data["my_type"]
        if my_type=="upload":
            if data["my_file"]=="1":
                file_path=open_file_dialog()
                if file_path!="":
                    insert_basic_db("onc_褐铁矿台账_路径",file_path)
            if data["my_file"]=="2":
                file_path=open_file_dialog()
                if file_path != "":
                    insert_basic_db("onc_mhp台账_路径",file_path)
            if data["my_file"]=="3":
                file_path=open_file_dialog()
                if file_path != "":
                    insert_basic_db("hpal_褐铁矿台账_路径",file_path)
            if data["my_file"]=="4":
                file_path=open_file_dialog()
                if file_path != "":
                    insert_basic_db("hpal_mhp台账_路径",file_path)
            if data["my_file"]=="5":
                file_path=open_file_dialog()
                if file_path != "":
                    file_path=file_path[:-((len(file_path.split("/")[-1]))+1)]
                    insert_basic_db("源数据文件夹",file_path)
            if data["my_file"]=="6":
                file_path=open_folder_dialog()
                if file_path != "":
                    insert_basic_db("数据归类文件夹",file_path)
        if my_type == "fetch_data":
            onc_褐铁矿台账_路径=get_value_from_basic_db("onc_褐铁矿台账_路径")
            onc_mhp台账_路径=get_value_from_basic_db("onc_mhp台账_路径")
            hpal_褐铁矿台账_路径=get_value_from_basic_db("hpal_褐铁矿台账_路径")
            hpal_mhp台账_路径=get_value_from_basic_db("hpal_mhp台账_路径")
            源数据文件夹=get_value_from_basic_db("源数据文件夹")
            数据归类文件夹=get_value_from_basic_db("数据归类文件夹")
            if onc_褐铁矿台账_路径!="":
                return_json["onc_褐铁矿台账_路径"]=onc_褐铁矿台账_路径
            if onc_mhp台账_路径!="":
                return_json["onc_mhp台账_路径"] = onc_mhp台账_路径
            if hpal_褐铁矿台账_路径!="":
                return_json["hpal_褐铁矿台账_路径"] =hpal_褐铁矿台账_路径
            if hpal_mhp台账_路径!="":
                return_json["hpal_mhp台账_路径"] = hpal_mhp台账_路径
            if 数据归类文件夹 != "":
                return_json["数据归类文件夹"] = 数据归类文件夹
            if 源数据文件夹!="":
                files_flag=[]
                return_json["源数据文件夹"] = 源数据文件夹
                files = [f for f in os.listdir(源数据文件夹) if os.path.isfile(os.path.join(源数据文件夹, f))]
                for i in range(0,len(files)):

                    files_flag.append(merge_test(files[i]))
                return_json["files_flag"]=files_flag
                return_json["files"]=files
        if my_type == "main_start":
            file_name=data["file_name"]
            if file_name!="":#选中文件

                源数据文件夹 = get_value_from_basic_db("源数据文件夹")
                源文件路径=源数据文件夹+"/"+file_name
                print("源数据文件夹:"+源数据文件夹)

                print("源文件路径:"+源文件路径)




                onc_褐铁矿台账_路径=get_value_from_basic_db("onc_褐铁矿台账_路径")
                onc_mhp台账_路径=get_value_from_basic_db("onc_mhp台账_路径")
                hpal_褐铁矿台账_路径=get_value_from_basic_db("hpal_褐铁矿台账_路径")
                hpal_mhp台账_路径=get_value_from_basic_db("hpal_mhp台账_路径")

                ONC褐铁矿台账文件支持列表=["ONC褐铁矿","ONC褐铁矿质量","ONC砾石"]
                ONC_MHP台账文件支持列表 = ["ONC_MHP", "ONC_MHP质量"]
                HPAL褐铁矿台账文件支持列表 = ["HPAL褐铁矿", "HPAL褐铁矿质量", "HPAL砾石"]
                HPAL_MHP台账文件支持列表 = ["HPAL_MHP", "HPAL_MHP质量","HPAL硫酸镍","HPAL硫酸钴","电解钴"]
                checkbox_list = data["checkbox_list"]
                print(checkbox_list)
                if len(checkbox_list) > 0:#如果手动选择类型，手动判断部分
                    if onc_褐铁矿台账_路径 != "" and checkbox_list[0] in ONC褐铁矿台账文件支持列表:
                        production_ledger_insert(onc_褐铁矿台账_路径, 源文件路径,checkbox_list[0])
                    if onc_mhp台账_路径 != "" and checkbox_list[0] in ONC_MHP台账文件支持列表:
                        production_ledger_insert(onc_mhp台账_路径, 源文件路径,checkbox_list[0])
                    if hpal_褐铁矿台账_路径 != "" and checkbox_list[0] in HPAL褐铁矿台账文件支持列表:
                        production_ledger_insert(hpal_褐铁矿台账_路径, 源文件路径,checkbox_list[0])
                    if hpal_mhp台账_路径 != "" and checkbox_list[0] in HPAL_MHP台账文件支持列表:
                        production_ledger_insert(hpal_mhp台账_路径, 源文件路径,checkbox_list[0])
                    return return_json
                if onc_褐铁矿台账_路径!="":
                    production_ledger_insert(onc_褐铁矿台账_路径, 源文件路径,"0")
                if onc_mhp台账_路径 != "":
                    production_ledger_insert(onc_mhp台账_路径, 源文件路径,"0")
                if hpal_褐铁矿台账_路径 != "":
                    production_ledger_insert(hpal_褐铁矿台账_路径, 源文件路径,"0")
                if hpal_mhp台账_路径 != "":
                    production_ledger_insert(hpal_mhp台账_路径, 源文件路径,"0")
        if my_type == "my_merge":
            源数据文件夹 = get_value_from_basic_db("源数据文件夹")
            数据归类文件夹 = get_value_from_basic_db("数据归类文件夹")
            print("源数据文件夹"+源数据文件夹)
            print("数据归类文件夹"+数据归类文件夹)
            if 源数据文件夹!="" and 数据归类文件夹!="":
                my_merge(源数据文件夹,数据归类文件夹)
        if my_type=="alter_file_name":
            old_name = data["old_name"]
            new_name = data["new_name"]
            print(old_name,new_name)
            源数据文件夹 = get_value_from_basic_db("源数据文件夹")
            # 构建完整的旧文件路径和新文件路径
            old_file_path = os.path.join(源数据文件夹, old_name)
            new_file_path = os.path.join(源数据文件夹, new_name)
            # 检查旧文件是否存在
            # 检查旧文件是否存在
            if os.path.exists(old_file_path):
                # 重命名文件
                os.rename(old_file_path, new_file_path)
                print(f"文件 '{old_name}' 已成功重命名为 '{new_name}'")
            else:
                print(f"文件 '{old_name}' 不存在，无法重命名。")
            print(源数据文件夹)
        if my_type=="open_file":
            file_name=data["file_name"]
            源数据文件夹 = get_value_from_basic_db("源数据文件夹")
            file_path=os.path.join(源数据文件夹, file_name)
            # 获取文件名和后缀
            name, extension = os.path.splitext(file_name)
            if extension==".pdf":
                # 打开 PDF 文件
                if os.path.exists(file_path):
                    os.startfile(file_path)  # Windows 系统
            if extension == ".xls" or extension == ".xlsx":
                if os.path.exists(file_path):
                    open_ledger(file_path)
            #print(name)
            #print(extension)
        if my_type=="open_ledger_file":
            file_path = data["file_path"]
            name, extension = os.path.splitext(os.path.basename(file_path))
            if extension == ".xls" or extension==".xlsx":
                if os.path.exists(file_path):
                    open_ledger(file_path)

        return return_json
