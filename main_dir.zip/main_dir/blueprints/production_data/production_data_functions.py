import os
import re
import shutil
import sqlite3
import tkinter
from tkinter import filedialog
patterns = [
        (r'^(\d{4})\.(\d{1,2})\.(\d{1,2})(ONC大中小砾石运输确认单|ONC大中小砾石确认单|ONC大中小砾石运输确认单（待确认）|ONC褐铁矿运输确认单|ONC褐铁矿运输确认单（待确认）|ONC-MHP过磅日报|ONC过磅明细)\.pdf$', r'onc/基本数据/{date}'),
        (r'^(\d{4})\.(\d{1,2})\.(\d{1,2})-(\d{1,2})(ONC-MHP质量证明书)\.pdf$', r'onc/质量证明/MHP/{date_range}'),
        (r'^ONC褐铁矿质量证明(\d{4})年(\d{1,2})月(\d{1,2})日(?:-(\d{1,2})日)?.pdf$', r'onc/质量证明/褐铁矿/{date_range}'),
        (r'^(\d{4})\.(\d{1,2})\.(\d{1,2})-(\d{1,2})(ONC褐铁矿质量证明书)\.pdf$', r'onc/质量证明/褐铁矿/{date_range}'),
        (r'^(\d{4})\.(\d{1,2})\.(\d{1,2})(ONC褐铁矿质量证明书)\.pdf$', r'onc/质量证明/褐铁矿/{date_range}'),

        (r'^(\d{4})\.(\d{1,2})\.(\d{1,2})(HPL大中小砾石确认单|HPL大中小块砾石确认单|HPL大中小砾石运输确认单（待确认）|HPL大中小块砾石确认单（待确认）|HPL大中小砾石确认单（待确认）|HPL褐铁矿运输确认单|HPL褐铁矿运输确认单（待确认）|HPL-MHP过磅日报|过磅明细)\.pdf$', r'hpal/基本数据/{date}'),
        (r'^(\d{4})\.(\d{1,2})\.(\d{1,2})-(\d{1,2})(HPL-MHP质量证明)\.pdf$', r'hpal/质量证明/MHP/{date_range}'),
        (r'^HPL褐铁矿质量证明(\d{4})年(\d{1,2})月(\d{1,2})日(?:-(\d{1,2})日)?.pdf$', r'hpal/质量证明/褐铁矿/{date_range}'),
        (r'^(\d{4})\.(\d{1,2})\.(\d{1,2})-(\d{1,2})(HPL褐铁矿质量证明书)\.pdf$', r'hpal/质量证明/褐铁矿/{date_range}'),
        (r'^(\d{4})\.(\d{1,2})\.(\d{1,2})(HPL褐铁矿质量证明书)\.pdf$', r'hpal/质量证明/褐铁矿/{date_range}'),
        (r'^(\d{4})\.(\d{1,2})\.(\d{1,2})(硫酸镍质量证明)\.pdf$', r'hpal/质量证明/硫酸镍/{date}'),
        (r'^(\d{4})\.(\d{1,2})\.(\d{1,2})-(\d{1,2})(电解钴质量证明)\.pdf$', r'hpal/质量证明/电解钴/{date_range}')
    ]
pattersfortest=[
(r'ONC褐铁矿运输确认单'),
(r'ONC大中小砾石'),
(r'ONC-MHP过磅日报'),
(r'ONC-MHP质量证明书'),
(r'ONC褐铁矿质量证明'),
(r'HPL褐铁矿运输确认单'),
(r'HPL大中小'),
(r'HPL-MHP过磅日报'),
(r'HPL-MHP质量证明'),
(r'HPL褐铁矿质量证明'),
(r'硫酸镍质量证明'),
(r'硫酸钴质量证明'),
    (r'电解钴'),
]
def open_file_dialog():
    file_path = ""
    dialog = tkinter.Toplevel()  # 创建对话窗口
    dialog.withdraw()  # 隐藏对话窗口
    dialog.geometry("300x150")
    dialog.attributes("-topmost", True)  # 设置对话窗口为置顶
    def on_file_select():  # 文件选择功能
        file_path = filedialog.askopenfilename(parent=dialog, title="Select a file")
        if file_path:
            print(f"Selected file: {file_path}")
        dialog.destroy()  # 关闭对话窗口
        return file_path
    file_path = on_file_select()
    return file_path
def open_folder_dialog():
    file_path = ""
    dialog = tkinter.Tk()  # 创建主窗口
    dialog.withdraw()  # 隐藏主窗口
    dialog.geometry("300x150")
    dialog.attributes("-topmost", True)  # 设置对话窗口为置顶

    def on_file_select():  # 文件选择功能
        nonlocal file_path
        file_path = filedialog.askdirectory(parent=dialog, title="Select a folder")
        if file_path:
            print(f"Selected file: {file_path}")
        dialog.destroy()  # 关闭对话窗口

    dialog.after(0, on_file_select)  # 将文件选择功能放到事件循环中
    dialog.mainloop()  # 开始事件循环
    return file_path
def insert_basic_db(my_key,my_value):
    connection = sqlite3.connect('basic_data.db')
    # 创建一个游标对象
    cursor = connection.cursor()
    # 插入数据
    cursor.execute('''
                    INSERT OR REPLACE INTO file_paths (id, file_name, file_path) VALUES (
                        (SELECT id FROM file_paths WHERE file_name = ?),
                        ?, ?
                    )
                    ''',
                   (my_key, my_key, my_value))
    connection.commit()  # 提交事务
    # 关闭游标和连接
    cursor.close()
    connection.close()
def get_value_from_basic_db(my_key):
    connection = sqlite3.connect('basic_data.db')
    cursor = connection.cursor() # 创建一个游标对象
    cursor.execute("SELECT * FROM file_paths where file_name='"+my_key+"'")   # 执行查询
    rows = cursor.fetchall()# 获取所有结果
    #print("查询结果：") # 打印查询结果
    my_value=""
    for row in rows:
        #print(row)
        my_value= row[2]
    # 关闭游标和连接
    cursor.close()
    connection.close()
    return my_value
def my_merge(source_folder_path, destination_folder_path):
    return_data = {"irregular_files": [], "merge_status": "文件名不符合规则"}
    global patterns

    def format_date(match):
        year, month, day_start = match.group(1), match.group(2).zfill(2), match.group(3).zfill(2)
        day_end = match.group(4).zfill(2) if match.group(4) else None
        # 判断 day_end 是否为数字
        if day_end is not None and not day_end.isdigit():
            day_end = None
        if day_end and int(day_end) < int(day_start):
            month = str(int(month) + 1).zfill(2)
            if int(month) > 12:
                month = "01"
                year = str(int(year) + 1)
        return f"{year}{month}{day_start}-{year}{month}{day_end}" if day_end else f"{year}{month}{day_start}"

    #for files in os.listdir(source_folder_path):
    for file_name in os.listdir(source_folder_path):
        print("当前重分类文件名:"+file_name)
        source_file=source_folder_path+"/"+file_name
        #source_file = os.path.join(root, file_name)
        for pattern, target_path_template in patterns:
            match = re.match(pattern, file_name)
            if match:
                print("当前重分类文件名符合规范:" + file_name)
                date_str = format_date(match)
                target_directory = destination_folder_path + "/" + target_path_template.format(date=date_str, date_range=date_str)
                #destination_file = os.path.join(target_directory, file_name)
                destination_file=destination_folder_path+"/"+target_path_template.format(date=date_str, date_range=date_str)+"/"+file_name
                if not os.path.exists(target_directory):
                    os.makedirs(target_directory)
                print("当前文件路径:"+source_file)
                print("重分类文件路径:"+destination_file)
                if os.path.exists(destination_file):
                    os.chmod(destination_file, 0o777)  # 设置文件为可读写

                # 使用shutil.copy2进行文件复制
                shutil.copy2(source_file, destination_file)
                # 移除只读属性
                if os.path.isfile(source_file):
                    os.chmod(source_file, 0o777)  # 将文件权限设置为可读、可写、可执行
                try:
                    os.remove(source_file)
                    print(f"当前文件重分类成功: {source_file}")
                except PermissionError as e:
                    print(f"PermissionError: {e}")
                except FileNotFoundError as e:
                    print(f"FileNotFoundError: {e}")
                except Exception as e:
                    print(f"Unexpected error: {e}")
                return_data["merge_status"] = "success"
                break
            else:
                print("当前重分类文件名不符合规范:" + file_name)
        else:
            return_data["irregular_files"].append(file_name)
    return return_data
def merge_test(file_name):
    global pattersfortest
    for pattern in pattersfortest:
        match = re.search(pattern, file_name)
        if match:
            return 1
    return 0