import tkinter
from flask import Blueprint, render_template, request, jsonify
from tkinter import filedialog



from blueprints.qing_gou_local.qing_gou import qing_gou_main_start

def open_file_dialog():
    file_path = ""
    dialog = tkinter.Toplevel()  # 创建对话窗口
    dialog.withdraw()  # 隐藏对话窗口
    dialog.geometry("300x150")
    dialog.attributes("-topmost", True)  # 设置对话窗口为置顶
    def on_file_select():  # 文件选择功能
        file_path = filedialog.askopenfilename(parent=dialog, title="Select a file")
        if file_path:
            print(f"Selected file: {file_path}")
        dialog.destroy()  # 关闭对话窗口
        return file_path
    file_path = on_file_select()
    return file_path




# 创建一个蓝图实例
qing_gou_local_blueprint = Blueprint('qing_gou_local_blueprint', __name__)
@qing_gou_local_blueprint.route('/qing_gou_local')
def qing_gou_local_home():
    return render_template("qing_gou/qing_gou_local_home.html")
@qing_gou_local_blueprint.route('qing_gou_local_upload_path',methods=["post"])
def qing_gou_local_upload_path():
    return_json= {'status': 'success'}
    if request.method == 'POST':
        data = request.get_json()
        my_type=data["my_type"]
        if my_type=="upload_path":
            qing_gou_file_path=open_file_dialog()
            if qing_gou_file_path=="":
                #没有选择文件
                print("没有选中文件")
            else:
                status=qing_gou_main_start(qing_gou_file_path)

                return_json["status"]=status


        return jsonify(return_json)
    else:
        return "This is a GET request"