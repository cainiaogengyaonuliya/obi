import ctypes
import re
import time

import xlwings as xw
from pywinauto import Application

def set_excel_window_maximized(app):
    excel_hwnd = app.api.Hwnd # 获取Excel应用程序窗口句柄
    app_window = Application().connect(handle=excel_hwnd) # 使用pywinauto连接到Excel窗口
    app_window.top_window().set_focus() # 设置Excel窗口置顶
    ctypes.windll.user32.SetWindowPos(excel_hwnd, -1, 0, 0, 0, 0, 0x0001)  # -1 表示置顶
    app_window.top_window().maximize() # 最大化Excel窗口
def jump_color_delete_column(column,sht): #(column,列名参数形式("D2"))
    sleeptime = 0.1
    sht.api.Range(column).Select()  # Select cell AD2
    time.sleep(sleeptime)
    column2=re.sub(r'\d+$', '', column)
    column2=column2+":"+column2#"D:D"
    sht.range(column2).color = (255, 0, 0)
    time.sleep(sleeptime)
    sht.range(column).api.EntireColumn.Delete()
    time.sleep(sleeptime)
def merge_color(range,color_p,new_value,sht):
    sleeptime=0.1
    a = range.split(':')[0]
    sht.api.Range(a).Select()
    time.sleep(sleeptime)
    sht.range(range).api.Merge()
    time.sleep(sleeptime)
    sht.range(range).color = color_p
    time.sleep(sleeptime)
    sht.range(range).value=new_value
    sht.range(range).api.HorizontalAlignment = -4108
    sht.range(range).api.Font.Bold = True

    # 选择范围
    range = sht.range(range)

    # 添加所有框线
    range.api.Borders(xw.constants.BordersIndex.xlEdgeBottom).LineStyle = xw.constants.LineStyle.xlContinuous
    range.api.Borders(xw.constants.BordersIndex.xlEdgeTop).LineStyle = xw.constants.LineStyle.xlContinuous
    range.api.Borders(xw.constants.BordersIndex.xlEdgeLeft).LineStyle = xw.constants.LineStyle.xlContinuous
    range.api.Borders(xw.constants.BordersIndex.xlEdgeRight).LineStyle = xw.constants.LineStyle.xlContinuous
    range.api.Borders(xw.constants.BordersIndex.xlInsideVertical).LineStyle = xw.constants.LineStyle.xlContinuous
    range.api.Borders(xw.constants.BordersIndex.xlInsideHorizontal).LineStyle = xw.constants.LineStyle.xlContinuous
    range.api.Borders(xw.constants.BordersIndex.xlEdgeBottom).Weight = 2
    range.api.Borders(xw.constants.BordersIndex.xlEdgeTop).Weight = 2
    range.api.Borders(xw.constants.BordersIndex.xlEdgeLeft).Weight = 2
    range.api.Borders(xw.constants.BordersIndex.xlEdgeRight).Weight = 2
    range.api.Borders(xw.constants.BordersIndex.xlInsideVertical).Weight = 2
    range.api.Borders(xw.constants.BordersIndex.xlInsideHorizontal).Weight = 2

    range.api.Borders(xw.constants.BordersIndex.xlEdgeBottom).Color = xw.utils.rgb_to_int((0, 0, 0))  # 黑色
    range.api.Borders(xw.constants.BordersIndex.xlEdgeTop).Color = xw.utils.rgb_to_int((0, 0, 0))  # 黑色
    range.api.Borders(xw.constants.BordersIndex.xlEdgeLeft).Color = xw.utils.rgb_to_int((0, 0, 0))  # 黑色
    range.api.Borders(xw.constants.BordersIndex.xlEdgeRight).Color = xw.utils.rgb_to_int((0, 0, 0))  # 黑色
    range.api.Borders(xw.constants.BordersIndex.xlInsideVertical).Color = xw.utils.rgb_to_int((0, 0, 0))  # 黑色
    range.api.Borders(xw.constants.BordersIndex.xlInsideHorizontal).Color = xw.utils.rgb_to_int((0, 0, 0))  # 黑色
def color(range,color_p,sht):
    sleeptime = 0.1
    a=range.split(':')[0]
    sht.api.Range(a).Select()
    time.sleep(sleeptime)
    sht.range(range).color = color_p
    time.sleep(sleeptime)
    sht.range(range).api.HorizontalAlignment = -4108
    sht.range(range).api.Font.Color = 0  # 0 表示黑色

    # 选择范围
    range = sht.range(range)

    # 添加所有框线
    range.api.Borders(xw.constants.BordersIndex.xlEdgeBottom).LineStyle = xw.constants.LineStyle.xlContinuous
    range.api.Borders(xw.constants.BordersIndex.xlEdgeTop).LineStyle = xw.constants.LineStyle.xlContinuous
    range.api.Borders(xw.constants.BordersIndex.xlEdgeLeft).LineStyle = xw.constants.LineStyle.xlContinuous
    range.api.Borders(xw.constants.BordersIndex.xlEdgeRight).LineStyle = xw.constants.LineStyle.xlContinuous
    range.api.Borders(xw.constants.BordersIndex.xlInsideVertical).LineStyle = xw.constants.LineStyle.xlContinuous
    range.api.Borders(xw.constants.BordersIndex.xlInsideHorizontal).LineStyle = xw.constants.LineStyle.xlContinuous
    range.api.Borders(xw.constants.BordersIndex.xlEdgeBottom).Weight =2
    range.api.Borders(xw.constants.BordersIndex.xlEdgeTop).Weight = 2
    range.api.Borders(xw.constants.BordersIndex.xlEdgeLeft).Weight = 2
    range.api.Borders(xw.constants.BordersIndex.xlEdgeRight).Weight = 2
    range.api.Borders(xw.constants.BordersIndex.xlInsideVertical).Weight =2
    range.api.Borders(xw.constants.BordersIndex.xlInsideHorizontal).Weight = 2

    range.api.Borders(xw.constants.BordersIndex.xlEdgeBottom).Color = xw.utils.rgb_to_int((0, 0, 0))  # 黑色
    range.api.Borders(xw.constants.BordersIndex.xlEdgeTop).Color = xw.utils.rgb_to_int((0, 0, 0))  # 黑色
    range.api.Borders(xw.constants.BordersIndex.xlEdgeLeft).Color = xw.utils.rgb_to_int((0, 0, 0))  # 黑色
    range.api.Borders(xw.constants.BordersIndex.xlEdgeRight).Color =xw.utils.rgb_to_int((0, 0, 0))  # 黑色
    range.api.Borders(xw.constants.BordersIndex.xlInsideVertical).Color = xw.utils.rgb_to_int((0, 0, 0))  # 黑色
    range.api.Borders(xw.constants.BordersIndex.xlInsideHorizontal).Color = xw.utils.rgb_to_int((0, 0, 0))  # 黑色
def qing_gou_main_start(file_path):
    app = xw.App(visible=False, add_book=False)

    wb = app.books.open(file_path)  # 打开Excel文件
    sheet=wb.sheets[0]
    查询日期=sheet.range(3,2).value
    库存组织=sheet.range(6,2).value
    库存组织2=""
    if 库存组织=="PT. OBI NICKEL COBALT":
        库存组织2="ONC"
    if 库存组织=="PT. HALMAHERA PERSADA LYGEND":
        库存组织2="HPAL"
    wb.close()
    #app.quit()

    if 库存组织2=="":
        print("第六行第二列不是ONC或者HPAL，非标准文件，终止")
        return ""
    try:
        file_path_new = file_path[:-len(file_path.split("/")[-1])] + 库存组织2+"-请购单执行情况查询("+查询日期.replace("-","")+").xlsx"
    except:
        return ""
    print("请购单执行情况表文件路径:"+file_path_new)



    wb = app.books.open(file_path) # 打开Excel文件
    wb.save(file_path_new)# 另存为.xlsx格式
    wb.close()

    app.visible = True
    wb = app.books.open(file_path_new)  # 打开Excel文件
    set_excel_window_maximized(app)
    sht = wb.sheets[0]
    sht.name = 库存组织2+"-请购单执行情况查询"+查询日期.replace("-","")
    sht.range('a1').api.EntireRow.Delete()

    jump_color_delete_column("AD2", sht)
    jump_color_delete_column("X2", sht)
    jump_color_delete_column("W2", sht)
    jump_color_delete_column("S2", sht)
    jump_color_delete_column("I2", sht)
    jump_color_delete_column("H2", sht)

    #sht.range("A1:AB2").color = (181, 198, 234)
    sht.range("A1:AB2").api.Font.Color = 0  # 0 表示黑色
    #time.sleep(1)
    merge_color('A3:P3', (255, 255, 0), "请购", sht)
    merge_color('Q3:T3', (255, 192, 0), "订单", sht)
    merge_color('U3:W3', (0, 176, 240), "到货", sht)
    merge_color('X3:AB3', (146, 208, 80), "入库", sht)

    color('A4:P4', (255, 255, 0), sht)
    color('Q4:T4', (255, 192, 0), sht)
    color('U4:W4', (0, 176, 240), sht)
    color('X4:AB4', (146, 208, 80), sht)
    wb.save()

    print("请购单执行情况执行完毕")
    # app.quit()
    return file_path_new


#pathaa=r"D:\Desktop\请购单执行情况查询.xls"
#qing_gou_main_start(pathaa)
