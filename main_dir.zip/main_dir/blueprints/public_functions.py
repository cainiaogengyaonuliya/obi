import ctypes

from pywinauto import Application


def set_excel_window_maximized(app):
    excel_hwnd = app.api.Hwnd# 获取Excel应用程序窗口句柄
    app_window = Application().connect(handle=excel_hwnd)# 使用pywinauto连接到Excel窗口
    app_window.top_window().set_focus()# 设置Excel窗口置顶
    ctypes.windll.user32.SetWindowPos(excel_hwnd, -1, 0, 0, 0, 0, 0x0001)  # -1 表示置顶
    app_window.top_window().maximize()# 最大化Excel窗口