import tkinter as tk
import os
import signal
import shutil
import sys

current_version = "6"
root = tk.Tk()


def create_gui():
    global root

    def on_closing():
        os.kill(os.getpid(), signal.SIGINT)
        root.destroy()

    root.geometry("400x350")
    root.protocol("WM_DELETE_WINDOW", on_closing)

    # Button to create a copy of the script
    copy_button = tk.Button(root, text="Create a Copy", command=create_copy)
    copy_button.pack(pady=10)

    # Button to update the password
    update_button = tk.Button(root, text="Update Password", command=lambda: update_password("{'user_password':'456'}"))
    update_button.pack(pady=10)

    root.mainloop()


def create_copy():
    # Determine the correct path to the script
    if getattr(sys, 'frozen', False):
        script_path = sys.executable
    else:
        script_path = __file__

    # Create a copy of the current script
    copy_name = f"{os.path.basename(script_path)}"

    # Use shutil to copy the script
    #shutil.copy(script_path, copy_name)



    # Append 1024 bytes of memory (or custom data) to the copied script
    with open(copy_name, "ab") as f:
        # Create 1024 bytes of dummy data
        dummy_data = b'\0' * 1024  # Change as needed
        f.write(dummy_data)  # Append the dummy data to the copied script


def update_password(new_password):
    # Determine the correct path to the copied script
    #copied_script_name = f"copy_of_{os.path.basename(__file__)}"  # Change as necessary

    if getattr(sys, 'frozen', False):
        # 获取当前可执行文件的完整路径
        executable_path = sys.executable

        # 提取文件名
        executable_name = os.path.basename(executable_path)

        # 在文件名前添加前缀 "copy_of"
        new_file_name = f"copy_of_{executable_name}"

        # 获取可执行文件的目录
        executable_directory = os.path.dirname(executable_path)

        # 构造新文件的完整路径
        copied_script_path = os.path.join(executable_directory, new_file_name)
    else:
        #copied_script_path = os.path.join(os.path.dirname(__file__), copied_script_name)
        pass
    print("copied_script_path")
    print(copied_script_path)
    # Read the last 1024 bytes of the copied script
    try:
        with open(copied_script_path, "r+b") as f:
            # Seek to the end of the file
            f.seek(0, os.SEEK_END)
            end_position = f.tell()
            start_position = max(0, end_position - 1024)  # Start position for the last 1024 bytes

            # Write the new password line directly
            f.seek(start_position)  # Go back to the start of the last 1024 bytes
            f.write(new_password.encode('utf-8'))  # Write the new password line

    except FileNotFoundError:
        print(f"{copied_script_path} not found.")


if __name__ == "__main__":
    create_gui()  # Run the GUI
