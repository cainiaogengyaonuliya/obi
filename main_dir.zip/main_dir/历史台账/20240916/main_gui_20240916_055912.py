import json
import multiprocessing
import shutil
import subprocess
import sys
import time
import tkinter as tk
import threading
import webbrowser
import os
import signal
import io
import sqlite3
import logging
from tkinter import messagebox
from urllib.parse import unquote

from main_flask import app
import requests
current_version="1"
class RedirectText(io.StringIO):
    def __init__(self, text_widget):
        super().__init__()
        self.text_widget = text_widget

    def write(self, text):
        self.text_widget.insert(tk.END, text)  # 在文本框中插入文本
        self.text_widget.see(tk.END)  # 滚动到文本框的底部
def run_flask():
    # 设置Flask日志记录到Tkinter文本框
    # 设置Flask日志记录到Tkinter文本框
    logger = logging.getLogger('werkzeug')
    logger.setLevel(logging.INFO)
    stream_handler = logging.StreamHandler(sys.stdout)
    logger.addHandler(stream_handler)
    app.run(host="0.0.0.0",debug=False)
def get_image_path(filename):
    """根据文件名获取图片路径，无论是否被打包"""
    # 如果被 PyInstaller 打包
    if getattr(sys, 'frozen', False):
        base_path = sys._MEIPASS  # 打包后的临时路径
    else:
        base_path = os.path.dirname(os.path.abspath(__file__))  # 开发时路径

    return os.path.join(base_path, 'static', filename)

root = tk.Tk()
def check_for_updates(main_executable,link):
    global root,current_version
    try:
        update_url = "https://steep-mode-8f0c.x2259026163.workers.dev/"
        response = requests.get(update_url)
        print(response.text)
        response.raise_for_status()

        # 原始 JSON 字符串
        #response_text = r'{"是否更新":"是","更新类型":"网络磁盘","更新地址":"\\\\192.168.130.25\\finance\\ONC-----------共享资料\\临时可删除\\main_gui.exe"}'
        # 替换单个反斜杠为双反斜杠以确保 JSON 格式正确
        response_text = response.text.replace('\\', '\\\\')
        #{"是否更新": "是", "更新类型": "网络磁盘","更新地址": "\\192.168.130.25\finance\ONC-----------共享资料\临时可删除\main_gui.exe"}
        # 解析 JSON 字符串
        data = json.loads(response_text)

        # 访问值
        is_update = data["是否更新"]
        update_type = data["更新类型"]
        update_address = data["更新地址"]

        # 打印值
        print("是否更新:", is_update)
        print("更新类型:", update_type)
        print("更新地址:", update_address)
        最新版本=data["最新版本"]
        if is_update == "是" and current_version!=最新版本:
            # 创建超链接标签
            link.config(text="有更新，点击查看")
            link.bind("<Button-1>", lambda event: show_link_popup(event, data,main_executable))
            #result = messagebox.askyesno("Update Available", "A new update is available. Do you want to update now?")
            print("123")
        else:
            link.config(text="当前已是最新版本")







    except Exception as e:
        messagebox.showerror("Error", f"Failed to check for updates: {e}")
def show_link_popup(event,data,main_executable):
    # 弹出确认对话框
    result = messagebox.askyesno("可更新", "有新版本，是否需要更新?")
    if result:
        print("User chose to update.")
        update_address = unquote(data["更新地址"])
        download_update(update_address, main_executable)

        # 在这里添加更新逻辑
    else:
        print("User chose not to update.")
def download_update(update_path, main_executable):
    # 创建 copy.bat 文件
    batch_content = """@echo off
    echo starting
    ping -n 2 127.0.0.1 > nul
    echo copy
    del main_gui.exe
    copy temp_main_gui.exe main_gui.exe /Y
    echo finished
    del temp_main_gui.exe
    ping -n 2 127.0.0.1 > nul
    echo done
    exit
    """

    # 将内容写入 copy.bat 文件
    with open('updater.bat', 'w') as bat_file:
        bat_file.write(batch_content)
    try:
        temp_update_path = os.path.join(os.getcwd(), "temp_main_gui.exe")

        # 复制更新文件到临时路径
        shutil.copyfile(update_path, temp_update_path)

        # 启动子进程来处理更新和重启
        #process = multiprocessing.Process(target=apply_update_and_restart, args=(temp_update_path, main_executable))
        #process.start()
        subprocess.Popen(f'updater.bat')
        # 关闭主程序
        os.kill(os.getpid(), signal.SIGINT)

    except Exception as e:
        messagebox.showerror("Error", f"Failed to download or apply the update: {e}")
def apply_update_and_restart(temp_update_path, main_executable):
    # 等待主程序关闭
    time.sleep(2)

    try:
        subprocess.Popen(f'updater.bat')
        # 备份旧程序文件（可选）
        backup_path = main_executable + ".bak"
        print("here")
        if os.path.exists(backup_path):
            os.remove(backup_path)
        shutil.move(main_executable, backup_path)

        # 替换旧文件为更新文件
        shutil.move(temp_update_path, main_executable)

        # 重启主程序

        #subprocess.Popen([main_executable])

    except Exception as e:
        print(f"Update failed: {e}")
        sys.exit(1)
# 创建GUI的函数


def create_gui():
    global root
    def on_closing():
        # 关闭窗口时，发送信号关闭Flask服务器
        os.kill(os.getpid(), signal.SIGINT)
        root.destroy()

    def open_flask_page():
        # 打开Flask服务器的网页地址
        webbrowser.open("http://127.0.0.1:5000/home")

    def toggle_topmost():
        # 切换窗口的置顶状态
        is_topmost = root.attributes('-topmost')
        root.attributes('-topmost', not is_topmost)

    root.title("引导程序主界面")
    root.geometry("400x350")
    root.configure(bg="#f0f0f0")  # 设置背景颜色
    # 设置窗口图标，指定图标文件路径
    image_path = get_image_path('loyalty.ico')
    root.iconbitmap(image_path)

    button1 = tk.Button(root, text="打开网页", command=open_flask_page ,width=15, height=2,)
    button1.pack(pady=10)

    # 创建置顶按钮
    # 创建顶部按钮框架
    top_button_frame = tk.Frame(root)
    top_button_frame.pack(pady=5)
    # 创建置顶按钮
    topmost_button = tk.Button(top_button_frame, text="置顶", command=toggle_topmost, width=15)
    topmost_button.pack(side=tk.LEFT, padx=5)
    # 添加状态栏
    status_label = tk.Label(root, text="状态栏", anchor='w')
    status_label.pack(fill=tk.X, padx=10, pady=(5, 0))
    # 创建输出文本框
    output_text = tk.Text(root, wrap=tk.WORD, height=10)
    output_text.pack(pady=10, padx=10, fill=tk.BOTH, expand=True)
    # 设置窗口关闭时的回调
    # 重定向print输出到输出文本框
    sys.stdout = RedirectText(output_text)




    root.protocol("WM_DELETE_WINDOW", on_closing)
    print("程序已启动")

    # 创建一个标签，作为超链接
    link = tk.Label(root, text="", fg="blue", cursor="hand2")
    link.pack(side="bottom", pady=10)  # 添加到窗口底部，并设置间距

    # 启动一个线程来检查更新
    update_thread = threading.Thread(target=check_for_updates, args=(sys.argv[0], link))
    update_thread.daemon = True  # 设置为守护线程，确保主线程退出时该线程也退出
    update_thread.start()
    #check_for_updates(sys.argv[0])
    root.mainloop()
    print("66666666666666666666")

def init_sqlite():
    connection = sqlite3.connect('basic_data.db')
    # 创建一个游标对象
    cursor = connection.cursor()
    # 创建一个表，只有在表不存在时才会创建
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS file_paths(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            file_name TEXT NOT NULL,
            file_path TEXT
        )
        ''')
    # 提交事务
    connection.commit()
    # 关闭游标和连接
    cursor.close()
    connection.close()
if __name__ == "__main__":
    init_sqlite()
    # 创建并启动Flask线程
    flask_thread = threading.Thread(target=run_flask)
    flask_thread.daemon = True  # 设置为守护线程，在主线程结束时自动关闭
    flask_thread.start()
    # 运行GUI
    create_gui()
