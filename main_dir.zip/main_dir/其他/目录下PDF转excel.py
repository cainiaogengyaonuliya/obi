import fnmatch
import os

from spire.pdf import *
from openpyxl import load_workbook

# 获取当前目录
pdf_directory = os.getcwd() #eg:D:\xu\code\pycharm\pythonProject
pdf_directory=r"F:\xu\生产台账临时文件夹"
print(pdf_directory)
pdf_files = []# 初始化一个空列表来存储PDF文件

# 遍历当前目录中的文件
for file in os.listdir(pdf_directory):
    if fnmatch.fnmatch(file, '*.pdf'):
        pdf_files.append(file)

print(pdf_files)


def convertpdf(filename,pdf_directory):
    # 创建PdfDocument对象
    pdf = PdfDocument()

    # 加载PDF文档
    pdf.LoadFromFile(pdf_directory+"\\"+filename)

    # 创建 XlsxLineLayoutOptions 对象来指定转换选项
    convertOptions = XlsxLineLayoutOptions(True, True, False, True, False)

    # 设置转换选项
    pdf.ConvertOptions.SetPdfToXlsxOptions(convertOptions)

    # 将PDF文档保存为Excel XLSX格式
    pdf.SaveToFile(pdf_directory+"\\"+filename[:-3]+"xlsx", FileFormat.XLSX)
    pdf.Close()

def strip_and_number_convert(filename,pdf_directory):
    # 加载Excel文件
    wb = load_workbook(pdf_directory+"\\"+filename)
    ws = wb.active
    # 处理数据
    for row in ws.iter_rows(min_row=1, max_row=100, min_col=1, max_col=ws.max_column):
        for cell in row:
            if isinstance(cell.value, str):
                cell.value = cell.value.strip()
            if isinstance(cell.value, str):
                # 尝试将文本转换为数字
                try:
                    # 转换为浮点数
                    cell.value = float(cell.value)
                except ValueError:
                    # 如果转换失败，保持原值
                    pass

    # 保存到新Excel文件
    wb.save(pdf_directory+"\\"+filename)

for i in range(0,len(pdf_files)):
    convertpdf(pdf_files[i],pdf_directory)
    pass

for i in range(0,len(pdf_files)):
    pdf_files[i]=pdf_files[i][:-3]+"xlsx"

for i in range(0,len(pdf_files)):
    strip_and_number_convert(pdf_files[i],pdf_directory)