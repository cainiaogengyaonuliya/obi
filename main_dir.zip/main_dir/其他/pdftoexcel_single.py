import pdfplumber
from openpyxl.reader.excel import load_workbook
from openpyxl.workbook import Workbook


def strip_and_number_convert(excel_file_path):#清空空白字符串以及数字转换
    wb = load_workbook(excel_file_path) # 加载Excel文件
    ws = wb.active
    for row in ws.iter_rows(min_row=1, max_row=100, min_col=1, max_col=ws.max_column):# 处理数据
        for cell in row:
            if isinstance(cell.value, str):
                cell.value = cell.value.strip()
            if isinstance(cell.value, str): # 尝试将文本转换为数字
                try:
                    cell.value = float(cell.value)  # 转换为浮点数
                except ValueError:
                    pass# 如果转换失败，保持原值
    wb.save(excel_file_path) # 保存到新Excel文件
    wb.close()
# 示例使用



def pdf_to_excel(source_file,destination_file):
    pdf = pdfplumber.open(source_file)
    page = pdf.pages[0]# 选择第一个页面
    table = page.extract_table() # 提取表格
    workbook = Workbook() # 创建Excel工作簿
    sheet = workbook.active
    if table: # 将提取的表格数据写入Excel
        for row in table:
            sheet.append(row)  # 将每一行添加到工作表

        workbook.save(destination_file) # 保存Excel文件
        print(f"表格已成功提取并保存到 {destination_file}")
    else:
        print("未找到表格数据")
    pdf.close()# 关闭PDF文件
    strip_and_number_convert(destination_file)
pdf_file_path=r"F:\xu\生产台账\hpal\质量证明\褐铁矿\20240902-20240903\HPL褐铁矿质量证明2024年9月2日-3日.pdf"
excel_file_path = 'output4.xlsx'  # 输出的Excel文件路径
pdf_to_excel(pdf_file_path, excel_file_path)
