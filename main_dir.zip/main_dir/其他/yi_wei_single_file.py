import re

import xlwings
excel_path=r"D:\My Document\Desktop\清关\资料0820\221st Shipment\DRAFT CIPL\47. YWW2400035001XXHC MOTOR CARBON BRUSH.xlsx"
class YI_WEI_UNIT:
    my_order=""#序号
    company_name=""
    status="1"#是标准还是非标准
    invoice_number=""
    contract_number=""
    my_date=""
    voyage=""
    my_item_list=[]
    total_price=""
    currency=""
    def __init__(self):
        pass
def get_yi_wei_data_from_excel(excel_path):
    yi_wei_unit=YI_WEI_UNIT()
    #app = xlwings.App(visible=True, add_book=False)  # 创建一个不可见的 Excel 应用程序实例
    app = xlwings.App(visible=False, add_book=False)  # 创建一个不可见的 Excel 应用程序实例
    wb = app.books.open(excel_path) # 打开工作簿
    sheet = wb.sheets["INVOICE"] # 选择一个工作表
    company_name = sheet.range((3, 1)).value
    yi_wei_unit.company_name = company_name
    yi_wei_unit.my_order=excel_path.split("\\")[-1].split(".")[0]
    if company_name!="NINGBO YIWEI MINING CO., LTD":
        yi_wei_unit.status=0#print("不标准")
        wb.close()
        app.quit()
        return yi_wei_unit
    else:
        yi_wei_unit.company_name="宁波毅威"
    if sheet.range((14, 1)).value != "No":
        yi_wei_unit.status = 0#print("不标准")
        wb.close()
        app.quit()
        return yi_wei_unit
    yi_wei_unit.invoice_number=sheet.range((8, 2)).value
    yi_wei_unit.contract_number=sheet.range((8, 6)).value
    yi_wei_unit.my_date=sheet.range((9, 6)).value
    yi_wei_unit.voyage=sheet.range((13, 2)).value
    yi_wei_unit.currency = re.search(r'\((.*?)\)', sheet.range((14, 6)).value).group(1)
    for i in range(15, 300):
        my_json={}
        cell_value = sheet.range((i, 1)).value  # 获取单元格的值
        if isinstance(cell_value, (int, float)):  # 判断是否为数字
            print(f"第 {i} 行第 1 列的值是数字: {cell_value}")
            my_json["contract_no"]=sheet.range((i, 2)).value
            my_json["chinese_name"] = ''.join(re.findall(r'[\u4e00-\u9fff]+', (sheet.range((i, 3)).value))).strip()
            my_json["english_name"] = ''.join(re.findall(r'[A-Za-z ]+', (sheet.range((i, 3)).value))).strip()
            my_json["quantity"]=sheet.range((i, 4)).value
            my_json["quantity_unit"] = sheet.range((i, 5)).value
            my_json["unit_price"] = sheet.range((i, 6)).value
            my_json["total_price"] = sheet.range((i, 7)).value
            yi_wei_unit.my_item_list.append(my_json)
        else:
            print(f"第 {i} 行第 1 列的值不是数字: {cell_value}")
            yi_wei_unit.total_price= sheet.range((i, 1)).value
            break
    wb.close()
    app.quit()
    return yi_wei_unit
yi_wei_unit=get_yi_wei_data_from_excel(excel_path)
destination_path=r"D:\My Document\Desktop\清关\HPAL---清关发票明细台账(更新版）20240820-1 - 副本.xlsx"
def insert_destination(destination_path,yi_wei_unit):
    app = xlwings.App(visible=True, add_book=False)  # 创建一个不可见的 Excel 应用程序实例
    wb = app.books.open(destination_path)  # 打开工作簿
    sheet = next(sheet for sheet in wb.sheets if sheet.name.startswith("清关发票明细台账"))
    last_row = sheet.range('K1').end('down').row
    sheet.api.Rows(last_row).Select()  # 选择第 1 行
    insert_row=int(last_row)+1
    print(last_row)

    for i in range(0,len(yi_wei_unit.my_item_list)):
        sheet.range((insert_row+i, 1)).value = yi_wei_unit.my_order
        sheet.range((insert_row+i, 2)).value = "foldername"
        sheet.range((insert_row+i, 3)).value = yi_wei_unit.voyage
        sheet.range((insert_row+i, 3)).value = yi_wei_unit.voyage
        sheet.range((insert_row+i, 5)).value = yi_wei_unit.company_name
        sheet.range((insert_row + i, 7)).value=yi_wei_unit.my_item_list[i].get("chinese_name")
        sheet.range((insert_row + i, 8)).value = yi_wei_unit.my_item_list[i].get("english_name")
        sheet.range((insert_row + i, 11)).value = yi_wei_unit.invoice_number
        sheet.range((insert_row + i, 12)).value = yi_wei_unit.my_item_list[i].get("contract_no")
        sheet.range((insert_row + i, 13)).value = yi_wei_unit.my_item_list[i].get("quantity")
        sheet.range((insert_row + i, 14)).value = yi_wei_unit.my_item_list[i].get("quantity_unit")
        sheet.range((insert_row + i, 15)).value = yi_wei_unit.currency
        sheet.range((insert_row + i, 16)).value = yi_wei_unit.my_item_list[i].get("unit_price")
        sheet.range((insert_row + i, 17)).value = yi_wei_unit.my_item_list[i].get("total_price")
        sheet.range((insert_row + i, 18)).value = yi_wei_unit.my_date
        sheet.range((insert_row + i, 19)).value = yi_wei_unit.my_date.year
        sheet.range((insert_row + i, 20)).value="系统未做"
if(yi_wei_unit.status=="1"):
    insert_destination(destination_path,yi_wei_unit)
else:
    print("不标准文件，请检查")