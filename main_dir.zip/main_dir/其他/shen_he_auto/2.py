import os

import xlwings
from PIL import ImageGrab
import keyboard
import time
import cv2
import numpy as np

import pyperclip
from pywinauto import keyboard as kb
import tkinter as tk
from tkinter import messagebox
from pywinauto import mouse
def read_可签字去重表(shen_he_file_path):
    app = xlwings.App(visible=False, add_book=False)  # 创建一个不可见的 Excel 应用程序实例
    wb = app.books.open(shen_he_file_path, update_links=False)  # 打开工作簿
    # 选择要复制的工作表
    sht = wb.sheets["去重单据号"]  # 替换为你要复制的工作表名称
    last_row = sht.range(sht.cells.last_cell.row, 1).end('up').row
    data = sht.range((1,1),(last_row,1)).value  # 一次性读取前30行和30列的数据，减少I/O操作
    wb.close()  # 关闭工作簿
    app.quit()  # 退出应用程序
    return data
def screenshot():
    # 截取屏幕并保存为 screenshot.png
    screenshot = ImageGrab.grab()
    screenshot.save("screenshot.png")
    return "screenshot.png"

def find_image_position(screenshot_path, template_path):
    # 读取截图和模板图像
    screenshot = cv2.imread(screenshot_path)
    template = cv2.imread(template_path)

    # 获取模板的宽和高
    h, w, _ = template.shape
    # 使用模板匹配
    result = cv2.matchTemplate(screenshot, template, cv2.TM_CCOEFF_NORMED)
    threshold = 0.8  # 设置阈值
    yloc, xloc = np.where(result >= threshold)
    # 返回匹配的位置
    return [(x, y) for (x, y) in zip(xloc, yloc)]
def show_alert():
    # 创建主窗口
    root = tk.Tk()
    root.withdraw()  # 隐藏主窗口

    # 创建顶置弹窗
    root.attributes("-topmost", True)  # 设置窗口为置顶模式

    # 弹出消息框
    messagebox.showinfo("Alert", "程序已停止")

    # 关闭Tkinter窗口
    root.destroy()
def on_esc_pressed():
    global running_flag
    print("ESC pressed, exiting...")
    running_flag=0
    show_alert()
    # 使用 keyboard 的 unhook_all 停止所有的监听
    keyboard.unhook_all()
    os._exit(0)  # 强制终止整个进程
def click_position(position):
    # 等待一小段时间以确保系统准备好接收点击
    time.sleep(0.5)
    # 使用 pywinauto 模拟点击指定的坐标
    mouse.click(coords=position)



def run_program():
    screenshot_path = screenshot()# 截取屏幕
    # 查找 "a.png" 的位置
    查询位置 = find_image_position(screenshot_path, r"b.png")
    # 输出匹配到的位置
    if 查询位置:
        for pos in 查询位置:
            print(f"Found 'a.png' at position: {pos}")
        click_position(pos)
        清空值位置_flag=0
        for i in range(0,100):
            time.sleep(1)
            screenshot_path = screenshot()
            清空值位置 = find_image_position(screenshot_path, r"c.png")
            if 清空值位置:
                清空值位置_flag=1
                break
        if 清空值位置_flag:#已经打开窗口
            #粘贴
            time.sleep(0.5)
            # 将内容复制到剪贴板
            pyperclip.copy("010108,01011402")
            kb.send_keys('^v')
            time.sleep(0.5)
            # 发送两个 Tab 键
            kb.send_keys('{TAB}')
            time.sleep(0.5)
            kb.send_keys('{TAB}')
            time.sleep(0.5)
            pyperclip.copy("上月")
            time.sleep(0.5)
            kb.send_keys('^v')
            time.sleep(0.5)
            kb.send_keys('{TAB}')
            time.sleep(0.5)
            kb.send_keys('{TAB}')
            time.sleep(0.5)
            kb.send_keys('{TAB}')
            time.sleep(0.5)
            kb.send_keys('{TAB}')
            time.sleep(0.5)
            kb.send_keys('{TAB}')
            time.sleep(0.5)
            kb.send_keys('{TAB}')
            time.sleep(0.5)
            kb.send_keys('{TAB}')

    else:
        print("查询位置 No match found.")
    pass
def main():
    global running_flag
    print("按下 Ctrl+P 开始程序...")
    keyboard.wait('ctrl+q')
    running_flag=1
    # 设置全局监听 ESC 键的事件处理
    keyboard.add_hotkey('esc', on_esc_pressed)
    run_program()
#main()
shen_he_file_path=r"F:\xu\2.出库审核\工作区\0907\材料出库单列表onc20240907 - 副本 - 副本.xls"
read_可签字去重表(shen_he_file_path)




