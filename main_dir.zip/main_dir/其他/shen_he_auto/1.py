from PIL import ImageGrab

def take_screenshot(save_path="screenshot.png"):
    # 获取屏幕截图
    screenshot = ImageGrab.grab()
    # 将截图保存为文件
    screenshot.save(save_path)
    print(f"Screenshot saved to {save_path}")

# 调用函数并保存截图
take_screenshot("screenshot.png")
