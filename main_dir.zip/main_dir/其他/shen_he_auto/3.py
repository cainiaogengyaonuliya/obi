import ctypes
import os
import threading
import xlwings
from PIL import ImageGrab
import keyboard
import time
import cv2
import numpy as np
import pyperclip
from pywinauto import keyboard as kb
import tkinter as tk
from tkinter import messagebox
from pywinauto import mouse
业务日期位置=None
def 业务日期位置查询():
    global 业务日期位置
    screenshot_path = screenshot()  # 截取屏幕
    业务日期 = find_image_position(screenshot_path, r"h.png",0.8)
    if 业务日期:
        corrected_positions = [(x - 40, y + 10) for x, y in 业务日期]
        业务日期位置=corrected_positions[0]
        print("业务日期位置查询到")
        print(业务日期位置)
    else:
        print("业务日期位置查询不到")
        业务日期位置=None
    return 业务日期位置
def read_可签字去重表(shen_he_file_path):
    app = xlwings.App(visible=False, add_book=False)  # 创建一个不可见的 Excel 应用程序实例
    wb = app.books.open(shen_he_file_path, update_links=False)  # 打开工作簿
    sht = wb.sheets["可签字去重单据号"]  # 替换为你要复制的工作表名称
    last_row = sht.range(sht.cells.last_cell.row, 1).end('up').row
    data = sht.range((1, 1), (last_row, 4)).value  # 一次性读取前30行和30列的数据
    wb.close()  # 关闭工作簿
    app.quit()  # 退出应用程序
    return data

def screenshot():
    screenshot = ImageGrab.grab()# 截取屏幕并保存为 screenshot.png
    screenshot.save("screenshot.png")
    return "screenshot.png"

def find_image_position(screenshot_path, template_path,threshold):
    # 读取截图和模板图像
    screenshot = cv2.imread(screenshot_path)
    template = cv2.imread(template_path)
    h, w, _ = template.shape
    result = cv2.matchTemplate(screenshot, template, cv2.TM_CCOEFF_NORMED)
    #threshold = 0.8  # 设置阈值
    yloc, xloc = np.where(result >= threshold)
    return [(x, y) for (x, y) in zip(xloc, yloc)]

def show_alert():
    # 创建主窗口
    root = tk.Tk()
    root.withdraw()  # 隐藏主窗口
    root.attributes("-topmost", True)  # 设置窗口为置顶模式
    messagebox.showinfo("Alert", "程序已停止")
    root.destroy()  # 关闭窗口

# 定义一个例外类，用于在线程中抛出
class ThreadTerminationException(Exception):
    pass

def terminate_thread(thread):
    # 使用 ctypes 在线程中抛出异常
    if not thread.is_alive():
        return
    thread_id = ctypes.pythonapi.PyThreadState_SetAsyncExc(
        ctypes.c_long(thread.ident),
        ctypes.py_object(ThreadTerminationException)
    )
    if thread_id == 0:
        raise ValueError("Invalid thread ID")
    elif thread_id > 1:
        ctypes.pythonapi.PyThreadState_SetAsyncExc(thread.ident, None)
        raise SystemError("Failed to stop thread")

def on_esc_pressed(thread):
    print("ESC pressed. Terminating thread...")
    terminate_thread(thread)
def click_position(position):
    time.sleep(0.5)  # 等待一小段时间
    mouse.click(coords=position)  # 使用 pywinauto 模拟点击指定的坐标

def run_program(shen_he_file_path,出库类型):
    try:
        签字_1(shen_he_file_path, 出库类型)
    except ThreadTerminationException:
        print("Thread was terminated.")

def 签字_1(shen_he_file_path, 出库类型):
    app = xlwings.App(visible=True, add_book=False)  # 创建一个不可见的 Excel 应用程序实例
    wb = app.books.open(shen_he_file_path, update_links=False)  # 打开工作簿
    sheet = wb.sheets["可签字去重单据号"]
    data_list = read_可签字去重表(shen_he_file_path)
    for i in range(len(data_list)):
        if data_list[i][1] == 出库类型:
            print(data_list[i][0], data_list[i][1])
            if data_list[i][3]!=None and data_list[i][3]!="":
                continue

            return_data = 签字_2(data_list[i])
            if return_data["签字状态"]=="成功":
                sheet.range(i + 1, 4).select()
                sheet.range(i+1, 4).value = "已签字"
            if return_data["签字状态"] == "失败":
                sheet.range(i + 1, 4).value = "签字失败"
                show_alert()
                os._exit(0)  # 强制终止整个进程
def 签字完成位置查询():
    screenshot_path = screenshot()  # 截取屏幕
    签字完成 = find_image_position(screenshot_path, r"f.png",0.9)
    if 签字完成:
        corrected_positions = [(x + 20, y + 10) for x, y in 签字完成]
        签字完成位置=corrected_positions[0]
        print(" 签字完成位置查询到")
        print(签字完成位置)
    else:
        print(" 签字完成位置 查询不到")
        签字完成位置=None
    return 签字完成位置
def 签字_2(data_list):
    return_data={"签字状态":"失败"}

    global 业务日期位置
    sleeptile=0.2
    # 模拟按下 F3 键
    keyboard.press_and_release('F3')
    time.sleep(2)
    pyperclip.copy("010108,01011402")
    kb.send_keys('^v')
    time.sleep(sleeptile)
    kb.send_keys('{TAB}')
    time.sleep(sleeptile)
    kb.send_keys('{TAB}')
    time.sleep(sleeptile)
    pyperclip.copy("上月")
    time.sleep(sleeptile)
    kb.send_keys('^v')
    time.sleep(sleeptile)
    for _ in range(7):  # 发送多个 Tab 键
        kb.send_keys('{TAB}')
        time.sleep(sleeptile)
    print("粘贴板数据")
    print(data_list[0])
    print(data_list[1])
    pyperclip.copy(data_list[0])
    time.sleep(sleeptile)
    kb.send_keys('^v')
    time.sleep(sleeptile)
    keyboard.press_and_release('alt+y')
    time.sleep(0.5)
    if 业务日期位置 == None:
        业务日期位置=业务日期位置查询()
    #print(业务日期位置)
    if 业务日期位置!=None:
        click_position(业务日期位置)
        time.sleep(sleeptile)
        kb.send_keys('+{TAB}')
        time.sleep(sleeptile)

        # 模拟键盘打字 data_list[2]="2024-09-10"
        try:
            date_str = data_list[2].strftime('%Y-%m-%d')
            for char in date_str:
                keyboard.send(char)
                time.sleep(0.1)  # 确保每个字符间有足够的时间间隔
                print("try")
        except:
            for char in data_list[2]:
                keyboard.send(char)
                time.sleep(0.1)  # 确保每个字符间有足够的时间间隔
                print("except")
        #keyboard.write(date_str)

        time.sleep(1)
        # 模拟按下 Enter 键
        keyboard.press_and_release('enter')
        time.sleep(0.2)

        keyboard.press_and_release('enter')# 模拟按下 Enter 键
        time.sleep(0.3)
        keyboard.press_and_release('ctrl+g')
        ##回调
        签字完成flag=0
        for i in range(0,500):
            if 签字完成位置查询():#签字成功
                签字完成flag=1
                return_data["签字状态"]="成功"
                break
            else:#签字失败
                keyboard.press_and_release('ctrl+g')
                time.sleep(0.1)
        if 签字完成flag==1:
            return return_data
        if 签字完成flag==0:
            return return_data
    else:
        print("找不到业务日期")
        return return_data

def main(审核文件路径,出库类型):
    print("按下 Ctrl+Q 开始程序...")
    keyboard.wait('ctrl+q')


    thread = threading.Thread(target=run_program,args=(审核文件路径, 出库类型)) # 创建并启动线程
    keyboard.add_hotkey('esc', lambda: on_esc_pressed(thread)) # 设置全局监听 ESC 键的事件处理
    thread.start()
    thread.join() # 等待线程结束

    print("程序已终止.")
    show_alert()  # 直接调用显示警告
审核文件路径 = r"D:\Desktop\222222222\材料出库单列表ONC.xls"
出库类型 = "印尼办公及长期资产领用材料出库"
出库类型="印尼生产领用材料出库"
main(审核文件路径,出库类型)



