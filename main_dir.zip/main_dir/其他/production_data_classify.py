import os
import re
import shutil
def my_merge(source_folder_path, destination_folder_path):
    return_data = {"irregular_files": [], "merge_status": "文件名不符合规则"}
    patterns = [
        (r'^(\d{4})\.(\d{1,2})\.(\d{1,2})(ONC大中小砾石运输确认单|ONC大中小砾石确认单|ONC大中小砾石运输确认单（待确认）|ONC褐铁矿运输确认单|ONC褐铁矿运输确认单（待确认）|ONC-MHP过磅日报|ONC过磅明细)\.pdf$', r'onc\基本数据\{date}'),
        (r'^(\d{4})\.(\d{1,2})\.(\d{1,2})-(\d{1,2})(ONC-MHP质量证明书)\.pdf$', r'onc\质量证明\MHP\{date_range}'),
        (r'^ONC褐铁矿质量证明(\d{4})年(\d{1,2})月(\d{1,2})日(?:-(\d{1,2})日)?.pdf$', r'onc\质量证明\褐铁矿\{date_range}'),

        (r'^(\d{4})\.(\d{1,2})\.(\d{1,2})(HPL大中小砾石运输确认单|HPL大中小砾石运输确认单（待确认）|HPL褐铁矿运输确认单|HPL褐铁矿运输确认单（待确认）|HPL-MHP过磅日报|过磅明细)\.pdf$', r'hpal\基本数据\{date}'),
        (r'^(\d{4})\.(\d{1,2})\.(\d{1,2})-(\d{1,2})(HPL-MHP质量证明)\.pdf$', r'hpal\质量证明\MHP\{date_range}'),
        (r'^HPL褐铁矿质量证明(\d{4})年(\d{1,2})月(\d{1,2})日(?:-(\d{1,2})日)?.pdf$', r'hpal\质量证明\褐铁矿\{date_range}'),
        (r'^(\d{4})\.(\d{1,2})\.(\d{1,2})(硫酸镍质量证明)\.pdf$', r'hpal\质量证明\硫酸镍\{date}'),
        (r'^(\d{4})\.(\d{1,2})\.(\d{1,2})-(\d{1,2})(电解钴质量证明)\.pdf$', r'hpal\质量证明\电解钴\{date_range}')
    ]

    def format_date(match):
        year, month, day_start = match.group(1), match.group(2).zfill(2), match.group(3).zfill(2)
        day_end = match.group(4).zfill(2) if match.group(4) else None
        # 判断 day_end 是否为数字
        if day_end is not None and not day_end.isdigit():
            day_end = None
        if day_end and int(day_end) < int(day_start):
            month = str(int(month) + 1).zfill(2)
            if int(month) > 12:
                month = "01"
                year = str(int(year) + 1)
        return f"{year}{month}{day_start}-{year}{month}{day_end}" if day_end else f"{year}{month}{day_start}"

    for root, dirs, files in os.walk(source_folder_path):
        for file_name in files:
            source_file = os.path.join(root, file_name)
            for pattern, target_path_template in patterns:
                match = re.match(pattern, file_name)
                if match:
                    print(file_name)
                    date_str = format_date(match)
                    target_directory = destination_folder_path + "\\" + target_path_template.format(date=date_str, date_range=date_str)
                    destination_file = os.path.join(target_directory, file_name)
                    if not os.path.exists(target_directory):
                        os.makedirs(target_directory)
                    shutil.move(source_file, destination_file)
                    return_data["merge_status"] = "success"
                    break
            else:
                return_data["irregular_files"].append(file_name)
    return return_data


source_folder_path = r"D:\Desktop\abc"
dest = r"F:\xu\生产台账"
return_data=my_merge(source_folder_path, dest)
print(return_data["irregular_files"])
def my_verify(destination_path):
    pass