import os

a=r"F:/xu/生产台账临时文件夹/2024.9.22-9.23硫酸钴质量证明.pdf"
file_name = os.path.basename(a)
print(file_name)  # 输出：2024.9.22-9.23硫酸钴质量证明.pdf