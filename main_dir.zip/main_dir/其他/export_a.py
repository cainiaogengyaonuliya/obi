'''
各部门公共项目档案导出方案。
注意，在本目录下创建a.xlsx
在开始前先crtl+c，在ctrl+p,结束后注意收尾数据是否匹配
'''
import keyboard
import time

import pyperclip
import xlwings

app = xlwings.App(visible=True, add_book=False)  # 创建一个不可见的 Excel 应用程序实例
wb = app.books.open("./a.xlsx", update_links=False)  # 打开工作簿
sheet=wb.sheets[0]
def run_program():
    print("程序开始运行...")
    row = 1  # 从第一行开始粘贴
    while True:
        # 监听Esc键以退出循环
        if keyboard.is_pressed('esc'):
            print("程序已停止。")
            break
        # 在这里可以放置你要运行的逻辑
        keyboard.press_and_release('ctrl+c')
        clipboard_content = pyperclip.paste()
        print(clipboard_content)
        # 将剪贴板内容写入到 Excel 工作表
        sheet.cells(row, 1).value = clipboard_content


        row += 1  # 移动到下一行

        print("剪贴板内容:", clipboard_content)
        time.sleep(0.1)  # 用于降低CPU占用
        keyboard.press_and_release('down')  # 模拟按下下方向键
        time.sleep(0.1)  # 用于降低CPU占用

def main():
    print("按下 Ctrl+Q 开始程序...")
    keyboard.wait('ctrl+q')
    run_program()

if __name__ == "__main__":
    main()