import os
import tkinter
from tkinter import filedialog
def open_folder_dialog():
    file_path=""
    dialog = tkinter.Toplevel()# 创建对话窗口
    dialog.withdraw()# 隐藏对话窗口
    dialog.geometry("300x150")
    dialog.attributes("-topmost", True) # 设置对话窗口为置顶
    def on_file_select():# 文件选择功能
        file_path = filedialog.askdirectory(parent=dialog, title="Select a file")
        if file_path:
            print(f"Selected file: {file_path}")
        dialog.destroy()# 关闭对话窗口
        return file_path
    file_path=on_file_select()
    return file_path
def get_excel_file_path_list(folder_path):
    folder_path = folder_path.replace("/", "\\")  # D:\My Document\Desktop\清关\资料0820/221st Shipment/BL
    print(folder_path)
    excel_file_path_list = []

    for root, dirs, files in os.walk(folder_path):  # 遍历文件夹及其子文件夹中的所有文件和文件夹
        print(f'当前目录路径: {root}')
        # 输出所有子目录
        for dir_name in dirs:
            print(f'子目录: {os.path.join(root, dir_name)}')
        # 输出所有文件
        for file_name in files:
            print(f'文件: {os.path.join(root, file_name)}')
            if "~$" in file_name:  # 以 ~$ 开头的文件通常是由 Microsoft Office 程序（如 Word、Excel、PowerPoint）创建的临时文件。
                continue
            if file_name.split(".")[-1] == "xlsx" or file_name.split(".")[-1] == "xls":
                # print(os.path.join(root, file_name))
                F = os.path.join(root, file_name)
                print(F)
                excel_file_path_list.append(F)
    return excel_file_path_list
def my_folder_start():
    folder_path = open_folder_dialog()
    excel_file_path_list=get_excel_file_path_list(folder_path)
    yi_wei_excel_path_list=[]
    for i in range(0,len(excel_file_path_list)):
        file_name=excel_file_path_list[i].split("/")[-1].split(".")[1][0:3]
        if "YW" in file_name:
            yi_wei_excel_path_list.append(excel_file_path_list[i])
    print(yi_wei_excel_path_list)
    none_yi_wei_list=[]
    for i in range(0,len(excel_file_path_list)):
        if(excel_file_path_list[i] not in yi_wei_excel_path_list):
            none_yi_wei_list.append(excel_file_path_list[i])
    print(none_yi_wei_list)

    for i in range(0,len(yi_wei_excel_path_list)):
        pass