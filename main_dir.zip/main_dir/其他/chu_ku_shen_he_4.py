# -*- coding: utf-8 -*-

import xlwings
HPAL在建工程 = ['仓库2期', '其他Others', '机场（土建）Airport', '电积钻车间(土建)', '电积钻车间(设备)',
                    '生态村项目 Ecological Village Project', '乙炔站acetylene station']
ONC在建工程 = ['原矿堆场', '洗矿车间', '洗矿后除渣', '褐铁矿磨矿及除渣', '褐煤添加车间', '选矿回水泵站',
                   '选矿综合办公楼', '选矿维修车间及综合仓库', '选矿厂区雨水收集池', '选矿厂区生活污水处理站',
                   '选矿10kV配电站', '选矿综合管网', '码头至选矿厂1#地中衡', '码头至选矿厂2#地中衡',
                   '码头至选矿厂外道路', '选矿高位水池', '选矿工业场地总平面及竖向', '褐铁矿一级浓缩',
                   '高压酸浸（含二级浓缩）', '循环浸出', 'CCD洗涤', '中和除铁铝', '除铁铝浓密分离', '氢氧化镍钴沉淀',
                   '氢氧化镍钴浓密分离', '氢氧化镍钴CCD洗涤', '氢氧化镍钴过滤', '尾渣中和', '絮凝剂制备',
                   '铁铝渣CCD洗涤', '浓硫酸贮存', '氢氧化钠贮存', '1号尾渣库尾渣坝', '1号尾渣库副坝',
                   '1号尾渣库排洪设施', '1号尾渣库防排渗设施', '1号尾渣库清污分流设施', '1号尾渣库截渗坝及渗水收集设施',
                   '1号尾渣库渗水回收泵站及管线', '1号尾渣库观测设施', '1号尾渣输送泵站', '尾渣输送泵站',
                   '1号尾渣库尾渣输送管线', '1号尾渣库排水浮船泵站', '1号尾渣库排水管线', '1号尾渣库管理站',
                   '1号尾渣库库区道路', '2号尾渣库尾渣坝', '2号尾渣库副坝', '2号尾渣库排洪设施', '2号尾渣库防排渗设施',
                   '2号尾渣库清污分流设施', '2号尾渣库截渗坝及渗水收集设施', '2号尾渣库渗水回收泵站及管线',
                   '2号尾渣库观测设施', '2号尾渣输送泵站（扩建）', '2号尾渣库尾渣输送管线', '2号尾渣库排水浮船泵站',
                   '2号尾渣库排水管线', '2号尾渣库管理站', '2号尾渣库库区道路', '3号尾渣库尾渣坝', '3号尾渣库排洪设施',
                   '3号尾渣库防排渗设施', '3号尾渣库清污分流设施', '3号尾渣库截渗坝及渗水收集设施',
                   '3号尾渣库渗水回收泵站及管线', '3号尾渣库观测设施', '3号尾渣库尾渣输送管线', '3号尾渣库排水浮船泵站',
                   '3号尾渣库排水加压泵站', '3号尾渣库排水管线', '3号尾渣库管理站', '3号尾渣库库区道路', '全厂性',
                   '硫磺库', '熔硫系统', '流硫罐区', '硫酸罐区', '化学水处理系统', '综合楼', '10KV配电楼', '循环水站',
                   '综合管网', '配电室9.5M层梁板柱', '消防水站基础垫层', '1号污水处理站', '机修车间桩基',
                   '焚硫及转化系统四系列', '干吸系统四系列', '余热回收系统四系列', '焚硫及转化系统五系列',
                   '干吸系统五系列', '余热回收系统五系列', '焚硫及转化系统六系列', '干吸系统六系列',
                   '余热回收系统六系列', '石灰石原矿仓', '石灰石皮带廊及转运站', '石灰石磨矿车间',
                   '石灰石场地总平面及竖向', '石灰乳制备系统', '取水泵站', '取水管线', '给水净化站及高位水池',
                   '初期雨水及事故池', '空压机及浸出循环水站', '输水管线', '冶炼配电室', '冶炼1#10kv配电站',
                   '冶炼2#10kv配电站', '冶炼3#10kv配电站', '110KV变电站及电气综合楼', '110-35KV电网部分',
                   '选矿35KV01站', '厂区整平', '总平面及竖向', '厂内道路', '矿山至冶炼厂1#地中衡',
                   '矿山至冶炼厂2#地中衡', '冶炼厂东侧厂外道路', '厂外道路', '综合楼', '空压机站', '综合维修车间',
                   '综合仓库（一）', '厂内综合管网', '污水处理', '综合办公楼', '厂外综合管网', '1#值班室', '2#值班室',
                   '3#值班室', '4#值班室', 'HPAL三期共用', '输水管工程', '管廊架工程', '泊位', '原1#宿舍', '原2#宿舍',
                   '原3#宿舍', '原4#宿舍', '原5#宿舍', '原6#宿舍', '原7#宿舍', '原9#宿舍', '中方餐厅', '1#配电间',
                   '2#配电间', 'A区空气能', 'A区冷库', 'A区内部道路', 'A区外部道路', '原8#宿舍', '原10#宿舍',
                   '原11#宿舍', '原12#宿舍', '原13#宿舍', '原14#宿舍', '原15#宿舍', '原16#宿舍', '原17#宿舍',
                   '印方餐厅', 'B区冷库', '3#配电间', '4#配电间', 'B区空气能', 'B区内部道路', 'B区外部道路', '道路工程']
def set_ui(sheet):
    # 隐藏BG到BM列
    sheet.range('BG:BM').api.EntireColumn.Hidden = True
    sheet.range('AL:AS').api.EntireColumn.Hidden = True
    sheet.range('C:D').api.EntireColumn.Hidden = True
    sheet.range('V:Z').api.EntireColumn.Hidden = True
    sheet.range('S:T').api.EntireColumn.Hidden = True
    sheet.range('AD:AK').api.EntireColumn.Hidden = True
    sheet.range('AV:AW').api.EntireColumn.Hidden = True
    sheet.range('J:J').api.EntireColumn.Hidden = True
    sheet.range('L:L').api.EntireColumn.Hidden = True
    sheet.range('Q:Q').api.EntireColumn.Hidden = True
    sheet.range('AY:AY').api.EntireColumn.Hidden = True
    # 自动调整 =列宽
    sheet.range('I:I').api.EntireColumn.AutoFit()
    sheet.range('K:K').api.EntireColumn.AutoFit()
    sheet.range('AZ:AZ').api.EntireColumn.AutoFit()
    sheet.range('AT:AT').api.EntireColumn.AutoFit()
    sheet.range('AU:AU').api.EntireColumn.AutoFit()
    sheet.range('A:B').api.EntireColumn.AutoFit()
    sheet.range('BN:BN').api.EntireColumn.AutoFit()
    sheet.range('BF:BF').api.EntireColumn.AutoFit()
    # 自动调整列宽

    # 设置左对齐和顶端对齐# 财务审核列
    cell_range = sheet.range('BN:BN')
    cell_range.api.HorizontalAlignment = xlwings.constants.HAlign.xlHAlignLeft
    cell_range.api.VerticalAlignment = xlwings.constants.VAlign.xlVAlignTop
    sheet.range('BN:BN').column_width = 100# 设置 BN 列的宽度，例如 20
    sheet.range('BN:BN').rows.autofit() # 自动调整行高
    sheet.range('BN:BN').api.WrapText = True# 设置 BN 列自动换行
    ##财务审核意见
    cell = sheet.range(2, 66)
    cell.api.HorizontalAlignment = -4108  # -4108 水平居中。 -4131 靠左，-4152 靠右。
    cell.api.VerticalAlignment = -4108
    cell.value = "财务审核意见"

    cell.font.bold = True  # 加粗
    cell.font.size = 9  # 字号9
    cell.font.name = '宋体'  # 字体为宋体
    cell.font.color = (255, 0, 0)  # 字体颜色为红色 (RGB格式)
    # 财务审核意见
def 印尼生产领用材料出库_基本规则_1(data_row_json):#生产领用>>领用部门：[生产部，技术部，电力服务部];常见物料分类:["主要原材料","集团辅材","集团油料","库存商品","其他各种包装物","其他钢材"];收支项目:空(也就是生产成本);生产线:不为空;实际项目号:不为空;
    rule_result = {"是否错误": "否","错误列表":[]}
    生产部=['生产部', '生产科', '生产科公共', '原料车间', '原料车间公共', '高压酸浸车间', '高压酸浸车间公共', 'MHP成品车间',
     'MHP成品车间公共', '硫酸车间', '硫酸车间公共', '水渣处理车间', '水渣处理车间公共', '蒸发车间', '蒸发车间公共',
     '萃取车间', '萃取车间公共', '渣场', '渣场公共', '电钴车间', '电钴车间公共', '硫酸镍成品车间', '硫酸镍成品车间公共',
     '生产部公共']
    技术部=['技术部', '质检部（化验室）', '技术工艺室', '技术部公共']
    电力服务部=['电力服务部', '检修维护科', '发电运行科', '安全技术科', '综合办', '电力服务部公共']
    领料部门=data_row_json["领料部门"]
    物料基本分类 = data_row_json["物料基本分类"]
    收支项目 = data_row_json["收支项目"]
    生产线 = data_row_json["生产线"]
    实际项目名称=data_row_json["实际项目名称"]
    常见物料分类=["主要原材料", "集团辅材", "集团油料", "库存商品", "其他各种包装物", "其他钢材"]

    if data_row_json["出入库类型"]=="印尼生产领用材料出库":
        if (领料部门 not in 生产部) and (领料部门 not in 技术部) and (领料部门 not in 电力服务部):
            rule_result["错误列表"].append({"错误类型1":"领料部门("+领料部门+")不正确,建议改为生产部类的领料部门"})
            rule_result["是否错误"] = "是"
        if 物料基本分类 not in 常见物料分类:
            rule_result["错误列表"].append({"错误类型2":"物料基本分类不常见,请人工检查"})
            rule_result["是否错误"] = "是"
        if 收支项目!=None:
            rule_result["错误列表"].append({"错误类型3": "收支项目应该为空"})
            rule_result["是否错误"] = "是"
        if 生产线==None:
            rule_result["错误列表"].append({"错误类型4": "生产线不为空"})
            rule_result["是否错误"] = "是"
        if 实际项目名称 == None:
            rule_result["错误列表"].append({"错误类型5": "实际项目名称不为空"})
            rule_result["是否错误"] = "是"
    return rule_result
def 印尼办公及长期资产领用材料出库_基本规则_1(data_row_json):
    #印尼办公及长期资产领用材料出库没有一级分类
    rule_result = {"是否错误": "否", "错误列表": []}
    return rule_result
    pass
def 印尼一般工程领用材料出库_基本规则_1(data_row_json):#工程领用>>实际项目名称:[在建工程类];收支项目:在建工程;生产线:空
    rule_result = {"是否错误": "否", "错误列表": []}
    global HPAL在建工程
    global ONC在建工程
    在建工程列表=HPAL在建工程+ONC在建工程
    实际项目名称=data_row_json["实际项目名称"]
    收支项目 = data_row_json["收支项目"]
    生产线 = data_row_json["生产线"]
    #print(实际项目名称)
    if data_row_json["出入库类型"] == "印尼一般工程领用材料出库":
        if 实际项目名称 not in 在建工程列表:
            rule_result["错误列表"].append({"错误类型1": "出库类型为("+data_row_json["出入库类型"]+"),实际项目名称("+实际项目名称+") 不属于在建工程类,工程一般领用的物料出库,实际项目名称都是--在建工程下面对应的项目子项名称"})
            rule_result["是否错误"] = "是"
        if "在建工程" not in 收支项目:
            rule_result["错误列表"].append({"错误类型2": "出库类型为(印尼一般工程领用材料出库),收支项目("+收支项目+")不属于在建工程类,请检查"})
            rule_result["是否错误"] = "是"
        if 生产线!=None:
            rule_result["错误列表"].append({"错误类型3": "出库类型为(印尼一般工程领用材料出库),生产线("+生产线+")非空,印尼一般工程领用材料出库没有生产线"})
            rule_result["是否错误"] = "是"
    return rule_result
def 印尼甲供甲付材料出库_基本规则_1(data_row_json):
    rule_result = {"是否错误": "否", "错误列表": []}
    global HPAL在建工程
    global ONC在建工程
    在建工程列表 = HPAL在建工程 + ONC在建工程
    收支项目 = data_row_json["收支项目"]
    生产线 = data_row_json["生产线"]
    领料部门列表=["施工管理部公共","施工管理部"]
    领料部门=data_row_json["领料部门"]
    if data_row_json["出入库类型"] == "印尼甲供甲付材料出库":
        if data_row_json["实际项目名称"] not in 在建工程列表:
            rule_result["错误列表"].append({"错误类型1": "出库类型为(印尼甲供甲付材料出库),实际项目名称(" + data_row_json["实际项目名称"] + ") 不属于在建工程类,工程一般领用的物料出库,实际项目名称都是--在建工程下面对应的项目子项名称"})
            rule_result["是否错误"] = "是"
        if data_row_json["承包商"] == None or  data_row_json["承包商"] == "":
            rule_result["错误列表"].append({"错误类型2": "出库类型为(印尼甲供甲付材料出库),但是没有承包商"})
            rule_result["是否错误"] = "是"
        if "在建工程" not in 收支项目:
            rule_result["错误列表"].append({"错误类型3": "出库类型为(印尼甲供甲付材料出库),收支项目("+收支项目+")不属于在建工程类,请检查"})
            rule_result["是否错误"] = "是"
        if 生产线!=None:
            rule_result["错误列表"].append({"错误类型4": "出库类型为(印尼甲供甲付材料出库),生产线("+生产线+")非空,印尼一般工程领用材料出库没有生产线"})
            rule_result["是否错误"] = "是"
        if 领料部门 not in 领料部门列表:
            rule_result["错误列表"].append({"错误类型5": "出库类型为(印尼甲供甲付材料出库),领料部门(" + 领料部门 + ")不常见,请复查"})
            rule_result["是否错误"] = "是"
    return rule_result
def 印尼甲供乙付材料出库_基本规则_1(data_row_json):
    rule_result = {"是否错误": "否", "错误列表": []}
    global HPAL在建工程
    global ONC在建工程
    在建工程列表 = HPAL在建工程 + ONC在建工程
    收支项目 = data_row_json["收支项目"]
    生产线 = data_row_json["生产线"]
    领料部门列表=["施工管理部公共","施工管理部"]
    领料部门=data_row_json["领料部门"]
    if data_row_json["出入库类型"] == "印尼甲供乙付材料出库":
        if data_row_json["实际项目名称"] not in 在建工程列表:
            rule_result["错误列表"].append({"错误类型1": "出库类型为(印尼甲供乙付材料出库),实际项目名称(" + data_row_json["实际项目名称"] + ") 不属于在建工程类,工程一般领用的物料出库,实际项目名称都是--在建工程下面对应的项目子项名称"})
            rule_result["是否错误"] = "是"
        if data_row_json["承包商"] == None or  data_row_json["承包商"] == "":
            rule_result["错误列表"].append({"错误类型2": "出库类型为(印尼甲供乙付材料出库),但是没有承包商"})
            rule_result["是否错误"] = "是"
        if "在建工程" not in 收支项目:
            rule_result["错误列表"].append({"错误类型3": "出库类型为(印尼甲供乙付材料出库),收支项目("+收支项目+")不属于在建工程类,请检查"})
            rule_result["是否错误"] = "是"
        if 生产线!=None:
            rule_result["错误列表"].append({"错误类型4": "出库类型为(印尼甲供乙付材料出库),生产线("+生产线+")非空,印尼一般工程领用材料出库没有生产线"})
            rule_result["是否错误"] = "是"
        if 领料部门 not in 领料部门列表:
            rule_result["错误列表"].append({"错误类型5": "出库类型为(印尼甲供乙付材料出库),领料部门(" + 领料部门 + ")不常见,请复查"})
            rule_result["是否错误"] = "是"
    return rule_result
def 印尼乙供甲付材料出库_基本规则_1(data_row_json):
    rule_result = {"是否错误": "否", "错误列表": []}
    global HPAL在建工程
    global ONC在建工程
    在建工程列表 = HPAL在建工程 + ONC在建工程
    收支项目 = data_row_json["收支项目"]
    生产线 = data_row_json["生产线"]
    领料部门列表=["施工管理部公共","施工管理部"]
    领料部门=data_row_json["领料部门"]
    if data_row_json["出入库类型"] == "印尼乙供甲付材料出库":
        if data_row_json["实际项目名称"] not in 在建工程列表:
            rule_result["错误列表"].append({"错误类型1": "出库类型为(印尼乙供甲付材料出库),实际项目名称(" + data_row_json["实际项目名称"] + ") 不属于在建工程类,工程一般领用的物料出库,实际项目名称都是--在建工程下面对应的项目子项名称"})
            rule_result["是否错误"] = "是"
        if data_row_json["承包商"] == None or  data_row_json["承包商"] == "":
            rule_result["错误列表"].append({"错误类型2": "出库类型为(印尼乙供甲付材料出库),但是没有承包商"})
            rule_result["是否错误"] = "是"
        if "在建工程" not in 收支项目:
            rule_result["错误列表"].append({"错误类型3": "出库类型为(印尼乙供甲付材料出库),收支项目("+收支项目+")不属于在建工程类,请检查"})
            rule_result["是否错误"] = "是"
        if 生产线!=None:
            rule_result["错误列表"].append({"错误类型4": "出库类型为(印尼乙供甲付材料出库),生产线("+生产线+")非空,印尼一般工程领用材料出库没有生产线"})
            rule_result["是否错误"] = "是"
        if 领料部门 not in 领料部门列表:
            rule_result["错误列表"].append({"错误类型5": "出库类型为(印尼乙供甲付材料出库),领料部门(" + 领料部门 + ")不常见,请复查"})
            rule_result["是否错误"] = "是"
    return rule_result
def 印尼自制工程物资材料出库_基本规则_1(data_row_json):
    rule_result = {"是否错误": "否", "错误列表": []}

    收支项目 = data_row_json["收支项目"]
    生产线 = data_row_json["生产线"]
    领料部门列表=["施工管理部公共","施工管理部"]
    领料部门=data_row_json["领料部门"]
    承包商=data_row_json["承包商"]
    实际项目名称=data_row_json["实际项目名称"]
    if data_row_json["出入库类型"] == "印尼自制工程物资材料出库":
        if 承包商!=None:
            rule_result["错误列表"].append({"错误类型1": "出库类型为(印尼自制工程物资材料出库),承包商("+承包商+")非空,印尼自制工程物资材料出库一般没有承包商"})
            rule_result["是否错误"] = "是"
        if 实际项目名称 != None:
            rule_result["错误列表"].append({"错误类型2": "出库类型为(印尼自制工程物资材料出库),实际项目名称(" + 实际项目名称 + ")非空,印尼自制工程物资材料出库一般没有实际项目名称"})
            rule_result["是否错误"] = "是"
        if 收支项目 != None:
            rule_result["错误列表"].append({"错误类型3": "出库类型为(印尼自制工程物资材料出库),收支项目(" + 收支项目 + ")非空,印尼自制工程物资材料出库一般没有收支项目"})
            rule_result["是否错误"] = "是"
        if 生产线 != None:
            rule_result["错误列表"].append({"错误类型4": "出库类型为(印尼自制工程物资材料出库),生产线(" + 生产线 + ")非空,印尼自制工程物资材料出库一般没有生产线"})
            rule_result["是否错误"] = "是"
    return rule_result

def rule1(data_row_json):
    rule_result = {"是否错误": "否", "错误列表": []}
    if data_row_json["单据日期"]!=data_row_json["出库日期"]:
        rule_result["错误列表"].append({"错误类型1": "单据日期不等于出库日期"})
        rule_result["是否错误"] = "是"
    return rule_result
def rule2(data_row_json):
    rule_result = {"是否错误": "否", "错误列表": []}
    收支项目=["公共维修-维修费-管理费用（印尼）","物料消耗-管理费用","建筑物维修-维修费-管理费用（印尼）","办公用品及电脑用品-办公费-管理费用（印尼）","办公设备维修-维修费-管理费用（印尼）","OBI食堂费用-管理费用","OBI宿舍费用-管理费用","燃油费-车辆费-管理费用（印尼）","防疫物资-管理费用","厨房/餐具室/卫生-办公费-管理费用（印尼）","劳保费用-管理费用","OBI医疗费用-管理费用","会议费-办公费-管理费用（印尼）"]
    if data_row_json["收支项目"] in 收支项目:
        if data_row_json["生产线"]!=None:
            rule_result["错误列表"].append({"错误类型1": "收支项目和生产线不匹配，管理费用不应该有生产线"})
            rule_result["是否错误"] = "是"
        if data_row_json["出入库类型"]!="印尼办公及长期资产领用材料出库":
            rule_result["错误列表"].append({"错误类型2":"收支项目和出入库类型不匹配，管理费用出库类型应该是印尼办公及长期资产领用材料出库"})
            rule_result["是否错误"] = "是"
    return rule_result
def rule3(data_row_json):
    rule_result = {"是否错误": "否", "错误列表": []}
    出入库类型=["印尼办公及长期资产领用材料出库","印尼生产领用材料出库"]
    if data_row_json["生产线"]=="MHP公共":
        if data_row_json["实际项目名称"]!="MHP生产":
            rule_result["错误列表"].append({"错误类型1": "生产线和实际项目名称不匹配，(MHP公共)生产线的实际项目名称应该是(MHP生产)"})
            rule_result["是否错误"] = "是"
        else:
            if data_row_json["出入库类型"] not in 出入库类型:
                rule_result["错误列表"].append({"错误类型2": '''生产线和出入库类型不匹配，(MHP公共)生产线的出入库类型应该是(印尼办公及长期资产领用材料出库)或者(印尼生产领用材料出库)'''})
                rule_result["是否错误"] = "是"
    return rule_result
def rule4(data_row_json):
    rule_result = {"是否错误": "否", "错误列表": []}
    生产线=["电厂1号炉","电厂2号炉","电厂3号炉","电厂公共"]
    领料部门=["电力服务部公共","检修维护科"]
    出入库类型=["印尼办公及长期资产领用材料出库", "印尼生产领用材料出库"]
    if data_row_json["生产线"] in 生产线:
        if data_row_json["实际项目名称"] !="电厂生产":
            rule_result["错误列表"].append({"错误类型1": "生产线和实际项目名称不匹配，实际项目名称应该是(电厂生产)"})

            rule_result["是否错误"] = "是"
        else:
            if data_row_json["领料部门"] not in 领料部门:
                rule_result["错误列表"].append({"错误类型2": "生产线和领料部门不匹配，领料部门应该是(电力服务部公共)或者(检修维护科)"})

                rule_result["是否错误"] = "是"
            if data_row_json["出入库类型"] not in 出入库类型:
                rule_result["错误列表"].append({"错误类型3": "生产线和出入库类型不匹配,出入库类型应该是(印尼办公及长期资产领用材料出库)或者(印尼生产领用材料出库)"})
                rule_result["是否错误"] = "是"
    return rule_result

def rule5(data_row_json):
    rule_result = {"是否错误": "否", "错误列表": []}
    rule_result["是否错误"]="否"
    if data_row_json["生产线"]=="电钴生产线":
        if data_row_json["实际项目名称"]!="电钴生产" and data_row_json["实际项目名称"]!="钴板生产":
            rule_result["错误列表"].append({"错误类型1": "生产线和实际项目名称不匹配，(电钴生产线)的实际项目名称应该是(电钴生产)"})

            rule_result["是否错误"] = "是"
        else:
            if data_row_json["收支项目"]!="机物料消耗-制造费用-自制产成品":
                rule_result["错误列表"].append({"错误类型2": "生产线和收支项目不匹配，(电钴生产线)的收支项目应该是(机物料消耗-制造费用-自制产成品)"})

                rule_result["是否错误"] = "是"
            else:
                if data_row_json["领料部门"] != "电积钴项目组公共" and data_row_json["领料部门"]!="电钴车间公共":
                    rule_result["错误列表"].append({"错误类型3": "生产线和领料部门不匹配，(电钴生产线)的领料部门应该是(电积钴项目组公共)"})

                    rule_result["是否错误"] = "是"
                else:
                    if data_row_json["出入库类型"] != "印尼办公及长期资产领用材料出库":
                        rule_result["错误列表"].append({"错误类型4": "生产线和出入库类型不匹配，(电钴生产线)的出入库类型应该是(印尼办公及长期资产领用材料出库)"})

                        rule_result["是否错误"] = "是"
    return rule_result



def rule6(data_row_json):
    rule_result = {"是否错误": "否", "错误列表": []}
    出入库类型=["印尼办公及长期资产领用材料出库", "印尼生产领用材料出库"]
    领料部门=["硫酸车间公共", "生产部公共"]
    if data_row_json["生产线"] == "硫磺制酸生产线":
        if  data_row_json["实际项目名称"]!="硫磺制酸生产":
            rule_result["错误列表"].append({"错误类型1": "生产线和实际项目名称不匹配，硫磺制酸生产的实际项目名称应该是(硫磺制酸生产)"})

            rule_result["是否错误"] = "是"
        else:
            if data_row_json["出入库类型"] not in 出入库类型:
                rule_result["错误列表"].append({"错误类型2": '''生产线和出入库类型不匹配，硫磺制酸生产的实际项目名称应该是["印尼办公及长期资产领用材料出库", "印尼生产领用材料出库"]'''})

                rule_result["是否错误"] = "是"
            else:
                if data_row_json["领料部门"] not in 领料部门:
                    rule_result["错误列表"].append({"错误类型3": '''生产线和领料部门名称不匹配，硫磺制酸生产的实际项目名称应该是["硫酸车间公共", "生产部公共"]'''})

                    rule_result["是否错误"] = "是"
    return rule_result

def rule7(data_row_json):
    rule_result = {"是否错误": "否", "错误列表": []}
    领料部门=["萃取车间公共", "蒸发车间公共", "生产部公共", "电仪部公共"]
    出入库类型=["印尼办公及长期资产领用材料出库", "印尼生产领用材料出库"]
    if data_row_json["生产线"] == "硫酸镍钴产线":
        if data_row_json["实际项目名称"] != "硫酸镍钴产线":
            rule_result["错误列表"].append({"错误类型1": "生产线和实际项目名称不匹配，硫酸镍钴产线的实际项目名称应该是(硫酸镍钴产线)"})

            rule_result["是否错误"] = "是"
            if data_row_json["领料部门"] not in 领料部门:
                rule_result["错误列表"].append({"错误类型2":'''生产线和领料部门不匹配，硫酸镍钴产线的实际项目名称应该是["萃取车间公共", "蒸发车间公共", "生产部公共", "电仪部公共"]'''})

                rule_result["是否错误"] = "是"
                if data_row_json["出入库类型"] not in 出入库类型:
                    rule_result["错误列表"].append({"错误类型3": '''生产线和出入库类型不匹配，硫酸镍钴产线的出入库类型应该是["印尼办公及长期资产领用材料出库", "印尼生产领用材料出库"]'''})

                    rule_result["是否错误"] = "是"
    return rule_result
def rule8(data_row_json):
    rule_result = {"是否错误": "否", "错误列表": []}
    if data_row_json["收支项目"]=="设备-工程物资-在建工程":
        if data_row_json["存货分类"]!="设备":
            rule_result["错误列表"].append({"错误类型1": '''(收支项目)和(存货分类)不匹配，(设备-工程物资-在建工程)的存货分类应该是(设备)'''})
            rule_result["是否错误"] = "是"

    return rule_result


def rule9(data_row_json):
    rule_result = {"是否错误": "否", "错误列表": []}

    if data_row_json["收支项目"] == "土建材料-工程物资-在建工程":
        if data_row_json["存货分类"] == "设备":
            rule_result["错误列表"].append({"错误类型1": '''(收支项目)和(存货分类)不匹配，(土建材料-工程物资-在建工程)的存货分类不应该是(设备)，而是(备品备件)或者(低值易耗品等)。或者(设备)的收支项目为(设备-工程物资-在建工程)'''})

            rule_result["是否错误"] = "是"

    return rule_result
def rule10(data_row_json):
    rule_result = {"是否错误": "否", "错误列表": []}
    收支项目=["土建材料-工程物资-在建工程", "设备-工程物资-在建工程"]
    if data_row_json["收支项目"] in 收支项目:
        if data_row_json["生产线"]!=None:
            rule_result["错误列表"].append({"错误类型1": '''收支项目和生产线不匹配，土建材料-工程物资-在建工程或者设备-工程物资-在建工程不应该有生产线'''})
            rule_result["是否错误"] = "是"
    return rule_result
def rule11(data_row_json):
    rule_result = {"是否错误": "否", "错误列表": []}
    实际项目名称=["MHP生产", "硫磺制酸生产", "电厂生产", "电钴生产"]
    if data_row_json["出入库类型"] == "印尼一般工程领用材料出库":
        if data_row_json["实际项目名称"] in 实际项目名称:
            rule_result["错误列表"].append({"错误类型1": '''出入库类型和实际项目名称不匹配。印尼一般工程领用材料出库的实际项目名称不应该有生产'''})

            rule_result["是否错误"] = "是"
    return rule_result

def rule12(data_row_json):#属于rule13下面的细则，单独拿出来
    rule_result = {"是否错误": "否", "错误列表": []}
    if data_row_json["出入库类型"] == "印尼甲供甲付材料出库":
        if data_row_json["实际项目名称"] =="HPAL三期共用":
            rule_result["错误列表"].append({"错误类型1": '''出入库类型和实际项目名称不匹配。甲供甲付出库类型，对应的承包商，一定有具体的工程项目子项名称，放到(HPAL三期共用)不合适。请确认实际项目名称后修改。'''})

            rule_result["是否错误"] = "是"

    return rule_result
def rule13(data_row_json):#(印尼一般工程领用材料出库)||(印尼甲供甲付材料出库) 的 (实际项目名称) in (在建工程)
    rule_result = {"是否错误": "否", "错误列表": []}
    onc在建工程=['原矿堆场', '洗矿车间', '洗矿后除渣', '褐铁矿磨矿及除渣', '褐煤添加车间', '选矿回水泵站', '选矿综合办公楼', '选矿维修车间及综合仓库', '选矿厂区雨水收集池', '选矿厂区生活污水处理站', '选矿10kV配电站', '选矿综合管网', '码头至选矿厂1#地中衡', '码头至选矿厂2#地中衡', '码头至选矿厂外道路', '选矿高位水池', '选矿工业场地总平面及竖向', '褐铁矿一级浓缩', '高压酸浸（含二级浓缩）', '循环浸出', 'CCD洗涤', '中和除铁铝', '除铁铝浓密分离', '氢氧化镍钴沉淀', '氢氧化镍钴浓密分离', '氢氧化镍钴CCD洗涤', '氢氧化镍钴过滤', '尾渣中和', '絮凝剂制备', '铁铝渣CCD洗涤', '浓硫酸贮存', '氢氧化钠贮存', '1号尾渣库尾渣坝', '1号尾渣库副坝', '1号尾渣库排洪设施', '1号尾渣库防排渗设施', '1号尾渣库清污分流设施', '1号尾渣库截渗坝及渗水收集设施', '1号尾渣库渗水回收泵站及管线', '1号尾渣库观测设施', '1号尾渣输送泵站', '尾渣输送泵站', '1号尾渣库尾渣输送管线', '1号尾渣库排水浮船泵站', '1号尾渣库排水管线', '1号尾渣库管理站', '1号尾渣库库区道路', '2号尾渣库尾渣坝', '2号尾渣库副坝', '2号尾渣库排洪设施', '2号尾渣库防排渗设施', '2号尾渣库清污分流设施', '2号尾渣库截渗坝及渗水收集设施', '2号尾渣库渗水回收泵站及管线', '2号尾渣库观测设施', '2号尾渣输送泵站（扩建）', '2号尾渣库尾渣输送管线', '2号尾渣库排水浮船泵站', '2号尾渣库排水管线', '2号尾渣库管理站', '2号尾渣库库区道路', '3号尾渣库尾渣坝', '3号尾渣库排洪设施', '3号尾渣库防排渗设施', '3号尾渣库清污分流设施', '3号尾渣库截渗坝及渗水收集设施', '3号尾渣库渗水回收泵站及管线', '3号尾渣库观测设施', '3号尾渣库尾渣输送管线', '3号尾渣库排水浮船泵站', '3号尾渣库排水加压泵站', '3号尾渣库排水管线', '3号尾渣库管理站', '3号尾渣库库区道路', '全厂性', '硫磺库', '熔硫系统', '流硫罐区', '硫酸罐区', '化学水处理系统', '综合楼', '10KV配电楼', '循环水站', '综合管网', '配电室9.5M层梁板柱', '消防水站基础垫层', '1号污水处理站', '机修车间桩基', '焚硫及转化系统四系列', '干吸系统四系列', '余热回收系统四系列', '焚硫及转化系统五系列', '干吸系统五系列', '余热回收系统五系列', '焚硫及转化系统六系列', '干吸系统六系列', '余热回收系统六系列', '石灰石原矿仓', '石灰石皮带廊及转运站', '石灰石磨矿车间', '石灰石场地总平面及竖向', '石灰乳制备系统', '取水泵站', '取水管线', '给水净化站及高位水池', '初期雨水及事故池', '空压机及浸出循环水站', '输水管线', '冶炼配电室', '冶炼1#10kv配电站', '冶炼2#10kv配电站', '冶炼3#10kv配电站', '110KV变电站及电气综合楼', '110-35KV电网部分', '选矿35KV01站', '厂区整平', '总平面及竖向', '厂内道路', '矿山至冶炼厂1#地中衡', '矿山至冶炼厂2#地中衡', '冶炼厂东侧厂外道路', '厂外道路', '综合楼', '空压机站', '综合维修车间', '综合仓库（一）', '厂内综合管网', '污水处理', '综合办公楼', '厂外综合管网', '1#值班室', '2#值班室', '3#值班室', '4#值班室', 'HPAL三期共用', '输水管工程', '管廊架工程', '泊位', '原1#宿舍', '原2#宿舍', '原3#宿舍', '原4#宿舍', '原5#宿舍', '原6#宿舍', '原7#宿舍', '原9#宿舍', '中方餐厅', '1#配电间', '2#配电间', 'A区空气能', 'A区冷库', 'A区内部道路', 'A区外部道路', '原8#宿舍', '原10#宿舍', '原11#宿舍', '原12#宿舍', '原13#宿舍', '原14#宿舍', '原15#宿舍', '原16#宿舍', '原17#宿舍', '印方餐厅', 'B区冷库', '3#配电间', '4#配电间', 'B区空气能', 'B区内部道路', 'B区外部道路', '道路工程']
    hpal在建工程=['仓库2期', '其他Others', '机场（土建）Airport', '电积钻车间(土建)', '电积钻车间(设备)', '生态村项目 Ecological Village Project', '乙炔站acetylene station']
    库存组织=data_row_json["库存组织"]
    if 库存组织=="PT.HALMAHERA PERSADA LYGEND":
        if data_row_json["出入库类型"] == "印尼甲供甲付材料出库" or data_row_json["出入库类型"]=="印尼一般工程领用材料出库":
            if data_row_json["实际项目名称"] not in hpal在建工程:
                rule_result["错误列表"].append({"错误类型1": '''(出入库类型)和(实际项目名称)不匹配。('''+data_row_json["出入库类型"]+'''),实际项目名称都是--在建工程下面对应的项目子项名称.'''})

                rule_result["是否错误"] = "是"
    if 库存组织 == "PT. OBI NICKEL COBALT":
        if data_row_json["出入库类型"] == "印尼甲供甲付材料出库" or data_row_json["出入库类型"]=="印尼一般工程领用材料出库":
            if data_row_json["实际项目名称"] not in onc在建工程:
                rule_result["错误列表"].append({"错误类型1": '''(出入库类型)和(实际项目名称)不匹配。('''+data_row_json["出入库类型"]+'''),实际项目名称都是--在建工程下面对应的项目子项名称.'''})

                rule_result["是否错误"] = "是"
    return rule_result

def rule14(data_row_json):
    rule_result = {"是否错误": "否", "错误列表": []}
    物料名称=["[停用]笔记本电脑", "笔记本电脑", "电脑", "[停用]电脑", "个人电脑", "[停用]台式电脑", "台式电脑"]
    if data_row_json["物料名称"] in 物料名称:
        if data_row_json["收支项目"] !="自有(买入）-固定资产":
            rule_result["错误列表"].append({"错误类型1": '''物料名称和收支项目不匹配，电脑的收支项目应该是(自有(买入）-固定资产)'''})

            rule_result["是否错误"] = "是"
        else:
            if data_row_json["出入库类型"] != "印尼办公及长期资产领用材料出库":
                rule_result["错误列表"].append({"错误类型1": '''物料名称和出入库类型不匹配，电脑的出入库类型应该是(印尼办公及长期资产领用材料出库)'''})

                rule_result["是否错误"] = "是"
    return rule_result

def rule15(data_row_json):
    rule_result = {"是否错误": "否", "错误列表": []}
    if data_row_json["出入库类型"] =="印尼甲供乙付材料出库":
        if data_row_json["销售单价"] ==None:
            rule_result["错误列表"].append({"错误类型1": '''出入库类型和销售单价不匹配，印尼甲供乙付材料出库的销售单价不应该为空'''})

            rule_result["是否错误"] = "是"
    return rule_result

def rule16(data_row_json):
    rule_result = {"是否错误": "否", "错误列表": []}
    收支项目=["机物料消耗-制造费用-自制产成品","机械设备维修-维修费-制造费用-自制产成品（印尼）"]
    if data_row_json["使用位置"] =="机修":
        if data_row_json["收支项目"] not in 收支项目:
            rule_result["错误列表"].append({"错误类型1": '''使用位置等于机修，收支项目应该在["机物料消耗-制造费用-自制产成品","机械设备维修-维修费-制造费用-自制产成品（印尼）"]里面'''})

            rule_result["是否错误"] = "是"
    return rule_result
def rule17(data_row_json):
    rule_result = {"是否错误": "否", "错误列表": []}
    if data_row_json["收支项目"]!=None:
        if "管理费用" in data_row_json["收支项目"]:
            if data_row_json["领料部门"]=="后勤服务部公共":
                if data_row_json["实际项目名称"] != "后勤管理中心公共":
                    rule_result["错误列表"].append({"错误类型1": '''领料部门和实际项目名称不匹配。('''+data_row_json["领料部门"]+") 和 ("+data_row_json["实际项目名称"]+")不匹配"})

                    rule_result["是否错误"] = "是"
            else:
                if data_row_json["领料部门"] != data_row_json["实际项目名称"]:
                    rule_result["错误列表"].append({"错误类型1": '''领料部门和实际项目名称不匹配。('''+data_row_json["领料部门"]+") 和 ("+data_row_json["实际项目名称"]+")不匹配"})

                    rule_result["是否错误"] = "是"
    return rule_result
def rule18(data_row_json):#生产部领用的，不应该进入管理费用
    rule_result = {"是否错误": "否", "错误列表": []}
    ONC生产部=["生产科公共","原料车间公共","高压酸浸车间公共","MHP成品车间公共","硫酸车间公共","水渣处理车间公共","渣场公共"]
    HPAL生产部=["生产科公共","原料车间公共","高压酸浸车间公共","MHP成品车间公共","硫酸车间公共","水渣处理车间公共","蒸发车间公共","萃取车间公共","渣场公共","电钴车间公共","硫酸镍成品车间公共"]
    生产部全=HPAL生产部+ONC生产部
    if data_row_json["收支项目"] != None:
        if data_row_json["领料部门"] in 生产部全:
            if "管理费用" in data_row_json["收支项目"]:
                rule_result["错误列表"].append({"错误类型1": '''领料部门和收支项目不匹配。领用部门为生产车间，进制造费用更合适。'''})
                rule_result["是否错误"] = "是"
    return rule_result
def rule19(data_row_json):
    rule_result = {"是否错误": "否", "错误列表": []}
    收支项目=data_row_json["收支项目"]
    if data_row_json["物料基本分类"] =="医用家具、台床及医用材料":
        if "OBI医疗费用" not in 收支项目:
            rule_result["错误列表"].append({"错误类型1": '''收支项目建议调整为：OBI医疗费用-管理费更精准些。'''})
            rule_result["是否错误"] = "是"
    return rule_result
def rule20(data_row_json):#自己去看ONC在建工程，ON4000全场性，只是叫全场性，但是全场性  专指  硫酸的全场性
    rule_result = {"是否错误": "否", "错误列表": []}
    领料部门=data_row_json["领料部门"]
    实际项目名称=data_row_json["实际项目名称"]
    if 领料部门=="硫酸车间公共":
        if 实际项目名称=="HPAL三期共用":
            rule_result["错误列表"].append({"错误类型1": '''实际项目名称与领用部门不太匹配：建议改为全厂性（所指三期硫酸车间全部）；而三期共用包含了其他车间。'''})
            rule_result["是否错误"] = "是"
    return rule_result
    pass
def start_shen_he(shen_he_file_path):
    错误单据号_列表=[]
    app = xlwings.App(visible=True, add_book=False)  # 创建一个不可见的 Excel 应用程序实例
    wb = app.books.open(shen_he_file_path, update_links=False)  # 打开工作簿

    source_sheet = wb.sheets[0]  # 替换为你要复制的工作表名称

    new_sheet = source_sheet.copy(after=wb.sheets[-1])  # 复制工作表并将其插入到工作簿中
    new_sheet.name = source_sheet.name+("(许阳峰审核)")
    source_sheet.name=source_sheet.name+("(原版)")
    sheet = new_sheet

    可签字表 = source_sheet.copy(after=new_sheet)  # 在源工作表后复制
    可签字表.name = "可签字"  # 重命名新工作表

    last_row = sheet.range(sheet.cells.last_cell.row, 1).end('up').row
    result={}
    基本规则_1 = [印尼生产领用材料出库_基本规则_1, 印尼办公及长期资产领用材料出库_基本规则_1,
                  印尼一般工程领用材料出库_基本规则_1, 印尼甲供甲付材料出库_基本规则_1,
                  印尼甲供乙付材料出库_基本规则_1, 印尼乙供甲付材料出库_基本规则_1, 印尼自制工程物资材料出库_基本规则_1]
    rules =基本规则_1+ [rule1, rule2, rule3, rule4, rule5, rule6, rule7, rule8, rule9, rule10, rule11, rule12, rule13, rule14, rule15, rule16,rule17,rule18,rule19,rule20]# 规则列表
    #rules=基本规则_1
    data_range = sheet.range(f"A1:BM{last_row}").value  # 一次性读取需要的数据区域
    for row in range(2,len(data_range)):
        print(row)
        insert_flag=0
        data_json = {
            "库存组织":data_range[row][0],
            "单据状态": data_range[row][4],
            "单据日期": data_range[row][5],
            "出库日期": data_range[row][6],
            "出入库类型": data_range[row][8],
            "领料部门": data_range[row][10],
            "承包商":data_range[row][15],
            "物料名称": data_range[row][17],
            "物料基本分类": data_range[row][20],
            "项目号": data_range[row][26],
            "实际项目号": data_range[row][27],
            "实际项目名称": data_range[row][28],
            "存货分类": data_range[row][49],
            "收支项目": data_range[row][51],
            "生产线": data_range[row][52],
            "使用位置": data_range[row][53],
            "销售单价": data_range[row][45],
        }
        result_1 = {"error_types": []}
        if data_json["单据状态"] == "自由":
            for rule in rules:

                r = rule(data_json)
                if r["是否错误"] == "是":
                    result_1["error_types"].append(r)
                    insert_flag=1

        if insert_flag==1:
            result[str(row+1)]=result_1
            row_range = sheet.range((str(row+1), 1), (str(row+1), 65))
            row_range.api.Font.Color = 255  # 255 是红色的 RGB 代码
            #result1={'error_types': [{'是否错误': '是', '错误列表': [{'错误类型1': '出库类型为(印尼一般工程领用材料出库),实际项目名称(MHP生产) 不属于在建工程类,工程一般领用的物料出库,实际项目名称都是--在建工程下面对应的项目子项名称'}, {'错误类型3': '出库类型为(印尼一般工程领用材料出库),生产线(鞍山市)非空,印尼一般工程领用材料出库没有生产线'}]}]}

            #error_list=[{'错误类型1': '出库类型为(印尼一般工程领用材料出库),实际项目名称(MHP生产) 不属于在建工程类,工程一般领用的物料出库,实际项目名称都是--在建工程下面对应的项目子项名称'}, {'错误类型3': '出库类型为(印尼一般工程领用材料出库),生产线(鞍山市)非空,印尼一般工程领用材料出库没有生产线'}]
            sheet.range((str(row + 1), 66)).value = ""
            s = ""
            my_index=1
            for whaterver in range(0, len(result_1['error_types'])):
                error_list = result_1['error_types'][whaterver]["错误列表"]
                换行flag = 0
                for i in range(len(error_list)):
                    values = list(error_list[i].values())  # 获取值列表
                    s = s + str(my_index) + ". " + values[0]
                    my_index=my_index+1
                    if i != (len(error_list) - 1):
                        s = s + "\n"
                if whaterver != (len(result_1['error_types']) - 1):
                    s = s + "\n"
            sheet.range((str(row + 1), 66)).value = str(s)
            错误单据号_列表.append(sheet.range((str(row + 1), 2)).value)
    #print(result)
    set_ui(sheet)


    last_col = sheet.range(2, sheet.cells.last_cell.column).end('left').column
    last_row = sheet.range(sheet.cells.last_cell.row, 2).end('up').row

    sheet.range((2, 1), (2, last_col)).api.AutoFilter(Field=66, Criteria1="<>")  # 将第二行的数据设为筛选范围，然后应用筛选器

    # 获取过滤后的值
    print(错误单据号_列表)

    可签字_工作表=wb.sheets["可签字"]
    # 清空从第三行到最后一行的内容
    可签字_工作表_last_row = 可签字_工作表.range(sheet.cells.last_cell.row, 1).end('up').row
    可签字_工作表.range(f"3:{可签字_工作表_last_row}").clear()  # 清空第三行到最后一行的内容

    data_range=sheet.range((3,1),(last_row,last_col)).value
    new_data_list=[]#新数据，也就是可签字_工作表
    unique_单据号_list = []
    unique_单据号_list_list=[]
    for i in range(0,len(data_range)):
        if data_range[i][1] in 错误单据号_列表:
            continue
        new_data_list.append(data_range[i])   # 如果不在错误单据号列表中，则将数据插入可签字_工作表

        current_单据号 = data_range[i][1]
        if current_单据号 in unique_单据号_list:
            continue
        unique_单据号_list.append(data_range[i][1])
        unique_单据号_list_list.append([(data_range[i][1]),(data_range[i][8]),(data_range[i][5])])
    可签字_工作表.range((3, 1)).value = new_data_list  #

    可签字_工作表_last_row = 可签字_工作表.range(可签字_工作表.cells.last_cell.row, 1).end('up').row
    可签字_工作表_last_col = 可签字_工作表.range(2, 可签字_工作表.cells.last_cell.column).end('left').column

    可签字_工作表.range((3,1),(可签字_工作表_last_row,可签字_工作表_last_col)).color = (146,208,80)

    #unique_单据号_list = list(set(unique_单据号_list))# 使用 set 去重

    another_sheet = wb.sheets.add('可签字去重单据号')
    # 移动新工作表到最后面
    another_sheet.api.Move(After=wb.sheets[-1].api)

    print(unique_单据号_list_list)

    another_sheet.range((1, 1)).value = unique_单据号_list_list
    another_sheet.range('A:B').api.EntireColumn.AutoFit()
    sheet.activate()


shen_he_file_path=r"F:\xu\2.出库审核\工作区\0910\材料出库单列表ONC0909 - 副本.xls"
start_shen_he(shen_he_file_path)
