import os

base_dir=r"F:\xu\生产台账"
onc_basic_data_dir=base_dir+"\\onc\\基本数据"
hpal_basic_data_dir=base_dir+"\\hpal\\基本数据"
basic_data_dir=[onc_basic_data_dir,hpal_basic_data_dir]
def count_directories(path):
    directories = []  # 用于保存文件夹的列表
    for entry in os.listdir(path):
        full_path = os.path.join(path, entry)  # 获取每个条目的完整路径
        if os.path.isdir(full_path):  # 检查条目是否为文件夹
            directories.append(full_path)  # 保存完整路径到列表
    return directories  # 返回文件夹数量和列表

def get_get_com_not_complete_not_complete(directory_list):
    complete_list = []
    not_complete_list = []
    for i in range(0,len(directory_list)):
        for root, dirs, files in os.walk(directory_list[i]):  # 遍历文件夹及其子文件夹中的所有文件和文件夹
            print(files)
            li_shi_que_ren_dan=0#砾石确认
            guo_bang_ming_xi=0#过磅明细
            he_tie_kuang=0#褐铁矿
            MHP=0#MHP
            for j in range(0,len(files)):
                if("大中小砾石运输确认单" in files[j] and "待确认" not in files[j]):
                    li_shi_que_ren_dan=1
                if ("过磅明细" in files[j]):
                    guo_bang_ming_xi = 1
                if ("褐铁矿运输确认单" in files[j] and "待确认" not in files[j]):
                    he_tie_kuang = 1
                if ("MHP过磅日报" in files[j]):
                    MHP = 1
            if li_shi_que_ren_dan==1 and guo_bang_ming_xi==1 and he_tie_kuang==1 and MHP==1:
                complete_list.append(root)
            else:
                not_complete_list.append(root)
    return complete_list,not_complete_list
complete_list_1=[]
not_complete_list_1=[]
for i in range(0,len(basic_data_dir)):
    directory_list = count_directories(basic_data_dir[i])
    complete_list,not_complete_list=get_get_com_not_complete_not_complete(directory_list)
    complete_list_1.extend(complete_list)
    not_complete_list_1.extend(not_complete_list)
print("complete_list")
print(complete_list_1)
print("not_complete_list")
print(not_complete_list_1)