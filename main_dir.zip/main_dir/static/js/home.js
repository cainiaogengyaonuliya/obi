function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const content = document.getElementById('content');

    if (sidebar.classList.contains('active')) {
        sidebar.classList.remove('active');
        content.classList.remove('active');
    } else {
        sidebar.classList.add('active');
        content.classList.add('active');
    }
}
