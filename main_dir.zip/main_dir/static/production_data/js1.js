window.onload = function() {
	refresh();
}
function refresh(){
    let my_json={"my_type":"fetch_data"}
    let promise = send_ajax(my_json,"/production_data_blueprint_upload");
    promise.then(function(response) {
        let file1_path_display_span=document.getElementById("file1_path_display_span")
        file1_path_display_span.innerHTML=response["onc_褐铁矿台账_路径"]

        let file1_path_display_span_2=document.getElementById("file1_path_display_span_2")
        file1_path_display_span_2.innerHTML=response["onc_mhp台账_路径"]

        let file1_path_display_span_3=document.getElementById("file1_path_display_span_3")
        file1_path_display_span_3.innerHTML=response["hpal_褐铁矿台账_路径"]

         let file1_path_display_span_4=document.getElementById("file1_path_display_span_4")
        file1_path_display_span_4.innerHTML=response["hpal_mhp台账_路径"]

        let file1_path_display_span_5=document.getElementById("file1_path_display_span_5")
        file1_path_display_span_5.innerHTML=response["源数据文件夹"]

        let file1_path_display_span_6=document.getElementById("file1_path_display_span_6")
        file1_path_display_span_6.innerHTML=response["数据归类文件夹"]


         keyExists = response.hasOwnProperty("files");
         if(keyExists){
            console.log("existed")

            display_files_big_area=document.getElementById("display_files_big_area")

            while (display_files_big_area.firstChild) { // 当还有子节点时
                display_files_big_area.removeChild(display_files_big_area.firstChild); // 删除第一个子节点
            }


            files=response["files"]
            files_flag=response["files_flag"]
            for (let i = 0; i < files.length; i++) {



                var display_files = document.createElement('div');
                var display_files_div1 = document.createElement('div');
                var display_files_div2 = document.createElement('div');
                var display_files_div3 = document.createElement('div');
                 var display_files_div4 = document.createElement('div');

                display_files.className = 'display_files';

                display_files_big_area.appendChild(display_files);
                display_files.appendChild(display_files_div1);
                display_files.appendChild(display_files_div2);
                display_files.appendChild(display_files_div3);
                 display_files.appendChild(display_files_div4);

                radioInput = document.createElement('input');
                // 设置属性
                radioInput.type = 'radio'; // 设置为单选按钮
                radioInput.name = 'foobar'; // 设置 name 属性
                 radioInput.value = files[i];
                 display_files_div1.appendChild(radioInput);

                let newImg = document.createElement('img');
                 newImg.src = "/static/production_data/file.png"; // 直接在 JavaScript 中使用 Jinja
                newImg.style.width = '2rem'; // 设置宽度
                newImg.style.height = '2rem'; // 设置高度为自动
                if(files[i].split(".").pop()==="pdf"){
                    newImg.src = "/static/production_data/pdf.png"
                }
                if(files[i].split(".").pop()==="xlsx"){
                   newImg.src = "/static/production_data/excel.png"
                }
                // 添加点击事件
                newImg.addEventListener('click', function() {
                    // 获取 img 的父节点
                    let parent = this.parentNode;

                    // 获取前一个兄弟节点
                    let previousSibling = parent.previousElementSibling;


                    let radio = previousSibling.querySelector('input[type="radio"]');
                    radio.checked = true;



                });


                display_files_div2.appendChild(newImg);

                 display_files_div3.innerHTML=files[i];
                 display_files_div3.contentEditable = "true";
                 display_files_div3.setAttribute('lastvalue', files[i]);  // 将 'your_value_here' 替换为你想要的值
                 // 添加点击事件
                display_files_div3.addEventListener('click', function() {
                    // 获取下一个兄弟元素
                    let nextDiv = this.nextElementSibling;
                     // 获取前一个兄弟节点
                    let previousSibling = this.previousElementSibling.previousElementSibling;


                    let radio = previousSibling.querySelector('input[type="radio"]');
                    radio.checked = true;

                    // 如果下一个兄弟元素存在并且是 div
                    if (nextDiv && nextDiv.tagName.toLowerCase() === 'div') {
                        // 将该元素显示出来
                        nextDiv.style.visibility = 'visible';  // 显示元素
                    }
                });
                // 添加失去焦点（blur）事件监听器，失去焦点时显示下一个兄弟 div
                display_files_div3.addEventListener('blur', function() {


                    let nextDiv = this.nextElementSibling;
                    let lastvalue=this.getAttribute('lastvalue'); // 获取自定义属性 lastvalue
                    let currentvalue=this.textContent;  // 获取 div 的文本内容

                    let my_buttons=nextDiv.querySelectorAll('button'); // 选择所有的 button 元素
                    if (currentvalue==lastvalue){
                       nextDiv.style.visibility = 'hidden';  // 显示元素
                    }
                    let my_buttons1=my_buttons[2];
                     if (my_buttons1.matches(':hover')) { // 检查按钮是否被鼠标悬停
                        nextDiv.style.visibility = 'visible';  // 显示元素
                     }


                });


                 if (files_flag[i]==1){
                 display_files_div3.style.color = "green";
                 }else{
                 display_files_div3.style.color = "red";
                 }


                 let namealterbtn = document.createElement('button');
                 namealterbtn.className = 'namealterbtn';

                namealterbtn.addEventListener('click', function(){
                          //send
                       // 获取父节点的前一个兄弟节点
                    let previousSibling = this.parentNode.previousElementSibling;
                    let lastvalue=previousSibling.getAttribute('lastvalue');

                    let my_json={"my_type":"alter_file_name","old_name":lastvalue,"new_name":previousSibling.textContent}
                    let promise = send_ajax(my_json,"/production_data_blueprint_upload");
                     promise.then(function(response) {
                        refresh();
                     });

                    previousSibling.setAttribute('lastvalue', previousSibling.textContent);
                    this.parentNode.style.visibility = 'hidden';  // 隐藏父
                });

                 let namealterspan = document.createElement('span');
                 namealterspan.textContent = '修改文件名';
                 namealterbtn.appendChild(namealterspan);

                let namealterbtncancel = document.createElement('button');
                namealterbtncancel.className = 'namealterbtn';
                                // 添加点击事件
                namealterbtncancel.addEventListener('click', function() {
                    // 隐藏按钮的父节点

                    // 获取父节点的前一个兄弟节点
                    let previousSibling = this.parentNode.previousElementSibling;
                    let lastvalue=previousSibling.getAttribute('lastvalue');
                    let currentvalue=previousSibling.textContent;
                    previousSibling.textContent=lastvalue;
                     this.parentNode.style.visibility = 'hidden';  // 隐藏父


                });
                 let namealterspancancel = document.createElement('span');
                 namealterspancancel.textContent = '取消修改文件名';
                 namealterbtncancel.appendChild(namealterspancancel);


                  let open_file_btn = document.createElement('button');
                  open_file_btn.addEventListener('click', function() {

                         // 获取父节点的前一个兄弟节点
                    let previousSibling = this.parentNode.previousElementSibling;
                    let lastvalue=previousSibling.getAttribute('lastvalue');

                    let my_json={"my_type":"open_file","file_name":lastvalue}
                    let promise = send_ajax(my_json,"/production_data_blueprint_upload");



                    });
                     open_file_btn.addEventListener('blur', function() {

                         this.parentNode.style.visibility = 'hidden';  // 隐藏父


                    });
                     let open_file_btn_span = document.createElement('span');
                 open_file_btn_span.textContent = '打开';
                 open_file_btn.appendChild(open_file_btn_span);


                    display_files_div4.appendChild(namealterbtn);
                  display_files_div4.appendChild(namealterbtncancel);
                  display_files_div4.appendChild(open_file_btn);
                  display_files_div4.style.visibility = 'hidden';   // 隐藏元素


            }
         }
        console.log('Response received:', response);
    });
    promise.catch(function(error) {
        console.error('Error occurred:', error);
    });
}
var animateButton = function(e) {

  e.preventDefault;
  //reset animation
  e.target.classList.remove('animate');

  e.target.classList.add('animate');
  setTimeout(function(){
    e.target.classList.remove('animate');
  },700);
};

var bubblyButtons = document.getElementsByClassName("bubbly-button");
    for (var i = 0; i < bubblyButtons.length; i++) {
      bubblyButtons[i].addEventListener('click', animateButton, false);
}
function send_ajax(json_para,url_path) {
    return new Promise(function(resolve, reject) {
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function() {
            if (xhr.readyState === 4) { // 4 means the request is done.
                if (xhr.status === 200) {
                    var json_parsed=JSON.parse(xhr.responseText);
                    resolve(json_parsed); // Successful response
                } else {
                    reject(new Error('Request failed with status code ' + xhr.status));
                }
            }
        };
        xhr.onerror = function() {
            reject(new Error('Network Error'));
        };
        xhr.open('POST', url_path);
        xhr.setRequestHeader('Content-Type', 'application/json');  // 设置请求头
        xhr.send(JSON.stringify(json_para));  // 发送请求并传递 JSON 数据
    });
}
var bubbly_button_1=document.getElementById("bubbly-button_1");
bubbly_button_1.onclick=function(e){
    let my_json={"my_type":"upload","my_file":"1"}
    let promise = send_ajax(my_json,"/production_data_blueprint_upload");
    promise.then(function(response) {
        refresh()
        console.log('Response received:', response);
    });
    promise.catch(function(error) {
        console.error('Error occurred:', error);
    });
}
var bubbly_button_2=document.getElementById("bubbly-button_2");
bubbly_button_2.onclick=function(e){
    let my_json={"my_type":"upload","my_file":"2"}
    let promise = send_ajax(my_json,"/production_data_blueprint_upload");
    promise.then(function(response) {
        refresh()
        console.log('Response received:', response);
    });
    promise.catch(function(error) {
        console.error('Error occurred:', error);
    });
}

var bubbly_button_3=document.getElementById("bubbly-button_3");
bubbly_button_3.onclick=function(e){
    let my_json={"my_type":"upload","my_file":"3"}
    let promise = send_ajax(my_json,"/production_data_blueprint_upload");
    promise.then(function(response) {
        refresh()
        console.log('Response received:', response);
    });
    promise.catch(function(error) {
        console.error('Error occurred:', error);
    });
}

var bubbly_button_4=document.getElementById("bubbly-button_4");
bubbly_button_4.onclick=function(e){
    let my_json={"my_type":"upload","my_file":"4"}
    let promise = send_ajax(my_json,"/production_data_blueprint_upload");
    promise.then(function(response) {
        refresh()
        console.log('Response received:', response);
    });
    promise.catch(function(error) {
        console.error('Error occurred:', error);
    });
}
var bubbly_button_5=document.getElementById("bubbly-button_5");
bubbly_button_5.onclick=function(e){
    let my_json={"my_type":"upload","my_file":"5"}
    let promise = send_ajax(my_json,"/production_data_blueprint_upload");
    promise.then(function(response) {
        refresh()
        console.log('Response received:', response);
    });
    promise.catch(function(error) {
        console.error('Error occurred:', error);
    });
}

function main_start(){
    file_name=""
    var radios = document.querySelectorAll('input[name="foobar"]');

    for (var radio of radios) {
                if (radio.checked) {
                    console.log('选中的值: ' + radio.value); // 显示选中的值
                    file_name=radio.value;
        }
    }

    checkbox_list=get_values()
    let my_json={"my_type":"main_start","file_name":file_name,"checkbox_list":checkbox_list}
    let promise = send_ajax(my_json,"/production_data_blueprint_upload");
    promise.then(function(response) {
        console.log('Response received:', response);
    });
    promise.catch(function(error) {
        console.error('Error occurred:', error);
    });
}


var bubbly_button_6=document.getElementById("bubbly-button_6");
bubbly_button_6.onclick=function(e){
    let my_json={"my_type":"upload","my_file":"6"}
    let promise = send_ajax(my_json,"/production_data_blueprint_upload");
    promise.then(function(response) {
        refresh()
        console.log('Response received:', response);
    });
    promise.catch(function(error) {
        console.error('Error occurred:', error);
    });
}
var my_merge_btn=document.getElementById("my_merge_btn");
my_merge_btn.onclick=function(e){
    let my_json={"my_type":"my_merge"}
    let promise = send_ajax(my_json,"/production_data_blueprint_upload");
    promise.then(function(response) {
        refresh()
        console.log('Response received:', response);
    });
    promise.catch(function(error) {
        console.error('Error occurred:', error);
    });
}
 function get_values(){

        var checkboxes = document.querySelectorAll('.checkbox-wrapper-40 input[type="checkbox"]');

        // 创建一个数组来存储选中的复选框的值
        var selectedValues = [];

        // 遍历复选框列表，检查是否被选中
        checkboxes.forEach(checkbox => {
            if (checkbox.checked) {
                selectedValues.push(checkbox.getAttribute('data-value'));  // 获取自定义的 data-value 值
            }
        });

        // 打印选中的复选框值数组
        console.log(selectedValues);
        return selectedValues

    }

     // 获取所有复选框
        var checkboxes = document.querySelectorAll('input[type="checkbox"]');

        // 为每个复选框添加点击事件
        checkboxes.forEach(checkbox => {
            checkbox.addEventListener('click', function() {
                // 如果当前复选框被选中，则取消其他复选框的选中状态
                if (this.checked) {
                    checkboxes.forEach(cb => {
                        if (cb !== this) {
                            cb.checked = false;
                        }
                    });
                }
            });
        });





// 获取所有具有 open_ledger_file 类的按钮
const open_ledger_file_btns = document.querySelectorAll('.open_ledger_file');

// 为每个按钮添加点击事件
open_ledger_file_btns.forEach(button => {
    button.addEventListener('click', function() {
    // 获取上一个兄弟元素（span）
                let previousSpan = this.previousElementSibling;

                // 检查上一个兄弟元素是否存在并且是 span
                if (previousSpan && previousSpan.tagName.toLowerCase() === 'span') {
                    // 获取并显示上一个兄弟元素的文本值
                    const previousText = previousSpan.textContent;
                    if (previousText==""){
                        alert('空地址无法打开'); // 显示上一个 span 的文本
                    }

                    let my_json={"my_type":"open_ledger_file","file_path":previousText};
                    let promise = send_ajax(my_json,"/production_data_blueprint_upload");
                } else {
                    alert('没有找到上一个文本。');
                }

    });
});