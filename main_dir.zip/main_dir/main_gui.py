import json
import shutil
import subprocess
import sys
import time
import tkinter
import tkinter as tk
import threading
import webbrowser
import os
import signal
import io
import sqlite3
import logging
from tkinter import messagebox, simpledialog
from urllib.parse import unquote

from main_flask import app
import requests

current_version="7"
class RedirectText(io.StringIO):
    def __init__(self, text_widget):
        super().__init__()
        self.text_widget = text_widget

    def write(self, text):
        self.text_widget.insert(tk.END, text)  # 在文本框中插入文本
        self.text_widget.see(tk.END)  # 滚动到文本框的底部
def run_flask():
    # 设置Flask日志记录到Tkinter文本框
    logger = logging.getLogger('werkzeug')
    logger.setLevel(logging.INFO)
    stream_handler = logging.StreamHandler(sys.stdout)
    logger.addHandler(stream_handler)
    app.run(host="0.0.0.0",debug=False)
def get_db_path():
    if getattr(sys, 'frozen', False):
        # 如果是打包后的程序，使用临时目录
        return os.path.join(sys._MEIPASS, 'secret.db')
    else:
        # 如果是开发环境，直接使用当前目录
        return 'secret.db'
def get_image_path(filename):
    """根据文件名获取图片路径，无论是否被打包"""
    # 如果被 PyInstaller 打包
    if getattr(sys, 'frozen', False):
        base_path = sys._MEIPASS  # 打包后的临时路径
    else:
        base_path = os.path.dirname(os.path.abspath(__file__))  # 开发时路径
    return os.path.join(base_path, 'static', filename)


def check_for_updates(main_executable,link):
    global current_version
    try:
        update_url = "https://steep-mode-8f0c.x2259026163.workers.dev/"
        response = requests.get(update_url)
        print(response.text)
        response.raise_for_status()

        # 原始 JSON 字符串
        #response_text = r'{"是否更新":"是","更新类型":"网络磁盘","更新地址":"\\\\192.168.130.25\\finance\\ONC-----------共享资料\\临时可删除\\main_gui.exe"}'
        # 替换单个反斜杠为双反斜杠以确保 JSON 格式正确
        response_text = response.text.replace('\\', '\\\\')
        #{"是否更新": "是", "更新类型": "网络磁盘","更新地址": "\\192.168.130.25\finance\ONC-----------共享资料\临时可删除\main_gui.exe"}
        # 解析 JSON 字符串
        data = json.loads(response_text)

        # 访问值
        is_update = data["是否更新"]
        update_type = data["更新类型"]
        update_address = data["更新地址"]

        # 打印值
        print("是否更新:", is_update)
        print("更新类型:", update_type)
        print("更新地址:", update_address)
        最新版本=data["最新版本"]
        if is_update == "是" and current_version!=最新版本:

            link.config(text="有更新，点击查看")# 创建超链接标签
            link.bind("<Button-1>", lambda event: show_link_popup(event, data,main_executable))
            #result = messagebox.askyesno("Update Available", "A new update is available. Do you want to update now?")
            #print("123")
        else:
            link.config(text="当前已是最新版本")




    except Exception as e:
        #messagebox.showerror("Error", f"无法检测更新状态: {e}")
        print(f"无法检测更新状态: {e}")
        pass
def show_link_popup(event,data,main_executable):
    # 弹出确认对话框
    result = messagebox.askyesno("可更新", "有新版本，是否需要更新?")
    if result:
        print("User chose to update.")
        update_address = unquote(data["更新地址"])
        download_update(update_address, main_executable)

        # 在这里添加更新逻辑
    else:
        print("User chose not to update.")
def download_update(update_path, main_executable):
    # 创建 copy.bat 文件
    batch_content = """@echo off
    echo starting
    ping -n 2 127.0.0.1 > nul
    echo copy
    del main_gui.exe
    copy temp_main_gui.exe main_gui.exe /Y
    echo finished
    del temp_main_gui.exe
    ping -n 2 127.0.0.1 > nul
    echo done
    exit
    """

    # 将内容写入 copy.bat 文件
    with open('updater.bat', 'w') as bat_file:
        bat_file.write(batch_content)
    try:
        temp_update_path = os.path.join(os.getcwd(), "temp_main_gui.exe")

        # 复制更新文件到临时路径
        shutil.copyfile(update_path, temp_update_path)

        # 启动子进程来处理更新和重启
        #process = multiprocessing.Process(target=apply_update_and_restart, args=(temp_update_path, main_executable))
        #process.start()
        subprocess.Popen(f'updater.bat')
        # 关闭主程序
        os.kill(os.getpid(), signal.SIGINT)

    except Exception as e:
        #messagebox.showerror("Error", f"下载更新文件失败: {e}")
        print(f"下载更新文件失败: {e}")
def apply_update_and_restart(temp_update_path, main_executable):

    time.sleep(2)# 等待主程序关闭

    try:
        subprocess.Popen(f'updater.bat')
        # 备份旧程序文件（可选）
        backup_path = main_executable + ".bak"
        print("here")
        if os.path.exists(backup_path):
            os.remove(backup_path)
        shutil.move(main_executable, backup_path)

        # 替换旧文件为更新文件
        shutil.move(temp_update_path, main_executable)

        # 重启主程序

        #subprocess.Popen([main_executable])

    except Exception as e:
        print(f"Update failed: {e}")
        sys.exit(1)
# 创建GUI的函数

root = tk.Tk()
def create_gui():
    global root
    root.deiconify()  # 重新显示主窗口


    def on_closing():
        # 关闭窗口时，发送信号关闭Flask服务器
        os.kill(os.getpid(), signal.SIGINT)
        root.destroy()

    def open_flask_page():

        webbrowser.open("http://127.0.0.1:5000/home")# 打开Flask服务器的网页地址

    def toggle_topmost():
        # 切换窗口的置顶状态
        is_topmost = root.attributes('-topmost')
        root.attributes('-topmost', not is_topmost)


    root.title("引导程序主界面")
    root.geometry("400x350")
    root.configure(bg="#f0f0f0")  # 设置背景颜色
    # 设置窗口图标，指定图标文件路径
    image_path = get_image_path('loyalty.ico')
    root.iconbitmap(image_path)

    button1 = tk.Button(root, text="打开网页", command=open_flask_page ,width=15, height=2,)
    button1.pack(pady=10)










    # 创建置顶按钮
    # 创建顶部按钮框架
    top_button_frame = tk.Frame(root)
    top_button_frame.pack(pady=5)
    # 创建置顶按钮
    topmost_button = tk.Button(top_button_frame, text="置顶", command=toggle_topmost, width=15)
    topmost_button.pack(side=tk.LEFT, padx=5)
    # 添加状态栏
    status_label = tk.Label(root, text="状态栏", anchor='w')
    status_label.pack(fill=tk.X, padx=10, pady=(5, 0))
    # 创建输出文本框
    output_text = tk.Text(root, wrap=tk.WORD, height=10)
    output_text.pack(pady=10, padx=10, fill=tk.BOTH, expand=True)
    # 设置窗口关闭时的回调
    # 重定向print输出到输出文本框
    sys.stdout = RedirectText(output_text)




    root.protocol("WM_DELETE_WINDOW", on_closing)
    print("程序已启动")

    # 创建一个标签，作为超链接
    link = tk.Label(root, text="", fg="blue", cursor="hand2")
    link.pack(side="bottom", pady=10)  # 添加到窗口底部，并设置间距

    # 启动一个线程来检查更新
    update_thread = threading.Thread(target=check_for_updates, args=(sys.argv[0], link))
    update_thread.daemon = True  # 设置为守护线程，确保主线程退出时该线程也退出
    update_thread.start()
    # 启动一个线程来检查更新
    root.mainloop()
def create_secret_database():
    db_path = get_db_path()  # 请确
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS config (
            my_flag TEXT NOT NULL,
            my_password TEXT NOT NULL
        )
    ''')
    # 查询是否已存在记录
    cursor.execute('SELECT COUNT(*) FROM config')
    count = cursor.fetchone()[0]

    # 如果记录不存在，则插入初始值
    if count == 0:
        cursor.execute('INSERT INTO config (my_flag, my_password) VALUES (?, ?)',
                       ("admin", "my_secret_password_my_secret_password"))
        print("初始值已插入：my_flag: admin, my_password: my_secret_password_my_secret_password")
    else:
        print("记录已存在，无需插入。")
    conn.commit()
    conn.close()
def init_sqlite():
    connection = sqlite3.connect('basic_data.db')
    cursor = connection.cursor()# 创建一个游标对象
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS file_paths(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            file_name TEXT NOT NULL,
            file_path TEXT
        )
        ''')# 创建一个表，只有在表不存在时才会创建

    connection.commit()# 提交事务
    cursor.close()# 关闭游标和连接
    connection.close()
def read_config():
    db_path = get_db_path()
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute('SELECT data FROM config')
    result = cursor.fetchone()
    conn.close()
    return result[0] if result else None

def check_config_data():
    db_path = get_db_path()  # 请确保定义了 get_db_path() 函数
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM config')
    result = cursor.fetchall()  # 获取所有结果
    conn.close()
    print(result)
    # 判断结果的长度
    if len(result) > 1:
        ask_for_password(result)  # 如果长度大于1，询问密码

def ask_for_password(result):
    root.withdraw()  # 隐藏主窗口
    root2 = tk.Toplevel()
    root2.title("引导程序主界面")
    root2.geometry("400x350")
    # 隐藏主窗口
    root2.withdraw()
    password = simpledialog.askstring("输入密码", "请输入密码:", show='*',parent=root2)  # 弹出输入框

    admin_password=result[0][1]
    user_password=result[1][1]
    if password == admin_password or password == user_password:  # 替换为你的正确密码
        print("密码正确，程序将终止。")
        root2.quit()  # 退出当前GUI
        #main_create_gui()  # 运行 GUI 函数

    else:
        messagebox.showerror("错误", "密码不匹配!退出程序")
        sys.exit(0)
if __name__ == "__main__":
    #create_secret_database()
    #check_config_data()

    init_sqlite()
    # 检查数据库数据

    # 创建并启动Flask线程
    flask_thread = threading.Thread(target=run_flask)
    flask_thread.daemon = True  # 设置为守护线程，在主线程结束时自动关闭
    flask_thread.start()
    # 创建并启动Flask线程
    create_gui()# 运行GUI
